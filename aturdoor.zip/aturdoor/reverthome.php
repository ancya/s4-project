<!DOCTYPE html>
<html>
<head>
<title>@Your door</title>

<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Grocery Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all" /> 
<!-- //font-awesome icons -->
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<!-- js -->
<script src="js/jquery-1.11.1.min.js"></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
</head>
	
<body>
	
<!-- header -->
	<div class="agileits_header">
		<div class="w3l_offers">
			<a href="product.php" style=height="30" >Today's special Offers !</a>
			
			
		
        </div>
		<div class="w3l_header_right">
		
		<form class="example" action="search.php" method="POST">
        <input type="text" placeholder="Search.." name="search" >
        <button type="submit"><i class="fa fa-search" ></i></button>
        </form>
				
		
		</div>
		
		<div >   
			<!-- <div style="float:left;margin-left:184px">
		<button style=" text-decoration:none;margin-top: 9px; height: 32px; width: 141px; background-color: #fdae04; border: none;font-size: 1.2em;color: #fff;"><a href="view_profile.php" style="text-decoration:none;">View Profile</a></button>
           </div> -->
		   <div style="float:left;margin-left:10px">
		<button style=" text-decoration:none;margin-top: 9px; height: 32px; width: 141px; background-color: #fdae04; border: none;font-size: 1.2em;color: #fff;"><a href="carts.php" style="text-decoration:none;">View Cart</a></button>
		
         </div>
	      </div> 
		  <!-- <div class="container mt-3"> -->

<!-- 
		  <div class="dropdown">
		  <div style="float:right;margin-right:184px">
    <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown"style=" text-decoration:none;margin-top: 20px; height: 32px; width: 141px; background-color: #fdae04; border: none;font-size: 1.2em;color: #fff;">>
      Dropdown button
    </button>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="#">Link 1</a></li>
      <li><a class="dropdown-item" href="#">Link 2</a></li>
      <li><a class="dropdown-item" href="#">Link 3</a></li>
      <li><hr class="dropdown-divider"></li>
      <li><a class="dropdown-item" href="#">Another link</a></li>
    </ul>
  </div>
      </div>
</div> -->


<li>
                   
                   <div class="dropdown">
                   <li>my account</li>
                   <div class="dropdown-content">
                   <ul class="dropdown-menu">
 <li><a class="dropdown-item" href="#">Link 1</a></li>
 <li><a class="dropdown-item" href="#">Link 2</a></li>
 <li><a class="dropdown-item" href="#">Link 3</a></li>
 <li><hr class="dropdown-divider"></li>
 <!-- <li><a class="dropdown-item" href="#">Another link</a></li>
                   <a href="signup.php">As User</a>
                   <a href="supplier.php">As Supplier</a> -->
                  
               </div>
              </div>

               
               </li>
		
		
		
		
		<div class="form-floating">
		
		<div class="w3l_header_right1">
	<select class="form-select" id="floatingSelect" aria-label="Floating label select example"style=" color: #fff;background-color: #84C639; height: 34px; font-size: -0.26rem;  margin: 7px;text-align: center;font-weight: 500;width:127px" onchange="this.value">
   <option selected><?php echo $name; ?></option>
   	
  
   
  
   
   </select>
		</div>
</div>
</body>
</html>
