<?php 
include 'db.php';
session_start();
$uid = $_SESSION['login_admin'];
$fid=$_GET['sid'];
    $sql = mysqli_query($conn,"SELECT * FROM `feedback_db` where feedback_id='$fid'");
 

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    
    <div class="main">
        
        <div class="disk">

        <div class="newsletter" style="background-color:#84c639;">
		<div class="container">
		<center><h3 style="color:#fff"> Feedback Reply</h3><center>
			<div class="">
				
			</div>
			<div class="" style="margin-top:10px;">
				<form  method="post">
					
					<div class="">
                    <table>
                <tr>
                   
                    <th>feedback</th>
                    <th>reply</th>
                </tr>
                <?php 
                $sql2 = mysqli_query($conn,"SELECT * FROM `feedback_db` where user_id='$uid'");
                while ($row = mysqli_fetch_assoc($sql2)){ ?>
                <tr>
                   
                    <td><?php echo $row['content']?></td>
                    <td><?php echo $row['replay']?></td>
                   
                </tr>
                <?php } ?>
            </table>
	<!-- <textarea cols="50" rows="10" name="freply"  value ="feedbackreply" required=""></textarea> -->
		</div>
					
			</div>
            </table>

        </div>
    </div>
    <script>
        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active')
            main.classList.toggle('active')

        }
    </script>

</body>

</html>