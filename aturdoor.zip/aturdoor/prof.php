<!DOCTYPE html>
<html>
<head>
<title>@Your door</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Grocery Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all" /> 
<!-- //font-awesome icons -->
<!-- js -->
<script src="js/jquery-1.11.1.min.js"></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- start-smoth-scrolling -->
</head>
	
<body>
<?php include 'hheader.php' ?>
<style>
.button-24{
    background: #FF4742;
  border: 1px solid #FF4742;
  border-radius: 6px;
  box-shadow: rgba(0, 0, 0, 0.1) 1px 2px 4px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: nunito,roboto,proxima-nova,"proxima nova",sans-serif;
  font-size: 14px;
  line-height: 16px;
  min-height: 30px;
  outline: 0;
  padding: 12px 14px;
  text-align: center;
  text-rendering: geometricprecision;
  text-transform: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: middle;
}

.button-24:hover,
.button-24:active {
  background-color: initial;
  background-position: 0 0;
  color: #FF4742;
}

.button-24:active {
  opacity: .5;
}

</style>
<?php
include 'db.php';
session_start();
error_reporting(0);
$uid = $_SESSION['login_admin'];
if($_SESSION['login_admin']==""){
  header('location:login.php');
}
$sql = mysqli_query($conn,"SELECT * from register where login_id='$uid'");
while($row=mysqli_fetch_array($sql)){
  $name = $row['uname'];
  $id= $row['login_id'];
  $email= $row['email'];
  $imgurl='seller/'.$row['image'];
 
}
?>
  <html>

  <head>
    
    <style>
      table {
        border-collapse: collapse;
        width: 100%;
      }

      th,
      td {
        text-align: left;
        padding: 8px;
      }

      tr:nth-child(even) {
        background-color: #f2f2f2;
      }
    </style>

  </head>

  </html>
  <div style="position: relative;top:5px;padding:5px;margin-bottom:50px;width: 496px; margin-left: 413px; margin-top: 100px;">
    <h3>Profile</h3>
    <table style="border:1px solid lightgrey;">
    <?php
                $result = mysqli_query($conn,"SELECT * FROM register where login_id='$uid'");
                $result1 = mysqli_query($conn,"SELECT * FROM login_tbl where login_id='$uid'");
                $raw = mysqli_fetch_array($result1);
                                while ($raw1 = mysqli_fetch_array($result)){ ?>


    <tr>
      <!-- <input type="text" value="<?php echo $imgurl ?>"> -->
        <img src="<?php echo $imgurl ?>" width="110px"  style="margin-left:200px;margin-top:-20px;"><br>
        </tr>
                                
      <tr>
        <th>Name</th>
        <td><?php echo $raw1['uname']; ?></td>
      </tr>
      <tr>
        <th>Address</th>
        <td><?php echo $raw1['address']; ?></td>
      </tr>
      <tr>
        <th>Email</th>
        <td><?php echo $raw['email']; ?></td>
      </tr>
      <tr>
        <th>Phone</th>
        <td><?php echo $raw1['phonenumber']; ?></td>
      </tr>
    </table>
  </div>
  <?php } ?>
  <!-- <form method="POST" enctype="multipart/form-data" style="width: 496px;margin-left: 419px;">
    <table class="table table-bordered">
      <h4 style="font-weight: bolder;">Update profile</h4>
      <hr>
      <tr>
        <th>Name</th>
        <td><input type="text" name="name" class="form-control" value="<?php echo $row['uname']; ?>" />
        </td>
      </tr>
      <tr>
        <th>Address</th>
        <td><input type="text" name="address" class="form-control" value="<?php echo $row['address']; ?>" />
        </td>
      </tr>
      <tr>
        <th>Phone</th>
        <td><input type="text" name="phone" class="form-control" value="<?php echo $row['phonenumber']; ?>" />
        </td>
      </tr>
      <input type="hidden" name="id" class="form-control" value="<?php echo $id; ?>" />
 -->

     <div>
                  <button  class="btn btn-primary" style=" margin-left: 44%;" type="submit" name="submit"><a href="edpro.php<?php echo $row['login_id']; ?>">Edit profile</button>
                   </div>
    </table>
  </form>

  </html>
<!-- <//?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="../login.html?e=1"</script>');
  } else {
    header("location:../login.html?e=1");
    die();
  }
}
?> -->
