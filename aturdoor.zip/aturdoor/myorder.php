<?php 
include 'db.php';
session_start();
$ff=$_SESSION['login_admin'];

$result =mysqli_query($conn, "SELECT register.uname, register.login_id,order_tbl.date,
order_tbl.id,order_tbl.login_id,order_tbl.status,order_tbl.price,
cart_tbl.product_id,cart_tbl.total_price,cart_tbl.quantity,
product_tbl.product_name,product_tbl.image,product_tbl.owner_id
FROM register
INNER JOIN order_tbl ON register.login_id = order_tbl.login_id
INNER JOIN cart_tbl ON order_tbl.id = cart_tbl.orderid
INNER JOIN product_tbl ON cart_tbl.product_id = product_tbl.product_id where register.login_id='$ff'");

                   
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <style>
        table{
            border-collapse:collapse;
            width:100%;
        }
        th,td{
            text-align:left;
            padding:10px
        }
        tr:nth-child(even){
            background-color:#f2f2f2;
        }
        th{
            background-color:#867198;
            color:black;
        }
    </style>
</head>

<body style="" height:100px;>

    
    
    <div class="main">

       
        <div class="disk">
           
            <div class="container" position="inherit">
                <form method="post">
                    <div class="row">
                        <div>
                        <div>
        <!-- <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search products" title="Type in a name"> -->
</div>

                            

					<div class="table-wrap">
						<table class="table" id="sample-table-1">
						  <thead class="thead-primary" style="background-color: #84C639; "margin:inherit">
                          <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table border=2 width=100%>
						    <tr>
                            <th>order id</th>
                            <th>Product name</th>
                            <th>quantity</th>
                            <th>Price</th>
                            <th>status</th>
                            <th>Date</th>
                            
						    </tr>
						  </thead>
						  <tbody>
                          <?php while ($row = mysqli_fetch_array($result)) { ?>
                            <tr>
                                <td><p><?php echo $row['id']?></p></td>
                                <!-- <td><p><img src="../dealer/productimages/<//?php echo $row['image']; ?>" alt=" " class="img-responsive" style="height: 50px; width: 50px;" /></p> -->
                                <td><p><?php echo $row['product_name']?></p></td>
                                <td><p><?php echo $row['quantity']?></p></td>
                                <td><p><?php echo $row['price']?></p></td>
                                <td><p><?php echo $row['status']?></p></td>
                                <td><p><?php echo $row['date']?></p></td>
                            </tr>
                         
                        <?php } ?>
<div>
                          </div>
                          </div>
                    <h2> MY ORDER</h2>
                </div>
                
                    </tbody>
                </table>
                <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("sample-table-1");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[5];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>


            </div>
</html>