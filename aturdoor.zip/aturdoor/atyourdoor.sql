-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2022 at 10:48 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atyourdoor`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart_tbl`
--

CREATE TABLE `cart_tbl` (
  `cart_id` int(11) NOT NULL,
  `login_id` int(20) NOT NULL,
  `product_id` int(20) NOT NULL,
  `quantity` int(22) NOT NULL,
  `price` int(20) NOT NULL,
  `total_price` int(20) NOT NULL,
  `sts` int(11) NOT NULL,
  `orderid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart_tbl`
--

INSERT INTO `cart_tbl` (`cart_id`, `login_id`, `product_id`, `quantity`, `price`, `total_price`, `sts`, `orderid`) VALUES
(1, 57, 12, 1, 99, 99, 1, 99),
(2, 57, 9, 1, 55, 55, 1, 99),
(3, 57, 1, 2, 300, 600, 1, 99),
(4, 57, 4, 1, 40, 40, 1, 99),
(6, 85, 1, 2, 300, 600, 0, 0),
(7, 57, 35, 2, 60, 120, 1, 100),
(8, 57, 27, 1, 40, 40, 1, 101),
(9, 57, 35, 1, 60, 60, 1, 101),
(10, 57, 35, 1, 60, 60, 1, 102),
(11, 57, 35, 1, 60, 60, 1, 103),
(12, 57, 35, 1, 60, 60, 1, 104),
(13, 57, 35, 1, 60, 60, 1, 105),
(14, 57, 35, 1, 60, 60, 1, 106),
(16, 57, 3, 3, 10, 30, 1, 107),
(17, 57, 5, 1, 22, 22, 1, 108),
(18, 57, 3, 1, 10, 10, 1, 109),
(19, 57, 27, 1, 40, 40, 1, 110),
(20, 57, 12, 1, 99, 99, 1, 111),
(21, 57, 5, 1, 22, 22, 1, 112),
(22, 57, 1, 4, 300, 1200, 1, 113),
(25, 57, 9, 1, 55, 55, 1, 113),
(26, 57, 30, 1, 80, 80, 1, 113),
(27, 57, 33, 1, 60, 60, 1, 113),
(28, 55, 3, 1, 10, 10, 1, 114),
(29, 55, 33, 1, 60, 60, 1, 114),
(30, 55, 7, 1, 88, 88, 1, 115),
(31, 55, 33, 4, 60, 240, 1, 116),
(32, 57, 9, 1, 55, 55, 1, 117),
(33, 57, 5, 2, 22, 44, 1, 118),
(34, 57, 41, 1, 40, 40, 1, 119),
(35, 50, 9, 1, 55, 55, 1, 120),
(36, 57, 9, 1, 55, 55, 1, 121),
(37, 57, 4, 1, 40, 40, 1, 121);

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `id` int(11) NOT NULL,
  `city` varchar(100) NOT NULL,
  `pincode` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`id`, `city`, `pincode`) VALUES
(6, 'kanjirapally', 678903);

-- --------------------------------------------------------

--
-- Table structure for table `dealer_tbl`
--

CREATE TABLE `dealer_tbl` (
  `dealer_id` int(11) NOT NULL,
  `dealer_name` varchar(40) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phonenumber` varchar(30) NOT NULL,
  `place` varchar(60) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dealer_tbl`
--

INSERT INTO `dealer_tbl` (`dealer_id`, `dealer_name`, `email`, `phonenumber`, `place`, `login_id`) VALUES
(4, 'karth', 'karthi@gmail.com', '80897865', 'ggjjjj', 25),
(5, 'Arya sasi', 'aryaa@gmail.com', '9562540965', 'Mettinpurathu House', 30),
(6, 'kuttan', 'Kuttan@outlook.com', '9607855340', 'kulirmala house', 51),
(7, 'Alexa', 'alexa@gmail.com', '7863562626', '', 71),
(9, 'Ani', 'ani1@g.com', '9544163214', '', 85),
(10, 'Keerthana', 'keerthana@gmail.com', '9544163214', '', 86),
(11, 'Arya', 'aryasasi1605@gmail.com', '9562540965', '', 89),
(12, 'Arya', 'aryasasi1605@gmail.com', '9562540965', '', 90),
(13, 'Karthik', 'karthikpato@gmail.com', '9544163214', '', 92);

-- --------------------------------------------------------

--
-- Table structure for table `deliveryboy_tbl`
--

CREATE TABLE `deliveryboy_tbl` (
  `dboy_id` int(11) NOT NULL,
  `dname` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phonenumber` bigint(20) NOT NULL,
  `place` varchar(50) NOT NULL,
  `login_id` int(11) NOT NULL,
  `dealer_id` int(30) NOT NULL,
  `status` int(10) NOT NULL,
  `sts` varchar(30) NOT NULL,
  `pincode` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `deliveryboy_tbl`
--

INSERT INTO `deliveryboy_tbl` (`dboy_id`, `dname`, `email`, `phonenumber`, `place`, `login_id`, `dealer_id`, `status`, `sts`, `pincode`) VALUES
(1, 'Kichu', 'kichu1@gmail.com', 890764432, 'kollam', 52, 0, 0, '', 0),
(2, 'Anu', 'ancyanu@gmail.com', 709678654, 'Kollam', 53, 0, 0, '', 0),
(4, 'Neha', 'Neha@gmail.com', 9567890467, 'kollam', 73, 0, 0, '', 0),
(5, 'tan', 'tan@gmail.com', 7560342611, 'kottayam', 74, 72, 1, '', 0),
(6, 'krish', 'krish@gmail.com', 9867722446, 'kottayam', 75, 72, 0, 'inactive', 686518),
(7, 'Tom', 'tom@gmail.com', 9544163214, 'kottayam', 87, 85, 1, 'inactive', 686001),
(8, 'Arya', 'arya1@gmail.com', 9995780645, 'kottayam', 88, 85, 1, 'inactive', 686544),
(9, 'Achu', 'achumon@gmail.com', 9544163214, 'kottayam', 91, 90, 1, 'inactive', 686001),
(10, 'Anilect', 'animon@gmail.com', 9544163214, 'kottayam', 100, 85, 1, 'inactive', 686001);

-- --------------------------------------------------------

--
-- Table structure for table `delivery_assign`
--

CREATE TABLE `delivery_assign` (
  `id` int(10) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `price` int(10) NOT NULL,
  `assigned_db` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `delivery_assign`
--

INSERT INTO `delivery_assign` (`id`, `customer_name`, `address`, `phone`, `price`, `assigned_db`, `status`) VALUES
(32, 'ederson', 'ethihad city', 9744444467, 44, '', 'ready to ship');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `category_name` varchar(20) NOT NULL,
  `category_desc` varchar(30) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `feedback_db`
--

CREATE TABLE `feedback_db` (
  `feedback_id` int(11) NOT NULL,
  `user_id` int(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `content` varchar(200) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `replay` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback_db`
--

INSERT INTO `feedback_db` (`feedback_id`, `user_id`, `name`, `subject`, `content`, `user_type`, `replay`) VALUES
(1, 0, 'Arjun', 'can\'t use', 'There is some issues on ordering', 'deliveryboy', 'contact admin'),
(2, 0, 'Joyal', 'not working', 'That\'s working perfectly when there are no recent orders, but...', 'Admin', 'we will work on it'),
(4, 0, 'ederson', 'bad quality', 'cant helpful', 'Admin', 'we will help u'),
(6, 0, 'buffon', 'Subject', 'this is not working', 'Admin', ''),
(7, 57, 'Anu', 'problem', 'this is not working well', 'Admin', 'we will contact');

-- --------------------------------------------------------

--
-- Table structure for table `login_tbl`
--

CREATE TABLE `login_tbl` (
  `login_id` int(11) NOT NULL,
  `email` varchar(35) NOT NULL,
  `password` varchar(25) NOT NULL,
  `role` varchar(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_tbl`
--

INSERT INTO `login_tbl` (`login_id`, `email`, `password`, `role`, `status`) VALUES
(50, 'admin221@gmail.com', 'Ancy143@', 'admin', 1),
(51, 'kuttan@outlook.com', 'Kuttn@123', 'dealer', 1),
(52, 'kichu1@gmail.com', 'Ancyanu@7', 'deliveryboy', 1),
(53, 'ancyanu@gmail.com', 'ancy@7', 'deliveryboy', 1),
(55, 'cidkaj@gmail.com', 'Ancyanu@7', 'user', 1),
(56, 'jj@gmail.com', 'Nil@123', 'user', 1),
(57, 'ancya@gmail.com', 'Ancyanu@7', 'user', 1),
(67, 'kichu@gmail.com', 'Kichu@7', 'seller', 1),
(73, 'Neha@gmail.com', 'Neha@7', 'deliveryboy', 1),
(75, 'krish@gmail.com', 'A@123', 'deliveryboy', 0),
(82, 'adarshvprasanth@gmail.com', 'Adarsh@7', 'user', 1),
(84, 'ancyalxndr143@gmail.com', 'Ancyanu@7', 'user', 1),
(85, 'ani1@gmail.com', 'Ani@7', 'seller', 1),
(86, 'keerthana@gmail.com', 'Ancyanu@7', 'seller', 1),
(87, 'tom@gmail.com', 'Ancyanu@7', 'deliveryboy', 1),
(88, 'arya1@gmail.com', 'Arya@7', 'deliveryboy', 1),
(90, 'aryasasi1605@gmail.com', 'Arya', 'seller', 1),
(91, 'achumon@gmail.com', 'Ancyanu@7', 'deliveryboy', 1),
(92, 'karthikpato@gmail.com', 'Ancyanu@7', 'seller', 1),
(94, 'tomjoseph11042000@gmail.com', 'Ancyanu@7', 'user', 1),
(99, 'ancyalexandera149@gmail.com', 'Ancyanu@7', 'user', 0),
(100, 'animon@gmail.com', 'Ancyanu@7', 'deliveryboy', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mail_sent`
--

CREATE TABLE `mail_sent` (
  `mail_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `sts` int(11) NOT NULL,
  `sent_date` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mail_sent`
--

INSERT INTO `mail_sent` (`mail_id`, `count`, `sts`, `sent_date`) VALUES
(1, 4, 1, '04-2022'),
(2, 6, 1, '05-2022'),
(3, 6, 1, '06-2022'),
(4, 0, 1, '06-2022'),
(5, 0, 1, '06-2022'),
(6, 0, 1, '06-2022'),
(7, 0, 1, '06-2022'),
(8, 0, 1, '06-2022'),
(9, 0, 1, '06-2022'),
(10, 0, 1, '06-2022'),
(11, 0, 1, '06-2022'),
(12, 0, 1, '06-2022'),
(13, 0, 1, '06-2022'),
(14, 0, 1, '06-2022'),
(15, 0, 1, '06-2022'),
(16, 0, 1, '06-2022'),
(17, 0, 1, '06-2022'),
(18, 0, 1, '06-2022'),
(19, 7, 1, '07-2022');

-- --------------------------------------------------------

--
-- Table structure for table `order_db`
--

CREATE TABLE `order_db` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `price` int(11) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_db`
--

INSERT INTO `order_db` (`order_id`, `product_id`, `login_id`, `date`, `price`, `status`) VALUES
(1, 1, 9, '2022-02-01', 300, 'Pending'),
(2, 2, 12, '2022-02-09', 350, 'Delivered');

-- --------------------------------------------------------

--
-- Table structure for table `order_tbl`
--

CREATE TABLE `order_tbl` (
  `id` int(10) NOT NULL,
  `login_id` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `status` varchar(20) NOT NULL,
  `del_boy` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_tbl`
--

INSERT INTO `order_tbl` (`id`, `login_id`, `price`, `status`, `del_boy`, `date`) VALUES
(58, 42, 211, 'delivered', 52, '2022-06-17 08:50:58'),
(100, 57, 120, 'delivered', 87, '2022-06-25 06:16:13'),
(112, 57, 22, 'shipped', 57, '2022-06-27 03:36:31'),
(113, 57, 1395, 'placed', 0, '2022-06-28 03:54:57'),
(114, 55, 70, 'delivered', 100, '2022-06-28 07:08:07'),
(115, 55, 88, 'delivered', 100, '2022-06-28 07:50:45'),
(116, 55, 240, 'delivered', 100, '2022-06-28 09:19:17'),
(117, 57, 55, 'shipped', 91, '2022-07-01 06:03:29'),
(118, 57, 44, 'shipped', 100, '2022-07-01 06:05:31'),
(119, 57, 40, 'placed', 0, '2022-07-01 06:08:17'),
(120, 50, 55, 'placed', 0, '2022-07-01 09:38:21'),
(121, 57, 95, 'placed', 0, '2022-07-03 07:08:58');

-- --------------------------------------------------------

--
-- Table structure for table `product_tbl`
--

CREATE TABLE `product_tbl` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `type` varchar(25) NOT NULL,
  `description` varchar(500) NOT NULL,
  `shop` varchar(30) NOT NULL,
  `image` varchar(100) NOT NULL,
  `image1` varchar(100) NOT NULL,
  `availability` varchar(26) NOT NULL,
  `price` varchar(50) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `status` int(10) NOT NULL,
  `owner_id` int(20) NOT NULL,
  `mdate` date DEFAULT NULL,
  `edate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_tbl`
--

INSERT INTO `product_tbl` (`product_id`, `product_name`, `type`, `description`, `shop`, `image`, `image1`, `availability`, `price`, `quantity`, `status`, `owner_id`, `mdate`, `edate`) VALUES
(4, 'Pomegrenate', '4', 'Fresh Fresh', 'fresh veg&fruits', 'fruits.jpg', 'pom.png', 'Available', '40', '-1', 1, 85, '2022-06-30', '2022-07-01'),
(5, 'cabbage', '4', 'Green and farm fresh', 'fresh veg&fruits', 'veg.jpg', 'cab.jfif', 'Avaliable', '22', '0', 1, 86, '2022-06-30', '2022-07-03'),
(6, 'cleaning mop', '2', 'Best Quality', 'Reliance', 'household.jpg', 'mop1.jfif', 'Avaliable', '299', '0', 1, 71, '2022-02-02', '2022-07-03'),
(9, 'Oreo', '1', 'Best Quality', 'Reliance', 'branded.jpg', 'app.jfif', 'Avaliable', '55', '0', 1, 85, NULL, NULL),
(10, 'Wheat Bread', '14', 'Fresh Fresh', 'Reliance', 'whole-wheat-bread-500x500.jpeg', 'app.jfif', 'Avaliable', '30', '29', 1, 85, NULL, NULL),
(12, 'rotking petfood', '7', 'fresh', 'Reliance', 'pet.jpg', 'app.jfif', 'Avaliable', '99', '18', 1, 85, NULL, NULL),
(15, 'potato', '4', 'fresh', 'fresh veg&fruits', 'potato.jfif', '', 'Avaliable', '30', '0', 1, 72, '2022-02-02', '2022-07-03'),
(17, 'Tomato', '4', 'Fresh tomato', 'fresh veg&fruits', 'tomato.jfif', '', 'Avaliable', '40', '14', 1, 85, NULL, NULL),
(21, 'cake', '14', 'Birthday cake', 'Reliance', 'cake.jfif', '', 'Avaliable', '500', '19', 1, 85, NULL, NULL),
(22, 'jam', '14', 'very tasty', 'Reliance', 'jam.jfif', '', 'Avaliable', '40', '4', 1, 72, NULL, NULL),
(27, 'Mopp', '2', 'cleano', 'Reliance', 'mop.jfif', 'mop1.jfif', 'Avaliable', '40', '38', 1, 72, NULL, NULL),
(28, 'cup cakes', '1', 'tastey', 'Reliance', '43.png', '46.png', 'Avaliable', '30', '5', 1, 72, NULL, NULL),
(38, 'Mango pickle', '21', 'tasty pickle', 'Reliance', 'mang.jfif', 'pickleMangoGrated.jpg', 'Avaliable', '60', '20', 1, 85, '2022-06-27', '2022-07-30'),
(39, 'Banana Chips', '1', 'Home made tasty chips', 'Reliance', 'chips.webp', 'chipss.jpg', 'Avaliable', '40', '70', 1, 85, '2022-06-26', '2022-08-19'),
(40, 'Cooking oil', '5', 'Sunrich refined cooking oil', 'Reliance', '1.png', '17.png', 'Avaliable', '110', '40', 1, 85, '2022-06-26', '2022-12-31'),
(41, 'Frooti', '6', 'Tasty Drinks', 'Reliance', 'froo.jpg', 'frooo.jfif', 'Avaliable', '40', '39', 1, 85, '2022-05-01', '2022-09-30'),
(42, 'French Fries', '8', 'Crispy French fries', 'Reliance', '75.png', 'french.jfif', 'Avaliable', '110', '7', 1, 85, '2022-06-29', '2022-08-27');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `reg_id` int(11) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `phonenumber` varchar(20) NOT NULL,
  `login_id` int(11) NOT NULL,
  `address` varchar(60) NOT NULL,
  `place` varchar(30) NOT NULL,
  `image` varchar(40) NOT NULL,
  `pincode` int(10) NOT NULL,
  `city` varchar(30) NOT NULL,
  `latitude` double NOT NULL,
  `longittude` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`reg_id`, `uname`, `lname`, `phonenumber`, `login_id`, `address`, `place`, `image`, `pincode`, `city`, `latitude`, `longittude`) VALUES
(21, 'ancy', '', '7863562626', 26, 'asdfg', '', '', 0, '', 0, 0),
(33, 'degea', '', '9877778976', 39, 'old trafford', '', '', 0, '', 0, 0),
(34, 'pato', '', '9845511554', 40, 'milano', '', '', 0, '', 0, 0),
(35, 'buffon', '', '9877778976', 41, 'fransisco', '', '', 0, '', 0, 0),
(41, 'buffon', '', '9877665547', 47, 'ethihad city', '', '', 0, '', 0, 0),
(42, 'degea', '', '9744444467', 48, 'fransisco', 'wayanad', '', 0, '', 0, 0),
(43, 'achu', '', '9995780645', 55, 'ancyuuu', 'kottayam', '', 686001, '', 0, 0),
(44, 'nil', '', '9891113452', 56, 'fhjjj', 'kottayam', '', 0, '', 0, 0),
(45, 'Anu', '', '7863562626', 57, 'nedungottu house', 'kottayam', '', 686001, '', 9.5260093, 76.8144186),
(46, 'Ancy', '', '7025119245', 76, 'nedungottu', 'kottayam', '', 686001, '', 0, 0),
(52, 'Adarsh', 'v', '9995780645', 82, 'Nadhanam', 'kottayam', '', 0, '', 0, 0),
(53, 'Ancy', 'Alexander', '7863562626', 83, 'Nedungottu house', 'kottayam', '', 0, '', 0, 0),
(54, 'Ancy', 'Alexander', '9995780645', 84, 'Nedungottu house', 'kottayam', '', 686001, '', 0, 0),
(55, 'Ancy', 'Alex', '9544163214', 93, 'NEDUNGOTTU CHARUVIL A PUTHEN VEEDU', 'kottayam', '', 686001, '', 0, 0),
(56, 'Ton', 'Joseph', '9544163214', 94, 'Tom Bhavan', 'kottayam', 'profile.png', 686544, '', 0, 0),
(59, 'Ann', 'Alexander', '7035667854', 99, 'Nedungottu', 'kottayam', '1.png', 686544, 'Kanjirappally', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `reg_sel_tbl`
--

CREATE TABLE `reg_sel_tbl` (
  `reg_id` int(11) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `phone` bigint(70) NOT NULL,
  `login_id` int(11) NOT NULL,
  `shop` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reg_sel_tbl`
--

INSERT INTO `reg_sel_tbl` (`reg_id`, `uname`, `phone`, `login_id`, `shop`, `place`, `city`, `image`, `status`) VALUES
(15, 'Ani', 9544163214, 85, 'Reliance', 'kottayam', 'kanjirapally', '12.jfif', 1),
(16, 'Keerthana', 9544163214, 86, 'max', 'kottayam', 'kanjirapally', 'l1.jfif', 1),
(18, 'Arya', 9562540965, 90, 'Karma', 'kottayam', 'kanjirapally', '12.jfif', 1),
(19, 'Karthik', 9544163214, 92, 'Aloha', 'kottayam', 'kanjirapally', '111.jfif', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(20) NOT NULL,
  `category_name` varchar(35) NOT NULL,
  `category_desc` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `category_name`, `category_desc`) VALUES
(1, 'Snacks', 'Branded Foods'),
(2, 'Households', 'Branded Holds'),
(4, 'Vegetables and Fruits', 'Fresh Fruits and Vegetables'),
(5, 'Kitchen', 'Kitchen Wares'),
(6, 'Beverages', 'Soft Drinks and Juices'),
(7, 'Petfood', 'petfood'),
(8, 'Frozen', 'Frozen Snacks'),
(14, 'Bread and Bakery', 'Fresh Breads'),
(21, 'Pickles and staples', 'seed'),
(29, 'Sweets', 'high sugar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart_tbl`
--
ALTER TABLE `cart_tbl`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealer_tbl`
--
ALTER TABLE `dealer_tbl`
  ADD PRIMARY KEY (`dealer_id`);

--
-- Indexes for table `deliveryboy_tbl`
--
ALTER TABLE `deliveryboy_tbl`
  ADD PRIMARY KEY (`dboy_id`);

--
-- Indexes for table `delivery_assign`
--
ALTER TABLE `delivery_assign`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback_db`
--
ALTER TABLE `feedback_db`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `login_tbl`
--
ALTER TABLE `login_tbl`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `mail_sent`
--
ALTER TABLE `mail_sent`
  ADD PRIMARY KEY (`mail_id`);

--
-- Indexes for table `order_db`
--
ALTER TABLE `order_db`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_tbl`
--
ALTER TABLE `order_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_tbl`
--
ALTER TABLE `product_tbl`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`reg_id`);

--
-- Indexes for table `reg_sel_tbl`
--
ALTER TABLE `reg_sel_tbl`
  ADD PRIMARY KEY (`reg_id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart_tbl`
--
ALTER TABLE `cart_tbl`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `dealer_tbl`
--
ALTER TABLE `dealer_tbl`
  MODIFY `dealer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `deliveryboy_tbl`
--
ALTER TABLE `deliveryboy_tbl`
  MODIFY `dboy_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `delivery_assign`
--
ALTER TABLE `delivery_assign`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `enquiry`
--
ALTER TABLE `enquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `feedback_db`
--
ALTER TABLE `feedback_db`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `login_tbl`
--
ALTER TABLE `login_tbl`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `mail_sent`
--
ALTER TABLE `mail_sent`
  MODIFY `mail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `order_db`
--
ALTER TABLE `order_db`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_tbl`
--
ALTER TABLE `order_tbl`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `product_tbl`
--
ALTER TABLE `product_tbl`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `reg_sel_tbl`
--
ALTER TABLE `reg_sel_tbl`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
