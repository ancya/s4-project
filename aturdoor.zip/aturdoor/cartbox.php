<?php 
include 'db.php';
session_start();
$uid = $_SESSION['login_admin'];
$quantity=1;
$sid = $_GET['cid'];

$sql = mysqli_query($conn,"SELECT * FROM product_tbl where product_id='$sid'");
while($row=mysqli_fetch_array($sql)){
    $price=$row['price'];
	$totalprice=$quantity*$price;
}
    $sel="SELECT * FROM `cart_tbl` WHERE `login_id`='$uid' and `product_id`='$sid' and `sts`=0";
	$query1=mysqli_query($conn,$sel);
	// $sql3="UPDATE product_tbl SET quantity=quantity-$quantity where product_id='$sid'";
	// mysqli_query($conn,$sql3);

	$num=mysqli_num_rows($query1);
	if($num > 0)
	{
		echo '<script>alert("product already exits u need to update..!");</script>';
		echo "<script>window.location='carts.php'</script>";
	}
	else{$sql2 = "INSERT INTO cart_tbl(login_id,product_id,quantity,price,total_price) VALUES ($uid,$sid,$quantity,$price,$totalprice)";
	 mysqli_query($conn,$sql2);

     echo"<script>alert('Added to Cart')</script>";
     echo "<script>window.location='carts.php'</script>";
}



?>
 