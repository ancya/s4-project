
<?php
include 'db.php';

if(isset($_POST['submit'])){
	$name=$_POST['Name'];
	$email=$_POST['Email'];
	$pass=$_POST['Password'];
	$phn=$_POST['Phone'];
	$shop=$_POST['shop'];
	$place=$_POST['place'];
    $city=$_POST['city'];
    $image=$_FILES["image"]["name"];
	$sel="SELECT * FROM `login_tbl` WHERE `email`='$email'";
	$query1=mysqli_query($conn,$sel);
	$num=mysqli_num_rows($query1);
	if($num > 0)
	{ 
		echo '<script>alert("Mail already in use..!");</script>';
		echo "<script>window.location='register.php'</script>";
	}
	else{	
	$sq = mysqli_query($conn,"INSERT INTO `login_tbl`(`email`,`password`,`role`,`status`) VALUES ('$email','$pass','seller',0)");

     $rid = mysqli_insert_id($conn);
     $upload_folder="seller/";
     $file_location=$upload_folder.basename($_FILES["image"]["name"]);
     move_uploaded_file($_FILES["image"]["tmp_name"],$file_location);
	$sql = mysqli_query($conn,"INSERT INTO `reg_sel_tbl`(`uname`, `phone`, `login_id`,`shop`,`place`,`city`,`image`,`status`) VALUES ('$name','$phn','$rid','$shop','$place','$city','$image',0)");
    $sql = mysqli_query($conn, "INSERT INTO `dealer_tbl`( `dealer_name`, `email`, `phonenumber`,`login_id`) VALUES ('$name','$email','$phn','$rid')");
    echo '<script>alert("Successfully Registered..!");</script>';
    header("Location:login.php");
	}
}

?>
<!DOCTYPE html>
<html>
<head>
<title>At your door</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Grocery Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all" /> 
<!-- //font-awesome icons -->
<!-- js -->
<script src="js/jquery-1.11.1.min.js"></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
</head>
	
<body>

<!-- products-breadcrumb -->
	<div class="products-breadcrumb">
		<div class="container">
			<ul>
				<li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Home</a><span>|</span></li>
				<li>Sign in</li>
			</ul>
		</div>
	</div>
<!-- //products-breadcrumb -->
<!-- banner -->
	<!--  -->
<!-- login -->
		<div class="w3_login">
			
			<div class="w3_login_module">
				<div class="module form-module">
				  <div class="form">
					<h2>REGISTRATION</h2>
					
					<!-- <script>
        function registration()
            {
        
                var name= document.getElementById("Name").value;
                var email= document.getElementById("Email").value;
                var number= document.getElementById("Phone").value;
                var address=document.getElementById("Address").value;
                var Password= document.getElementById("Password").value;
                var CPassword= document.getElementById("CPassword").value;
                
                
                var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
                var letters = /^[A-Za-z]+$/;
                var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                var phoneno =  /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
                
                if(name=='')
                {
                 
                }
                else if(!letters.test(name))
                {
                    alert('Name field required only alphabet characters');
					return false;
                }

                else if(email=='')
                {
                    alert('Please enter your user email id');
					return false;
                }
                else if(address=='')
                {
                    alert('Please enter your Address');
					return false;
                }
                else if (!filter.test(email))
                {
                    alert('Enter the e-mail format correctly');
					return false;
                }
        else if(Phone=='')
                {
                    alert('Please enter your number');
					return false;
                }
                else if (!validatePhoneNumber(number))
                {
                    alert('Enter the phone format correctly');
					return false;
                }
        
                
                else if(Password=='')
                {
                    alert('Please enter Password');
					return false;
                }
                else if(CPassword=='')
                {
                    alert('Enter Confirm Password');
					return false;
                }
                else if(!pwd_expression.test(Password))
                {
                    alert ('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
					return false;
                }
                else if(Password != CPassword )
                {
                    alert ('Password not Matched');
					return false;
                }
                else if(document.getElementById("Password").value.length < 6)
                {
                    alert ('Password minimum length is 6');
					return false;
                }
                else if(document.getElementById("CPassword").value.length > 12)
                {
                    alert ('Password max length is 12');
					return false;
                }
                else
                {                            
                        return true;
                    
                }
            }

			function validatePhoneNumber(input_str) {
    var re = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;

    return re.test(input_str);
}

function validateForm(event) {
    var phone = document.getElementById('myform_phone').value;
    if (!validatePhoneNumber(phone)) {
        document.getElementById('phone_error').classList.remove('hidden');
    } else {
        document.getElementById('phone_error').classList.add('hidden');
        alert("validation success")
    }
    event.preventDefault();
}
            </script>
             <script>		
function Validate() 
{
    var val = document.getElementById('Name').value;

    if (!val.match(/^[A-Z][A-Za-z/ ]{3,}$/)) 
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets are allowed!!";
		            document.getElementById('lname').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script> -->

				  </div>
				  <div class="form">
					
				  <h2>REGISTRATION</h2>
					<form method="POST" onsubmit="return registration()" enctype="multipart/form-data">

                    <div class="">
						<input type="text" name="Name" id="Name" placeholder="Name" required onchange="Validate()">
                        <span id="msg1" style="color:red;"></span>
                        <script>        
function Validate() 
{
    var val = document.getElementById('Name').value;

    if (!val.match(/^[A-Z][A-Za-z]{3,}$/)) 
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
                    document.getElementById('Name').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script>
</div>



                        <div class="">
						<input type="password" name="Password" id="Password" placeholder="Password" required onchange="Validpass()">
                        <span id="msg2" style="color:red;"></span>
                        <script>        
function Validpass() 
{
    var val = document.getElementById('Password').value;

    if (!val.match(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/)) 
    {
        document.getElementById('msg2').innerHTML="Upper case, Lower case, Special character and Numeric number are required in Password filed";
        
             document.getElementById('Password').value = "";
        return false;
    }
document.getElementById('msg2').innerHTML=" ";
    return true;
}
</script>
</div>



                        <div class="">
						<input type="password" name="CPassword" id="CPassword" placeholder="Confirm Password" required onchange="Validcpass()">
                        <span id="msg3" style="color:red;"></span>
<script>
function Validcpass()
{
var pas1=document.getElementById("Cpassword");
                              var pas2=document.getElementById("Cpassword");
                            
                              if(pas1.value=="")
    {
        document.getElementById('msg3').innerHTML="Password can't be null!!";
        pas1.focus();
        return false;
    }
    if(pas2.value=="")
    {
        document.getElementById('msg3').innerHTML="Please confirm password!!";
        pass2.focus();
        return false;
    }
    if(pas1.value!=pas2.value)
    {
        document.getElementById('msg3').innerHTML="Passwords does not match!!";
        pas1.focus();
        return false;
    }
     document.getElementById('msg3').innerHTML=" "; 
    return true;
}
</script>
</div>

                        
<div class="">
<input type="email" name="Email" id="Email" placeholder="Email" required onchange="Validemail()">
<span id="msg4" style="color:red;"></span>
<script>        
function Validemail() 
{
    var val = document.getElementById('Email').value;

    if (!val.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) 
    {
        document.getElementById('msg4').innerHTML="Enter a Valid Email";
        
             document.getElementById('Email').value = "";
        return false;
    }
document.getElementById('msg4').innerHTML=" ";
    return true;
}
        </script>

</div>

						
                        <div class="">
						<input type="text" name="shop" id="shop" placeholder="Shop Name" required onchange="Validatesname()">
                        <span id="msg5" style="color:red;"></span>
                        <script>        
function Validatesname() 
{
    var val = document.getElementById('shop').value;

    if (!val.match(/^[A-Z][A-Za-z]{3,}$/)) 
    {
        document.getElementById('msg5').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
                    document.getElementById('shop').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}
</script>
</div>
                        
                        
                        
                        <div class="">
						<input type="text" name="Phone" id="Phone" placeholder="Phone No" required onchange="Validmobile()">
                        <span id="msg6" style="color:red;"></span>
<script>
function Validmobile() 
{
    var val = document.getElementById('Phone').value;

    if (!val.match(/^[789][0-9]{9}$/))
    {
        document.getElementById('msg6').innerHTML="Only Numbers are allowed and must contain 10 number";
    
        
                    document.getElementById('phone').value = "";
        return false;
    }
document.getElementById('msg6').innerHTML=" ";
    return true;
}
</script>
</div>

                        <!-- <div class="name">PLACE</div>
						<input type="text" name="place" id="place" placeholder="" required=" ">
                         -->
                         <div class="form-group">
                         <div class="name">Place</div>
            <select id="role" name="place" class="form-control" required>
              <option value="select" selected disabled>select</option> 
              <option value="kottayam">Kottayam</option>
              
              </select>
          </div>
          <div class="form-group">
            <div class="name">city</div>
            <?php $query=mysqli_query($conn,"select * from city");
                                          while($row=mysqli_fetch_array($query))
                                          {?>
             <select id="role" name="city" class="form-control" required>
             <option value="select">select</option> 
              <option value="<?php echo $row['city'];?>" ><?php echo $row['city'];?></option> 
              
              
              <option value=""></option>
              <?php } ?>
               
              </select>
          </div>
         
                        <div class="form-row">
                            <div class="name">PROOF</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="form-control" type="file" name="image" id="image">

                                </div>
						<input type="submit" value="Register" name="submit" onClick="registration()">
						
						<div><center><a href="login.php">SIGN IN</a></center></div>
					  </form>
				  </div>
				  <div class="form">
					
				 
			</div>
			<script>
				$('.toggle').click(function(){
				  // Switches the Icon
				  $(this).children('i').toggleClass('fa-pencil');
				  // Switches the forms  
				  $('.form').animate({
					height: "toggle",
					'padding-top': 'toggle',
					'padding-bottom': 'toggle',
					opacity: "toggle"
				  }, "slow");
				});
			</script>
		</div>
<!-- //login -->
		</div>
		<div class="clearfix"></div>
	</div>
<!-- //banner -->

</body>
</html>