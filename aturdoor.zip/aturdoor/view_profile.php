<?php
include 'db.php';
session_start();
error_reporting(0);
$uid = $_SESSION['login_admin'];
if($_SESSION['login_admin']==""){
  header('location:login.php');
}
$sql = mysqli_query($conn,"SELECT * from register where login_id='$uid'");
while($row=mysqli_fetch_array($sql)){
  $name = $row['uname'];
  $id= $row['login_id'];
  $email= $row['email'];
 
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>At your Door</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css_cart/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css_cart/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css_cart/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css_cart/custom.css">
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
      <!-- font-awesome icons -->
    <link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all" /> 
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet">
 
<!-- //font-awesome icons -->
<!-- js -->
<script src="js/jquery-1.11.1.min.js"></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>

</head>

<body>

 <?php 
 include 'hheader.php'
  ?>


  <div class="main-content">
    <!-- Top navbar -->
    <div class="main-content">
    <!-- Top navbar -->
    <nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
      <div class="container-fluid">
        <!-- Brand -->
        <a class="h4 mb-0 text-white text-uppercase d-none d-lg-inline-block" href="" target="_blank">User profile</a>
        <!-- Form -->
        
        <!-- User -->
        <ul class="navbar-nav align-items-center d-none d-md-flex">
          <li class="nav-item dropdown">
            <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <div class="media align-items-center">
                
               
              </div>
            </a>
           
          </li>
        </ul>
      </div>
    </nav>
    <!-- Header -->
    
      </div>
    </div>
    <br>
    <br>
    <!-- Page content -->
    <div class="container-fluid mt--7" >
      <div class="row">
          
        <div class="col-lg-6 order-xl-1" style="margin-left: 280px;">
          <div class="card bg-secondary shadow" style="margin-left: 113px;">
            <div class="card-header bg-white border-0">
              <div class="row align-items-center">
                <div class="col-8">
                    <div style="float:left;">
                  <h3 class="mb-0">My account</h3>
                 </div>
                 
                </div>
                
              </div>
            </div>
            <div class="card-body" style="background:#84c369">
              <form action="Edit_profile.php" method="post">
               
                <?php
                $result = mysqli_query($conn,"SELECT * FROM register where login_id='$uid'");
                $result1 = mysqli_query($conn,"SELECT * FROM login_tbl where login_id='$uid'");
                $raw1 = mysqli_fetch_array($result1);
                                while ($raw = mysqli_fetch_array($result)){ ?>
                <div class="pl-lg-4">
                  <div class="row">
                      
                    <div class="col-md-12">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-username" style="color: #fff;">Username</label>
                        <input type="text" name="uname" class="form-control form-control-alternative" placeholder="Username" value="<?php echo $raw['uname']; ?>" readonly>
                        
                      </div>
                    </div>
                    <div class="col-lg-6">
                     
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-6">
                      
                    </div>
                    
                  </div>
                </div>
                <hr class="my-4">
                <!-- Address -->
         
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-address" style="color: #fff;">Address</label>
                        <input name="address" class="form-control form-control-alternative" placeholder="Home Address" value="<?php echo $raw['address']; ?>" type="text">
                      </div>
                    </div>
                  </div>
                  <hr class="my-4">
                
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-address" style="color: #fff;">Mobile Number</label>
                        <input name="phone" class="form-control form-control-alternative" placeholder="Mobile Number" value="<?php echo $raw['phonenumber']; ?>" type="text">
                      </div>
                    </div>
                  </div>
                  <hr class="my-4">
               
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-address" style="color: #fff;">Email</label>
                        <input name="email" class="form-control form-control-alternative" placeholder="Home Address" value="<?php echo $raw1['email']; ?>" type="text"readonly>
                      </div>
                    </div>
                
                <hr class="my-4">
               
              <?php } ?>
              <div>
                  <button class="btn btn-primary" style=" margin-left: 44px;" type="submit" name="submit">Edit profile</button>
                   </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="clearfix"> </div>
			<div class="agile_footer_grids">
				<div class="col-md-3 w3_footer_grid agile_footer_grids_w3_footer">
					<div class="w3_footer_grid_bottom">
						
						
					</div>
				</div>
				<div class="col-md-3 w3_footer_grid agile_footer_grids_w3_footer">
					<div class="w3_footer_grid_bottom">
						
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="wthree_footer_copy">
				<p>© 2016 Grocery Store. All rights reserved | Design by <a href="http://w3layouts.com/">W3layouts</a></p>
			</div>
    
 

    
</body>

</html>