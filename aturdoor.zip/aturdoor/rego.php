
<?php
include 'db.php';

if(isset($_POST['submit'])){
	$name=$_POST['Name'];
	$email=$_POST['Email'];
	$pass=$_POST['Password'];
	$phn=$_POST['Phone'];
	$add=$_POST['Address'];
	$place=$_POST['place'];
	$sel="SELECT * FROM `login_tbl` WHERE `email`='$email'";
	$query1=mysqli_query($conn,$sel);
	$num=mysqli_num_rows($query1);
	if($num > 0)
	{
		echo '<script>alert("Mail already in use..!");</script>';
		echo "<script>window.location='register.php'</script>";
	}
	else{	
	$sq = mysqli_query($conn,"INSERT INTO `login_tbl`(`email`,`password`,`role`,`status`) VALUES ('$email','$pass','user',0)");

     $rid = mysqli_insert_id($conn);
	$sql = mysqli_query($conn,"INSERT INTO `register`(`uname`, `phonenumber`, `login_id`,`address`,`place`) VALUES ('$name','$phn','$rid','$add','$place')");
    header("Location:verifymail2.php?eml=$email");
	}
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Grocery Store a Ecommerce Online Shopping Category Flat Bootstrap Responsive Website Template | Sign In & Sign Up :: w3layouts</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Grocery Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all" /> 
<!-- //font-awesome icons -->
<!-- js -->
<script src="js/jquery-1.11.1.min.js"></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
</head>
	
<body>

<!-- products-breadcrumb -->
	<div class="products-breadcrumb">
		<div class="container">
			<ul>
				<li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Home</a><span>|</span></li>
				<li>Sign up</li>
			</ul>
		</div>
	</div>
<!-- //products-breadcrumb -->
<!-- banner -->
	<!--  -->
<!-- login -->
		<div class="w3_login">
			
			<div class="w3_login_module">
				<div class="module form-module">
				  <div class="form">
					<h2>REGISTRATION</h2>
					
					<script>
        function registration()
            {
        
                var name= document.getElementById("Name").value;
                var email= document.getElementById("Email").value;
                var number= document.getElementById("Phone").value;
                var address=document.getElementById("Address").value;
                var Password= document.getElementById("Password").value;
                var CPassword= document.getElementById("CPassword").value;
                
                
                var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
                var letters = /^[A-Za-z]+$/;
                var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                var phoneno =  /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
                
                if(name=='')
                {
                 
                }
                else if(!letters.test(name))
                {
                    alert('Name field required only alphabet characters');
					return false;
                }

                else if(email=='')
                {
                    alert('Please enter your user email id');
					return false;
                }
                else if(address=='')
                {
                    alert('Please enter your Address');
					return false;
                }
                else if (!filter.test(email))
                {
                    alert('Enter the e-mail format correctly');
					return false;
                }
        else if(Phone=='')
                {
                    alert('Please enter your number');
					return false;
                }
                else if (!validatePhoneNumber(number))
                {
                    alert('Enter the phone format correctly');
					return false;
                }
        
                
                else if(Password=='')
                {
                    alert('Please enter Password');
					return false;
                }
                else if(CPassword=='')
                {
                    alert('Enter Confirm Password');
					return false;
                }
                else if(!pwd_expression.test(Password))
                {
                    alert ('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
					return false;
                }
                else if(Password != CPassword )
                {
                    alert ('Password not Matched');
					return false;
                }
                else if(document.getElementById("Password").value.length < 6)
                {
                    alert ('Password minimum length is 6');
					return false;
                }
                else if(document.getElementById("CPassword").value.length > 12)
                {
                    alert ('Password max length is 12');
					return false;
                }
                else
                {                            
                        return true;
                    
                }
            }

			function validatePhoneNumber(input_str) {
    var re = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;

    return re.test(input_str);
}

function validateForm(event) {
    var phone = document.getElementById('myform_phone').value;
    if (!validatePhoneNumber(phone)) {
        document.getElementById('phone_error').classList.remove('hidden');
    } else {
        document.getElementById('phone_error').classList.add('hidden');
        alert("validation success")
    }
    event.preventDefault();
}
            </script>

				  </div>
				  <div class="form">
					
				  <h2>REGISTRATION</h2>
					<form method="POST" onsubmit="return registration()">
						<input type="text" name="Name" id="Name" placeholder="Name" required=" ">
						<input type="password" name="Password" id="Password" placeholder="Password" required=" ">
						<input type="password" name="CPassword" id="CPassword" placeholder="Confirm Password" required=" ">

						<input type="email" name="Email" id="Email" placeholder="Email Address" required=" ">
						<input type="text" name="Address" id="Address" placeholder="Address" required=" ">
						<input type="text" name="Phone" id="Phone" placeholder="Phone Number" required=" ">
						<input type="text" name="place" id="place" placeholder="place" required=" ">
						
						<input type="submit" value="Register" name="submit" onClick="registration()">
						
						<div><center><a href="login.php">SIGN IN</a></center></div>
					  </form>
				  </div>
				  <div class="form">
					
				 
			</div>
			<script>
				$('.toggle').click(function(){
				  // Switches the Icon
				  $(this).children('i').toggleClass('fa-pencil');
				  // Switches the forms  
				  $('.form').animate({
					height: "toggle",
					'padding-top': 'toggle',
					'padding-bottom': 'toggle',
					opacity: "toggle"
				  }, "slow");
				});
			</script>
		</div>
<!-- //login -->
		</div>
		<div class="clearfix"></div>
	</div>
<!-- //banner -->

</body>
</html>