<?php
session_start();
include('db.php');
$ff=$_SESSION['login_admin'];
$dy = date("Y-m-d h:i:s");
mysqli_query($conn,"UPDATE `time_tbl` SET `outtime`='$dy',`status`=0 WHERE `login_id`='$ff'");
session_destroy();
header('Location:index.php');
?>