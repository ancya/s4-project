<?php
include 'dbd.php';

session_start();
$ff=$_SESSION['login_admin'];
 $name=$_GET['oid'];

 $a = mysqli_query($con,"UPDATE `order_tbl` SET `status`='ready' WHERE id = '$name'");
//  $sql = mysqli_query($con,"INSERT INTO `delivery_assign`(`customer_name`,`address`,`phone`,`price`, `assigned_db`, `status`) VALUES ('$name','$add','$phone','$total','ready to ship')");
     echo "<script>alert('Approved for Delivery boy')</script>";
 echo "<script>window.location='view_orders.php';</script>";



?>