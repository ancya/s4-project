<?php
include 'dbd.php';
$day = date("d");
$month = date("m-Y");
$mn = date("m");
echo $day."<br>";
echo $month;
$sq = mysqli_query($con,"SELECT SUM(order_tbl.price) as total,product_tbl.owner_id FROM `order_tbl` join cart_tbl on cart_tbl.orderid=order_tbl.id join product_tbl on product_tbl.product_id=cart_tbl.product_id where order_tbl.date like '%-08-%' GROUP BY product_tbl.owner_id ORDER BY product_tbl.owner_id desc");
$sql = mysqli_query($con,"SELECT * FROM `adminpay` WHERE `days`='$month'");
if(mysqli_num_rows($sql)<1){
    while ($row = mysqli_fetch_assoc($sq)) {
        $ow = $row['owner_id'];
        $as = $row['total'];
        $fnl = ($as/100)*10;
        mysqli_query($con,"INSERT INTO `adminpay`(`ownerid`, `days`, `total`, `amount`, `status`) VALUES 
                 ('$ow','$month','$as','$fnl',0)");
    }
    header("location:login.php");
}
?>