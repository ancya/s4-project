<?php
include 'dbd.php';
session_start();
error_reporting(0);
$ff=$_SESSION['login_admin'];

if($_SESSION['login_admin']==""){
    header('location:login.php');
  }
$ann=mysqli_query($con,"SELECT * from dealer_tbl where login_id='$ff'");
$rows = mysqli_fetch_array($ann);
$rr=$rows['login_id'];
$oid = $_GET['sid'];
if(isset($_POST['assign'])){
 
 
   // $name=$_POST['uid'];
    //$add=$_POST['aid'];
    //$phone=$_POST['pid'];
    //$total=$_POST['tid'];

    $a = mysqli_query($con,"UPDATE `order_tbl` SET `status`='ready' WHERE sts = 0");
	//$sql = mysqli_query($con,"INSERT INTO `delivery_assign`(`customer_name`,`address`,`phone`,`price`, `assigned_db`, `status`) VALUES ('$name','$add','$phone','$total','ready to ship')");
		echo "<script>alert('Deliver Boy Assigned')</script>";
}


?>


<!doctype html>
<html lang="en">
  <head>
  	<title>Orders</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="style.css">

	</head>
	<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-4">
					<h2 class="heading-section">View Orders</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-primary">
						    <tr>
                           
                            <th>User Name</th>
                            <th>Image</th>
						    <th>Address</th>  
						      <th>Phone Number</th>
					         <th>Product Name</th>
						      <th>Quantity</th>
                              <th>Total</th>
                            

						    </tr>
						  </thead>
						  <tbody>
                          <?php
                 
            $result = mysqli_query($con, "SELECT *
            FROM register
            INNER JOIN order_tbl ON register.login_id = order_tbl.login_id
            INNER JOIN cart_tbl ON order_tbl.id = cart_tbl.orderid
            INNER JOIN product_tbl ON cart_tbl.product_id = product_tbl.product_id where cart_tbl.orderid='$oid'");
                                while ($raw = mysqli_fetch_assoc($result)){
                                     ?>
						    <tr class="alert" role="alert">
                           
                            <td class="email"><?php echo $raw['uname']; ?></td>
                            <td class="email">
						    		<div class="img" style="background-image: url(productimages/<?php echo $raw['image']; ?>);"></div>
                                   
                                </td>
                            <td class="email"><?php echo $raw['address']; ?></td>
                            <td class="email"><?php echo $raw['phonenumber']; ?></td>
                            
            
						    	<td class="email">
						    	
                                    <span><?php echo $raw['product_name']; ?> </span>
                                </td>
                                 
						      <td>
						      	<div class="email">
						      	<span style="color:black;"><?php echo $raw['quantity']; ?> </span>
						    
						      	</div>
						      </td>
						      <td><?php echo $raw['total_price']; ?></td>
                              <form action="" method="POST">
                              <input type="hidden" name="uid" value="<?php echo $raw['uname']; ?>">
                              <input type="hidden" name="aid" value="<?php echo $raw['address']; ?>">
                              <input type="hidden" name="pid" value="<?php echo $raw['phonenumber']; ?>">
                              <input type="hidden" name="tid" value="<?php echo $raw['total_price']; ?>">

                              <form>
                            
						      	
				        	  <?php } ?> 
                                
                               
						    </tr>
                         

						   

						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>

