<?php 
@session_start();
$uid = $_SESSION['login_admin'];
include 'dbd.php';
$sql5 = mysqli_query($con, "SELECT * FROM `login_tbl` INNER join dealer_tbl on login_tbl.login_id = dealer_tbl.login_id where dealer_tbl.login_id='$uid'");
$sql4 = mysqli_fetch_array($sql5);
$sq7 = $sql4['dealer_name'];
$ab = mysqli_query($con,"SELECT * FROM `adminpay` where ownerid='$uid' and status='0'");
$ac = mysqli_query($con,"SELECT * FROM `product_tbl` where quantity<5 and owner_id='$uid' ORDER by quantity ASC");
?>
<style>
.dropbtn {
  background-color: transparent;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}
</style>
<style>
	.popupdiv {
                display: none;
                position: fixed; /* Stay in place */
                z-index: 1; /* Sit on top */
                padding-top: 100px; /* Location of the box */
                left: 0;
                top: 0;
                width: 100%; /* Full width */
                height: 100%; /* Full height */
                overflow: auto; /* Enable scroll if needed */
                background-color: rgb(0,0,0); /* Fallback color */
                background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            }
            .divimg{
                background-color: black;
            }
			.overlay {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(8, 8, 8, 0.7);
    transition: opacity 500ms;
    visibility: hidden;
    opacity: 0;
  }
  .overlay:target {
    visibility: visible;
    opacity: 1;
  }
  
  .popup {
    margin: 70px auto;
    padding: 20px;
    background: rgb(255, 255, 255);
    text-align: center;
    border-radius: 0;
    border: 5px solid #000000;
    width: 30%;
    height: relative;
    position: relative;
    transition: all 5s ease-in-out;
  }
  
  .popup h2 {
    margin-top: 0;
    color: #333;
    font-family: 'Times New Roman';
  }
  .popup .close {
    position: absolute;
    top: 20px;
    right: 30px;
    transition: all 20ms;
    font-size: 30px;
    font-weight: bold;
    text-decoration: none;
    color: rgb(0, 0, 0);
  }
  .popup .close:hover {
    color: #080808;
  }
  .popup .content {
    width: 100%;
    overflow: auto;
  }
  @media screen and (max-width: 700px){
    .box{
      width: 70%;
    }
    .popup{
      width: 70%;
    }
  }

</style>
<script>
            function close() {
            document.getElementById("userpopup").style.display = "none";
            }
			function show(){
                document.getElementById("userpopup").style.display = "block";

			}

</script>
<div class="popupdiv" id="userpopup">
                <div class="popup">
                    <h1>important</h1><br>
				<div class="alert alert-success" role="alert">
          <center>
          <table style="text-align:center">
            <tr>
              <th>Product</th>
              <th>Quantity</th>
            </tr>
            <?php while($qw=mysqli_fetch_assoc($ac)){ ?>
            <tr>
              <td style="<?php if($qw['quantity']>0){ ?>color:red<?php } ?>"><?php echo $qw['product_name']?></td>
              <td style="text-align:center;<?php if($qw['quantity']>0){ ?>color:red<?php } ?>"><?php echo $qw['quantity']?></td>
            </tr>
            <?php } ?>
          </table><br>
        
          <a href="viwpro.php" class="btn">Update</a></center>
					<h5>
				</div>
				
                    <a class="close" href="javascript:close()">&times;</a>
                    <div class="content">
                            <div class="col-sm-6">
                            </div>
                            <div class="col-sm-6">
                            </div>
                    </div>
                </div>
            </div>
<div class="topbar">
    <div class="toggle" onclick="toggleMenu()"></div>
    <div class="search">
        <label>
            <input type="text" placeholder="Search here">
            <i class="fa fa-search" aria-hidden="true"></i>
</label>
    </div><div class="dropdown">
  <button class="dropbtn">
    <?php if(mysqli_num_rows($ab)>0){ ?>
          <b style="margin-left:100px;"> <a href="viewpay.php" style="text-decoration:none; color:red"> Due </a></b>
        <?php } ?></button>
  <div class="dropdown-content">
          <i>Pay below dues</i>
                          <?php
                 
            $resul = mysqli_query($con, "SELECT *
            FROM adminpay where ownerid='$ff' and `status`=0"); 
                                while ($raw = mysqli_fetch_assoc($resul)){
                                     ?>
    <a href="payy.php?cid=<?php echo $raw['adminpay_id']; ?>"><?php echo $raw['days']; ?> - ₹<?php echo $raw['amount']; ?></a>
    <hr>
    <?php } ?>
    <a href="viewpay.php">View all dues</a>
  </div>
</div>
<a href="#" onclick="show();" style=" text-decoration:none;"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bell" viewBox="0 0 16 16">
  <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2zM8 1.918l-.797.161A4.002 4.002 0 0 0 4 6c0 .628-.134 2.197-.459 3.742-.16.767-.376 1.566-.663 2.258h10.244c-.287-.692-.502-1.49-.663-2.258C12.134 8.197 12 6.628 12 6a4.002 4.002 0 0 0-3.203-3.92L8 1.917zM14.22 12c.223.447.481.801.78 1H1c.299-.199.557-.553.78-1C2.68 10.2 3 6.88 3 6c0-2.42 1.72-4.44 4.005-4.901a1 1 0 1 1 1.99 0A5.002 5.002 0 0 1 13 6c0 .88.32 4.2 1.22 6z"/>
  <?php if(mysqli_num_rows($ac)>0){ ?><i style="margin-left:-5px; color:red; font-size:20px;" >*<?php echo mysqli_num_rows($ac); ?></i><?php } ?>
</svg></a>	
    <?php echo $sq7; ?>
    


</div>