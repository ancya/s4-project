<?php
include 'dbd.php';
$su_id=$_GET['sid'];
$sts=$_GET['sts'];

if ($sts == 0) {
    mysqli_query($con,"UPDATE `deliveryboy_tbl` SET `status` = 1 WHERE `login_id` ='$su_id'");
    mysqli_query($con,"UPDATE `login_tbl` SET `status` = 1 WHERE `login_id` ='$su_id'");
    echo "<script> alert('Verified Delivery Boy!!'); window.location.href='view_deliverboy.php';</script>";
} 
else
 {
mysqli_query($con,"UPDATE `deliveryboy_tbl` SET `status` = 0 WHERE `login_id` ='$su_id'");
echo "<script> alert('Reject Delivery Boy!!'); window.location.href='view_deliverboy.php';</script>";
 }
  

    
?>