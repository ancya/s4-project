<?php
session_start();
// error_reporting(0);
$uid = $_SESSION['login_admin'];
include('dbd.php');	

if($_SESSION['login_admin']==""){
    header('location:login.php');
  }
if(isset($_POST['submit']))
{
	$category=$_POST['category'];
	$productname=$_POST['productname'];
	$productprice=$_POST['price'];
	$productdescription=$_POST['description'];
    $shop=$_POST['shop'];
    $mdate=$_POST['mdate'];
    $edate=$_POST['edate'];
    
    //$productimage=$_FILES["image"]["name"];
    //$productimage1=$_FILES["image1"]["name"];

    $countfiles=count($_FILES['file']['name']);
    for($i=0;$i<$countfiles;$i++){
        $filename=$_FILES['file']['name'][$i];
        move_uploaded_file($_FILES['file']['tmp_name'][$i],'productimages/'.$filename);
        $img1 = $_FILES['file']['name'][0];
        $img2 = $_FILES['file']['name'][1];
    }
    $quantity=$_POST['quantity'];
 
  
    // $query=mysqli_query($con,"select max(product_id) as product_id from product_tbl");
	// $result=mysqli_fetch_array($query);
	// $productid=$result['product_id']+1;
	// $dir="dealer/productimages/$productid/";
    

    $sel="SELECT * FROM `product_tbl` WHERE `product_name`='$productname'";
	$query1=mysqli_query($con,$sel);
	$num=mysqli_num_rows($query1);
	if($num > 0)
	{
		echo '<script>alert("product already exist..!");</script>';
		echo "<script>window.location='insert_product.php'</script>";
	}
else
	{
        //move_uploaded_file($_FILES["image"]["tmp_name"],"productimages/".$_FILES["image"]["name"]);
        //move_uploaded_file($_FILES["image"]["tmp_name"],"productimages/".$_FILES["image1"]["name"]);
     $sql=mysqli_query($con,"insert into product_tbl(product_name,type,description,shop,availability,price,quantity,status,owner_id,mdate,edate) values('$productname','$category','$productdescription','$shop','Avaliable','$productprice','$quantity',1,'$uid','$mdate','$edate')");
     $rid = mysqli_insert_id($con);
     $sq = mysqli_query($con,"UPDATE `product_tbl` SET `image`='$img1',`image1`='$img2' WHERE `product_id`='$rid'");

    }
}
?>

<!DOCTYPE html>

<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo.jpg">

    <!-- Title Page-->
    <title>At Ur Door.</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i"
        rel="stylesheet">

    <!-- Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <!-- Main CSS-->
    <link href="css_add/main.css" rel="stylesheet" media="all">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">


   
</head>

<body>
    <div class="header">
    <div class="home">
        <label>
            <a href="dealer1.php"><i class="fa fa-home" aria-hidden="true" style="margin: 20px;font-size: xx-large;text-decoration:none"></i></a>
            
        </label>
       
</div>
    <div class="page-wrapper bg-gra-03 p-t-45 p-b-50" style="background-color: #f5f5f5;">
        <div class="wrapper wrapper--w790">
            <div class="card card-5">
                <div class="card-heading" style="background-color: #65d333;;">
                    <h2 class="title">ADD PRODUCTS</h2>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="form-row m-b-55">
                            <div class="name">Product Name</div>
                            <div class="value">
                                <div class="row row-space">
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" id="lname" type="text" name="productname"
                                                style="width: 494px;"required onchange="Validate()">
                                                
                                            <!-- <label class="label--desc">product name</label> -->
                                            <span id="msg1" style="color:red;"></span>
                                            <script>        
function Validate() 
{
    var val = document.getElementById('productname').value;

    if (!val.match(/^[A-Z][A-Za-z]{3,}$/)) 
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
                    document.getElementById('productname').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="name">Category</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <select name="category">
                                        <option value="">Select Category</option>
                                            <?php $query=mysqli_query($con,"select * from tbl_category");
                                          while($row=mysqli_fetch_array($query))
                                          {?>

                                            <option value="<?php echo $row['id'];?>"><?php echo $row['category_name'];?>
                                            </option>
                                            <?php } ?>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Price</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="price">

                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Description</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="description" style="height: 119px;">
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Shop Name</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="shop" id="shop" style="height: 119px;" required onchange="Validatename()">
                                    <span id="msg" style="color:red;"></span>
                        <script>        
function Validatename() 
{
    var val = document.getElementById('shop').value;

    if (!val.match(/^[A-Z][A-Za-z]{3,}$/)) 
    {
        document.getElementById('msg').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
                    document.getElementById('shop').value = "";
        return false;
    }
document.getElementById('msg').innerHTML=" ";
    return true;
}
</script>

                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">manufacture date</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="date" name="mdate">

                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Expiry Date</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="date" name="edate">

                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Image</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="form-control" type="file" name="file[]" id="file" multiple>
                                    <!-- <input type="file" id="files" name="files" multiple><br><br> -->

                                </div>
                            </div>
                            
                        </div>
                        <div class="form-row">
                            <div class="name">Quantity</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="quantity" >
                                </div>
                            </div>
                        </div>
                       


                        <div>
                            <button class="btn btn--radius-2 btn--red" type="submit" name="submit">Add</button>
                            
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>		
function Validate() 
{
    var val = document.getElementById('lname').value;

    if (!val.match(/^[A-Z][A-Za-z/ ]{3,}$/)) 
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets are allowed!!";
		            document.getElementById('lname').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body>

</html>