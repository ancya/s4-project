<?php
include 'dbd.php';
session_start();
error_reporting(0);
$ff=$_SESSION['login_admin'];

if($_SESSION['login_admin']==""){
    header('location:login.php');
  }

// $ann=mysqli_query($con,"SELECT * from adminpay where owner_id='$ff'");
// $rows = mysqli_fetch_array($ann);

?>


<!doctype html>
<html lang="en">
  <head>
  	<title>Orders</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="style.css">

	</head>
	<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-4">
					<h2 class="heading-section">View payment</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-primary">
						    <tr>
                           
                            <th>month of payment</th>
                            <th>Total</th>  
                            <th>Amount to pay</th>
                            <th>payment</th>
						  
						     

						    </tr>
						  </thead>
						  <tbody>
                          <?php
                 
            $result = mysqli_query($con, "SELECT *
            FROM adminpay where ownerid='$ff' and `status`=0"); 
          
                                while ($raw = mysqli_fetch_assoc($result)){
                                     ?>
						    <tr class="alert" role="alert">
                           
                            <td class="email"><?php echo $raw['days']; ?></td>
                           
                            <td class="email"><?php echo $raw['total']; ?></td>
                            <td class="email"><?php echo $raw['amount']; ?></td>
                           <td> <button><a href="payy.php?cid=<?php echo $raw['adminpay_id']; ?>">pay</a></button></td>
            
						    	
						      	</div>
						      </td>
						      <td><?php echo $raw['total_price']; ?></td>
                              <form action="" method="POST">
                              <input type="hidden" name="uid" value="<?php echo $raw['days']; ?>">
                              <input type="hidden" name="aid" value="<?php echo $raw['amount']; ?>">
                              <input type="hidden" name="pid" value="<?php echo $raw['total']; ?>">
                             

                              <form>
                            
						      	
				        	  <?php } ?> 
                                
                               
						    </tr>
                         

						   

						  </tbody>
						</table>
                        
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>

