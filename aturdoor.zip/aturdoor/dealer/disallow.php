<?php
include 'dbd.php';

session_start();
$ff=$_SESSION['login_admin'];
 $ft=$_GET['oid'];

 $a = mysqli_query($con,"UPDATE `coupon_tbl` SET `status`='unvalid' WHERE id = '$ft'");
//  $sql = mysqli_query($con,"INSERT INTO `delivery_assign`(`customer_name`,`address`,`phone`,`price`, `assigned_db`, `status`) VALUES ('$name','$add','$phone','$total','ready to ship')");
 echo "<script>alert('Coupon Disallowed')</script>";
 echo "<script>window.location='viewcoupon.php';</script>";



?>