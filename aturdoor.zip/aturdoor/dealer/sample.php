<?php
include 'dbd.php';

if(isset($_POST['assign'])){
 
 
   // $name=$_POST['uid'];
    //$add=$_POST['aid'];
    //$phone=$_POST['pid'];
    //$total=$_POST['tid'];

    $a = mysqli_query($con,"UPDATE `order_tbl` SET `status`='ready' WHERE sts = 0");
	//$sql = mysqli_query($con,"INSERT INTO `delivery_assign`(`customer_name`,`address`,`phone`,`price`, `assigned_db`, `status`) VALUES ('$name','$add','$phone','$total','ready to ship')");
		echo "<script>alert('Deliver Boy Assigned')</script>";
}


?>


<!doctype html>
<html lang="en">
  <head>
  	<title>Orders</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="style.css">

	</head>
	<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-4">
					<h2 class="heading-section">View Orders</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-primary">
						    <tr>
                           
                            <th>User Name</th>
						    <th>Address</th>  
						      <th>Phone Number</th>
                              <th>Total</th>
                              <th>Status</th>
                              <th>Details</th>
                              <th>Approve</th>
                            

						    </tr>
						  </thead>
						  <tbody>
                          <?php
                 
            $result = mysqli_query($con, "SELECT * from order_tbl join register on order_tbl.login_id = register.login_id
                           where order_tbl.status='placed'");
                                while ($raw = mysqli_fetch_assoc($result)){
                                     ?>
						    <tr class="alert" role="alert">
                           
                            <td class="email"><?php echo $raw['uname']; ?></td>
                            <td class="email"><?php echo $raw['address']; ?></td>
                            <td class="email"><?php echo $raw['phonenumber']; ?></td>
						      <td><?php echo $raw['price']; ?></td>
                              <td><?php echo $raw['status']; ?></td>
                              <td><a href="view_prod.php?sid=<?php echo $raw['id']; ?>" style="color:blue">View</a></td>
                              <form action="" method="POST">
                              <input type="hidden" name="uid" value="<?php echo $raw['uname']; ?>">
                              <input type="hidden" name="aid" value="<?php echo $raw['address']; ?>">
                              <input type="hidden" name="pid" value="<?php echo $raw['phonenumber']; ?>">
                              <input type="hidden" name="tid" value="<?php echo $raw['price']; ?>">

                             
                              <td>
                                   <!-- <select name="category" style="width:77px">
                                        <option value="" >select</option>
                                            <?php 
                                            //$query=mysqli_query($con,"select * from deliveryboy_tbl");
                                          //while($row=mysqli_fetch_array($query))
                                          //{?>
                                            <option value="<?php //echo $row['dboy_id'];?>"><?php //echo $row['dname'];?>
                                            </option>
                                            <?php 
                                          //} ?>
                                        </select> -->
                                   <input type="submit" name="assign" value="Approve">
                              </td>
                              <form>
                            
						      	
				        	  <?php } ?> 
                                
                               
						    </tr>
                         

						   

						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>

