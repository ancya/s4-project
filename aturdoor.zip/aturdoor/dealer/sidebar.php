<?php

?>
<div class="container">
    <div class="navigation">
        <ul>
            <li style="margin-top:10px;">
                <a href="admin.php">
                    <span class="icon"><i class="fa fa-shopping-cart" aria-hidden="true"></i></span>
                    <span class="title">
                        <h2>At Your Door</h2>
                    </span>
                </a>
            </li>
            <li class="li_list">
                <a href="dealer1.php">
                    <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <span class="title">Dashboard</span>
                </a>
            </li>
            <li class="li_list">
                <a href="insert_product.php">
                    <span class="icon"><i class="fa fa-user" aria-hidden="true"></i></span>
                    <span class="title">Add Products</span>
                </a>
            </li>  <li class="li_list">
                <a href="viwpro.php">
                    <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <span class="title">Manage products</span>
                </a>
            </li>
            </li>  <li class="li_list">
                <a href="adddeliveryboy.php">
                    <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <span class="title">Add Delivery Boy</span>
                </a>
            </li>
            </li>  <li class="li_list">
                <a href="coupon.php">
                    <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <span class="title">Add coupon</span>
                </a>
            </li>
            <!-- <li class="li_list">
                <a href="edit_details.php">
                    <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <span class="title">edit/update products</span>
                </a>
            </li> -->
            <li class="li_list">
                <a href="viewcoupon.php">
                    <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <span class="title">View Orders</span>
                </a>
            </li>
           
            <li class="li_list">
                <a href="view_deliverboy.php">
                    <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <span class="title">view delivery boy</span>
                </a>
            </li>
            <!-- <li class="li_list">
                <a href="view_deliverboy.php">
                    <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <span class="title">edit/manage delivery boy</span>
                </a>
            </li> -->
            <li class="li_list">
                <a href="enquiryc.php">
                    <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <span class="title">enquiry</span>
                </a>
            </li>
         
         
            
            </li>
            <li class="li_list">
                <a href="../logout.php">
                    <span class="icon"><i class="fa fa-sign-out" aria-hidden="true"></i></span>
                    <span class="title">Sign Out</span>
                </a>
            </li>
        </ul>
    </div>