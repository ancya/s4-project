<?php
include 'dbd.php';
error_reporting(0);
session_start();
$ff=$_SESSION['login_admin'];
if($_SESSION['login_admin']==""){
    header('location:login.php');
  }


?>


<!doctype html>
<html lang="en">
  <head>
  	<title>Orders</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <style>
       

        label {
            padding: 12px 12px 12px 0;
            display: inline-block;
        }


        .container {
            border-radius: 5px;
            background-color: #f2f2f2;
			width:100%
        }

        .col-25 {
            float: left;
            width: 15%;
            margin-top: 6px;
        }

        .col-75 {
            float: left;
            width: 75%;
            margin-top: 6px;
        }

        /* Clear floats after the columns */
        .row:after {
            content: "";
            display: table;
            clear: both;
        }
    </style>

	</head>
	<body>
	<
	<section class="ftco-section">
		<div class="container">
		<div class="topbar">
    <div class="toggle" onclick="toggleMenu()" style=" float: left;"></div>
    <div class="search" style=" float: left;">
        <label>
            <input type="text" placeholder="Search here">
           
        </label>

    </div>
    


</div>
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-4">
					
					<h2 class="heading-section" style="margin-top: 10px;">AT UR DOOR</h2>
				</div>
				<div>
				<i class="fa fa-home" aria-hidden="true" style="color: black;margin-top: 24px;font-size: xx-large;"></i>
	          </div>
			  <div style="margin-left: 44px;margin-top: 27px;">
				<a href="Admin/logout.php" style="color: black;margin-top: 24px;">Log Out</a>
	          </div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-primary" style="background-color: #84C639;">
						    <tr>
                           
                            <th>User Name</th>
						    <th>Address</th>  
						      <th>Phone Number</th>
                              <th>Total</th>
                              <th>Status</th>
                              <th>Details</th>
                              <th>Approve</th>
                            

						    </tr>
						  </thead>
						  <tbody>
                          <?php
                 
            $ann=mysqli_query($con,"SELECT * from dealer_tbl where login_id='$ff'");
            $rows = mysqli_fetch_array($ann);
            $rr=$rows['login_id'];
 
$result =mysqli_query($con, "SELECT register.uname, register.phonenumber,register.address,
order_tbl.id,order_tbl.login_id,order_tbl.status,order_tbl.price,
cart_tbl.product_id,cart_tbl.total_price,cart_tbl.quantity,
product_tbl.product_name,product_tbl.image,product_tbl.owner_id
FROM register
INNER JOIN order_tbl ON register.login_id = order_tbl.login_id
INNER JOIN cart_tbl ON order_tbl.id = cart_tbl.orderid
INNER JOIN product_tbl ON cart_tbl.product_id = product_tbl.product_id where product_tbl.owner_id='$rr' and order_tbl.status='placed'");

                                while ($raw = mysqli_fetch_assoc($result)){
                                     ?>
						    <tr class="alert" role="alert">
                           
                            <td class="email"><?php echo $raw['uname']; ?></td>
                            <td class="email"><?php echo $raw['address']; ?></td>
                            <td class="email"><?php echo $raw['phonenumber']; ?></td>
						      <td><?php echo $raw['price']; ?></td>
                              <td><?php echo $raw['status']; ?></td>
                              <td><a href="view_prod.php?sid=<?php echo $raw['id']; ?>" style="color:blue">View</a></td>
                              
                              <form method="POST">
                              <input type="hidden" name="uid" value="<?php echo $raw['id']; ?>">
                              <input type="hidden" name="aid" value="<?php echo $raw['address']; ?>">
                              <input type="hidden" name="pid" value="<?php echo $raw['phonenumber']; ?>">
                              <input type="hidden" name="tid" value="<?php echo $raw['price']; ?>">
                              <td>
                                  <a href="appr_deliveryboy.php?oid=<?php echo $raw['id']; ?>"> <input type="button" name="assign" value="Approve"></a>
                              </td>
                              <form>
                                </tr>
                            
						      	
				        	  <?php } ?> 
                         

						   

						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>

