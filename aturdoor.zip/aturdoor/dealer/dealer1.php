<?php
include 'dbd.php';
session_start();
error_reporting(0);
$ff=$_SESSION['login_admin'];

if($_SESSION['login_admin']==""){
    header('location:login.php');
  }
$ann=mysqli_query($con,"SELECT * from dealer_tbl where login_id='$ff'");
$rows = mysqli_fetch_array($ann);
$rr=$rows['login_id'];
$sql2 = mysqli_query($con, "SELECT register.uname, register.phonenumber,register.address,
order_tbl.id,order_tbl.login_id,order_tbl.status,
cart_tbl.product_id,cart_tbl.total_price,cart_tbl.quantity,
product_tbl.product_name,product_tbl.image,product_tbl.owner_id
FROM register
INNER JOIN order_tbl ON register.login_id = order_tbl.login_id
INNER JOIN cart_tbl ON order_tbl.id = cart_tbl.orderid
INNER JOIN product_tbl ON cart_tbl.product_id = product_tbl.product_id where product_tbl.owner_id='$rr'");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">

</head>

<body>
    <?php include 'sidebar.php'; ?>

    <div class="main">
        <?php include 'topbar.php'; ?>

        <!-- <div class="cardBox">
            <div class="card">
                <div>
                <h2>
                                                <?php
                            $query = "SELECT order_id FROM order_db ORDER BY order_id";  
                            $query_run = mysqli_query($con, $query);
                            $row = mysqli_num_rows($query_run);
                            echo '<h4>'.$row.'</h4>';
                        ?>
                                                </h2>
                    <div class="cardName">Total orders</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-eye" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div> <h2>
                                                <?php
                            $query = "SELECT product_id FROM product_tbl ORDER BY product_id";  
                            $query_run = mysqli_query($con, $query);
                            $row = mysqli_num_rows($query_run);
                            echo '<h4>'.$row.'</h4>';
                        ?>
                                                </h2>
                    
                    <div class="cardName">Sales</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">5</div>
                    <div class="cardName">Comments</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-comment" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">3999</div>
                    <div class="cardName">Earnings</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-inr" aria-hidden="true"></i>
                </div>
            </div>
        </div> -->


        <div class="details">
            <div class="recentOrders">
                <div class="cardHeader">
                    <h2>Recent Orders</h2>
                    <a href="#" class="btn">View All</a>
                </div>
                
                <table>
                <thead>
                        <tr>
                            <td>Name</td>
                            <td>Address</td>
                            <td>Phone</td>
                            <td>Product</td>
                            <td>Image</td>
                            <td>Qunatity</td>
                            <td>Price</td>
                            <!-- <td>date</td -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        while ($row = mysqli_fetch_array($sql2)) { ?>
                        <tr>
                            <td>
                                <h4><?php echo $row['uname']?></h4>
                            </td>
                            
                            <td>
                                <h4><?php echo $row['address']?></h4>
                            </td>
                            <td>
                                <h4><?php echo $row['phonenumber']?></h4>
                            </td>
                            <td>
                                <h4><?php echo $row['product_name']?></h4>
                            </td>
                            <td>
                            <div class="imgBx"><img src="productimages/<?php echo $row['image']; ?>" /></div>
											
                            </td>
                            <td>
                            <?php echo $row['quantity']?>
                            </td>
                            <td>
                            <?php echo $row['total_price']?>
                            </td>

                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        
    </div>

    <script>
        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active')
            main.classList.toggle('active')

        }
    </script>

</body>

</html>