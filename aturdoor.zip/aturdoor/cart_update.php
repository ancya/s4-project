<?php
include 'db.php';
$cartid = $_GET['cid'];
$price = $_GET['pid'];
$productid = $_GET['pro_id'];
$qid = $_GET['qid'];
echo $price;
echo $qid;
$total=$_GET['pid'] * $_GET['qid'];
echo $cartid;
echo "\n";
echo $qid;
echo "\n";
echo $total;
echo "\n";
echo $productid;

$sqll = "UPDATE cart_tbl SET quantity=$qid,total_price=$total where cart_id=$cartid and product_id=$productid";
mysqli_query($conn,$sqll);



?>