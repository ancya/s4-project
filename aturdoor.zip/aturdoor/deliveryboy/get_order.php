<?php
session_start();
include 'db2.php';
$id = $_SESSION['login_admin'];
 $name=$_GET['oid'];
 $st=$_GET['st'];
if($st==1){
    $a = mysqli_query($con,"UPDATE `order_tbl` SET `status`='shipped', del_boy='$id' WHERE id = '$name'");
    //$sql = mysqli_query($con,"INSERT INTO `delivery_assign`(`customer_name`,`address`,`phone`,`price`, `assigned_db`, `status`) VALUES ('$name','$add','$phone','$total','ready to ship')");
        echo "<script>alert('You have been assigned')</script>";
        echo "<script>window.location='deliveryboy1.php';</script>";
}else{
    $a = mysqli_query($con,"UPDATE `order_tbl` SET `status`='delivered' WHERE id = '$name'");
    mysqli_query($con,"UPDATE `deliveryboy_tbl` SET `sts`='active' WHERE `login_id`='$id'");
    echo "<script>alert('{Product delivered}')</script>";
    echo "<script>window.location='mydelivery.php';</script>";
}




?>