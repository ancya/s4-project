<?php

@session_start();
?>
<div class="container">
    <div class="navigation">
        <ul>
            <li style="margin-top:10px;">
                <a href="admin.php">
                    <span class="icon"><i class="fa fa-shopping-cart" aria-hidden="true"></i></span>
                    <span class="title">
                        <h2>At Your Door</h2>
                    </span>
                </a>
            </li>
            <li class="li_list">
                <a href="deliveryboy1.php">
                    <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <span class="title">Dashboard</span>
                </a>
            </li>
          
            
            
            <li class="li_list">
                <a href="mydelivery.php">
                    <span class="icon"><i class="fa fa-info-circle" aria-hidden="true"></i></span>
                    <span class="title">Order History</span>
                </a>
            </li>
            <li class="li_list">
                <a href="edit.php">
                    <span class="icon"><i class="fa fa-cog" aria-hidden="true"></i></span>
                    <span class="title">Edit Details</span>
                </a>
            </li>
            <li class="li_list">
                <a href="feedback.php">
                    <span class="icon"><i class="fa fa-unlock" aria-hidden="true"></i></span>
                    <span class="title">feedback</span>
                </a>
            </li>   
            
            <li class="li_list">
                <a href="logout.php">
                    <span class="icon"><i class="fa fa-sign-out" aria-hidden="true"></i></span>
                    <span class="title">Sign Out</span>
                </a>
            </li>
        </ul>
    </div>