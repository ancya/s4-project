<?php 
include 'db2.php';
session_start();
if($_SESSION['login_admin']==""){
    header('location:login.php');
  }
$sql = mysqli_query($con,"SELECT * FROM `feedback_db` where user_type='deliveryboy'");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="../Admin/css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <?php include 'sidebar.php'; ?>

    <div class="main">
        <?php include 'topbar.php'; ?>
        <div class="disk">

            <h2>Feedbacks</h2>

            <table>
                <tr>
                    <th>Name</th>
                    <th>Subject</th>
                    <th>Feedback</th>
                </tr>
                <?php while ($row = mysqli_fetch_assoc($sql)){ ?>
                <tr>
                    <td><?php echo $row['name']?></td>
                    <td><?php echo $row['subject']?></td>
                    <td><?php echo $row['content']?></td>
                </tr>
                <?php } ?>
            </table>

        </div>
    </div>
    <script>
        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active')
            main.classList.toggle('active')

        }
    </script>

</body>

</html>