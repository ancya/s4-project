<?php
session_start();
$did = $_SESSION['login_admin'];
include 'db2.php';
if($_SESSION['login_admin']==""){
    header('location:../login.php');
  }
$sq =mysqli_query($con,"SELECT pincode FROM `deliveryboy_tbl`where login_id='$did'");
$sqa = mysqli_fetch_array($sq);
@$pls = $sqa['pincode'];
$sql = mysqli_query($con, "SELECT * from order_tbl join register on order_tbl.login_id = register.login_id where order_tbl.del_boy=0 and register.pincode='$pls' and  order_tbl.status='placed' or  order_tbl.status='ready'");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">

</head>

<body>
    <?php include 'sidebar.php'; ?>

    <div class="main">
        <?php include 'topbar.php'; ?>

        <!-- <div class="cardBox">
            <div class="card">
                <div>
                    <div class="numbers">1,042</div>
                    <div class="cardName">Today's order</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-eye" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">208</div>
                    <div class="cardName">Sales</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">5</div>
                    <div class="cardName">Comments</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-comment" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">3999</div>
                    <div class="cardName">Earnings</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-inr" aria-hidden="true"></i>
                </div>
            </div>
        </div> -->


        <div class="details">
            <div class="recentOrders">
                <div class="cardHeader">
                    <h2>Recent Orders</h2>

                    <a href="#" class="btn">View All</a>
                </div>
                <iframe id="google_map" width="100%" height="200" frameborder="0" scrolling="no" marginheight="0"
                        marginwidth="0" src="https://maps.google.co.in?output=embed"></iframe><br>

                 <table>
                    <thead>
                        <tr>
                            <td>Name</td>
                            <td>phno</td>
                            <td>Place</td>
                            <td>Price</td>
                            <td>Status</td>
                            <td>Location</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_array($sql)) { ?>
                            <tr>
                                <td><?php echo $row['uname']?></td>
                                <td><?php echo $row['phonenumber']?></td>
                                <td><?php echo $row['address']?></td>
                                <td><?php echo $row['price']?></td>

                                <input type="hidden" value="<?php echo $row['longittude']?>" id="lon">
                                <input type="hidden" value="<?php echo $row['latitude']?>" id="lat">
                                <?php if ($row['status']=='ready' || $row['status']=='placed'){
                                    ?>
                                    
                                <td><a href="get_order.php?oid=<?php echo $row['id']?>&&st=1" style="text-decoration:none"><span class="status inprogress">Get</span></a></td>
                           <?php }else if($row['status']=='shipped') { ?>
                            
                            <td><a href="get_order.php?oid=<?php echo $row['id']?>&&st=2" style="text-decoration:none"><span class="status return">Deliver</span></a></td>
                            <?php }else{ ?>
                                <td><span class="status delivered">Complete</span></td>
                            <?php }?>
                            <td><button  style="" type="button" onclick="showmap();"> location</button></td>

                            </tr>
                            <!-- <tr>
                            <td>Mango</td>
                            <td>100</td>
                            <td>Due</td>
                            <td><span class="status pending">Pending</span></td>
                        </tr>
                        <tr>
                            <td>Maggi</td>
                            <td>50</td>
                            <td>Paid</td>
                            <td><span class="status return">Return</span></td>
                        </tr>
                        <tr>
                            <td>Sugar</td>
                            <td>40</td>
                            <td>due</td>
                            <td><span class="status delivered">In Progress</span></td>
                        </tr> -->
                        <?php } ?>
                    </tbody>
                </table>

            </div>
            
        </div>
    </div>

    <script>
        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active')
            main.classList.toggle('active')

        }
        function showmap() {

            var lat = document.getElementById('lat').value;
            var lon = document.getElementById('lon').value;
            var coords = lat + ',' + lon;
            document.getElementById("google_map").setAttribute('src', 'https://maps.google.co.in/?q=' + coords + '&output=embed');

        }

    </script>

</body>

</html>