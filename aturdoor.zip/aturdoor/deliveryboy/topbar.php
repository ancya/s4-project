<div class="topbar">
    <div class="toggle" onclick="toggleMenu()"></div>
    <div class="search">
        <label>
            <input type="text" placeholder="Search here">
            <i class="fa fa-search" aria-hidden="true"></i>
        </label>

    </div>Delivery Boy
    <div class="user">
        <img src="https://i.guim.co.uk/img/media/e7562393b67a43b7b2329a6dd2de29f9051ceb12/1550_1862_1943_1166/master/1943.jpg?width=1200&height=1200&quality=85&auto=format&fit=crop&s=845d6980bc11a35266a9441f91ff916e">
    </div>


</div>