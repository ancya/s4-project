<?php
session_start();
include 'db2.php';
$did = $_SESSION['login_admin'];


?>


<!doctype html>
<html lang="en">
  <head>
  	<title>Orders</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="../dealer/style.css">

	</head>
	<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-4">
					<h2 class="heading-section">View Orders</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-primary">
						    <tr>
                           
                            <th>User Name</th>
						    <th>Address</th>  
						      <th>Phone Number</th>
                              <th>Total</th>
                              <th>Status</th>
                              
                              <th>Action</th>
                            

						    </tr>
						  </thead>
						  <tbody>
                          <?php
                 
            $result = mysqli_query($con, "SELECT * from order_tbl join register on order_tbl.login_id = register.login_id
            where order_tbl.del_boy='$did' order by order_tbl.status desc");
                                while ($raw = mysqli_fetch_assoc($result)){
                                     ?>
						    <tr class="alert" role="alert">
                           
                            <td class="email"><?php echo $raw['uname']; ?></td>
                            <td class="email"><?php echo $raw['address']; ?></td>
                            <td class="email"><?php echo $raw['phonenumber']; ?></td>
						      <td><?php echo $raw['price']; ?></td>
                              <td><?php echo $raw['status']; ?></td>
                             <!-- <td><a href="view_prod.php?sid=<?php echo $raw['id']; ?>" style="color:blue">View</a></td>
                               -->
                              <form method="POST">
                              <input type="hidden" name="uid" value="<?php echo $raw['id']; ?>">
                              <input type="hidden" name="aid" value="<?php echo $raw['address']; ?>">
                              <input type="hidden" name="pid" value="<?php echo $raw['phonenumber']; ?>">
                              <input type="hidden" name="tid" value="<?php echo $raw['price']; ?>">
                              <td>
								<?php if($raw['status']=='shipped'){ ?>
                                  <a href="get_order.php?oid=<?php echo $raw['id']?>&&st=2"> <input type="button" name="assign" value="Deliverd"></a>
                                <?php }else{ ?>
									<i style="color:grey">No action</i>
									<?php } ?>
								</td>
                              <form>
                                </tr>
                            
						      	
				        	  <?php } ?> 
                         

						   

						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>

