<?php
include 'db.php';
session_start();
error_reporting(0);
$uid = $_SESSION['login_admin'];
if($_SESSION['login_admin']==""){
  header('location:login.php');
}
$sql = mysqli_query($conn,"SELECT * from register where login_id='$uid'");
while($row = mysqli_fetch_array($sql)){
  $name = $row['uname'];
  $phonenumber = $row['phonenumber'];
  $address= $row['address'];
  
}

if (isset($_POST['btnreply'])) {
	// $name = $_POST['name'];
    $comment = $_POST['Comments'];
   $content = $_POST['content'];
    $subject = $_POST['subject'];

    $as = mysqli_query($conn,"INSERT INTO `feedback_db`( `user_id`,`name`, `subject`, `content`, `user_type`) VALUES ('$uid','$name','$content','$comment','$subject')");
    header("location:home.php");
}

?>
<!DOCTYPE html>
<html>
<head>
<title>@Your door</title>

<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Grocery Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all" /> 
<!-- //font-awesome icons -->
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<!-- js -->
<script src="js/jquery-1.11.1.min.js"></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<style>
	.popupdiv {
                display: none;
                position: fixed; /* Stay in place */
                z-index: 1; /* Sit on top */
                padding-top: 100px; /* Location of the box */
                left: 0;
                top: 0;
                width: 100%; /* Full width */
                height: 100%; /* Full height */
                overflow: auto; /* Enable scroll if needed */
                background-color: rgb(0,0,0); /* Fallback color */
                background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            }
            .divimg{
                background-color: black;
            }
			.overlay {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(8, 8, 8, 0.7);
    transition: opacity 500ms;
    visibility: hidden;
    opacity: 0;
  }
  .overlay:target {
    visibility: visible;
    opacity: 1;
  }
  
  .popup {
    margin: 70px auto;
    padding: 20px;
    background: rgb(255, 255, 255);
    text-align: center;
    border-radius: 0;
    border: 5px solid #000000;
    width: 60%;
    height: 50%;
    position: relative;
    transition: all 5s ease-in-out;
  }
  
  .popup h2 {
    margin-top: 0;
    color: #333;
    font-family: 'Times New Roman';
  }
  .popup .close {
    position: absolute;
    top: 20px;
    right: 30px;
    transition: all 20ms;
    font-size: 30px;
    font-weight: bold;
    text-decoration: none;
    color: rgb(0, 0, 0);
  }
  .popup .close:hover {
    color: #080808;
  }
  .popup .content {
    width: 100%;
    overflow: auto;
  }
  @media screen and (max-width: 700px){
    .box{
      width: 70%;
    }
    .popup{
      width: 70%;
    }
  }

</style>
<script>
            function close() {
            document.getElementById("userpopup").style.display = "none";
            }
			function show(){
                document.getElementById("userpopup").style.display = "block";

			}

</script>
</head>
	
<body>
	
<!-- header -->
	<div class="agileits_header">
		<div class="w3l_offers">
			<a href="offers.php" style="height:45px" >Today's special Offers !</a>
			
			
		
        </div>
		
		<div class="w3l_header_right">
		
		<form class="example" action="search.php" method="POST">
        <input type="text" placeholder="Search.." name="search" >
        <button type="submit"><i class="fa fa-search" ></i></button>
        </form>
				
		
		</div>
		
		
		<!-- <div >    -->
			<!-- <div style="float:left;margin-left:184px">
		<button style=" text-decoration:none;margin-top: 9px; height: 32px; width: 141px; background-color: #fdae04; border: none;font-size: 1.2em;color: #fff;"><a href="view_profile.php" style="text-decoration:none;">View Profile</a></button>
           </div> -->
		   <!-- <div style="float:left;margin-left:10px">
		<button style=" text-decoration:none;margin-top: 9px; height: 32px; width: 141px; background-color: #fdae04; border: none;font-size: 1.2em;color: #fff;"><a href="carts.php" style="text-decoration:none;">View Cart</a></button>
		
         </div>
	      </div>  -->
		  <!-- <div class="container mt-3"> -->

<!-- 
		  <div class="dropdown">
		  <div style="float:right;margin-right:184px">
    <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown"style=" text-decoration:none;margin-top: 20px; height: 32px; width: 141px; background-color: #fdae04; border: none;font-size: 1.2em;color: #fff;">>
      Dropdown button
    </button>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="#">Link 1</a></li>
      <li><a class="dropdown-item" href="#">Link 2</a></li>
      <li><a class="dropdown-item" href="#">Link 3</a></li>
      <li><hr class="dropdown-divider"></li>
      <li><a class="dropdown-item" href="#">Another link</a></li>
    </ul>
  </div>
      </div>
</div> -->



		
		
		
		
		<div class="form-floating">
		
		<div class="w3l_header_right1">
		<div class="popupdiv" id="userpopup">
                <div class="popup">
                    <h1>important</h1><br><br>
					<h3>offers</h3>
				<div class="alert alert-success" role="alert">
					
					<strong>Well done!</strong> You have a special offer.
					<h5><a href="offers.php">click here</a>
				</div>
				
                    <a class="close" href="javascript:close()">&times;</a>
                    <div class="content">
                            <div class="col-sm-6">
                            </div>
                            <div class="col-sm-6">
                            </div>
                    </div>
                </div>
            </div>

			<a href="#" onclick="show();"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bell" viewBox="0 0 16 16">
  <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2zM8 1.918l-.797.161A4.002 4.002 0 0 0 4 6c0 .628-.134 2.197-.459 3.742-.16.767-.376 1.566-.663 2.258h10.244c-.287-.692-.502-1.49-.663-2.258C12.134 8.197 12 6.628 12 6a4.002 4.002 0 0 0-3.203-3.92L8 1.917zM14.22 12c.223.447.481.801.78 1H1c.299-.199.557-.553.78-1C2.68 10.2 3 6.88 3 6c0-2.42 1.72-4.44 4.005-4.901a1 1 0 1 1 1.99 0A5.002 5.002 0 0 1 13 6c0 .88.32 4.2 1.22 6z"/>
</svg></a>	
	<select class="form-select" id="floatingSelect" aria-label="Floating label select example"style=" color: #fff;background-color: #84C639; height: 34px; font-size: -0.26rem;  margin: 7px;text-align: center;font-weight: 500;width:127px" onchange="this.value">
   <option selected><?php echo $name; ?></option>
   <!-- <option>phone:</?php echo $phonenumber; ?></option>
   <option>Address<//?php echo $address; ?></option> -->
   
   </select>
		</div>
</div>



<!-- <div class="w3l_header_right1">
		<div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" ><br>
                            <img class="user-avatar rounded-circle" src="./images/setting.png" alt="User Avatar" height="40px" width="40px"></a>
                            <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="customer_profile.php"><i class="fa fa-user"></i> My Profile</a>
                            <a class="nav-link" href="customer_change_password.php"><i class="fa fa-user"></i>Change Password</a>
                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div></div>
                               -->

	
		
		<div class="clearfix"> </div>
	</div>
<!-- script-for sticky-nav -->
	<script>
	$(document).ready(function() {
		 var navoffeset=$(".agileits_header").offset().top;
		 $(window).scroll(function(){
			var scrollpos=$(window).scrollTop(); 
			if(scrollpos >=navoffeset){
				$(".agileits_header").addClass("fixed");
			}else{
				$(".agileits_header").removeClass("fixed");
			}
		 });
		 
	});
	</script>
<!-- //script-for sticky-nav -->

	<div class="logo_products">
		<div class="container">
			<div class="w3ls_logo_products_left">
				<h1><a href="home.php"><span>@Your</span>Door</a></h1>
				<h4 style="margin left:5px">THE BEST SUPERMARKET</h4>
			</div>
			<div class="w3ls_logo_products_left1">
				<ul class="special_items">
					<!-- <li><a href="events.php" style="color: #84C639;font-size: 15px;font-weigth:bold;">Events</a><i style="padding:15px">/</i></li> -->
					<li><a href="about.php" style="color: #84C639;font-size: 15px;font-weigth:bold;">About Us</a><i style="padding:15px">/</i></li>
					<li><a href="rp.php?sid=<?php echo $uid ?>" style="color: #84C639;font-size: 15px;font-weigth:bold;">feedback reply</a><i style="padding:15px">/</i></li>
					<li><a href="services.php" style="color: #84C639;font-size: 15px;font-weigth:bold;">Services</a><i style="padding:15px">/</i></li>
					<li><a href="carts.php" style="color: #84C639;font-size: 15px;font-weigth:bold;">View cart</a><i style="padding:15px">/</i></li>
					<li><div class="user-area dropdown float-right">
                        <a href="#"  style="color: #84C639;font-size: 15px;font-weigth:bold;" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" ><br>
                           My Account</a>
                            <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="prof.php"><i class="fa fa-user"></i>Profile</a>
							<a class="nav-link" href="myorder.php"><i class="fa fa-user"></i>My order</a>
                            <a class="nav-link" href="change_password.php?id =<?php echo $id ?>"><i class="fa fa-user"></i>Password</a>
                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div></div></li>
</div>
						<div class="w3ls_logo_products_left1">
				<ul class="phone_email">
					<li><i class="fa fa-phone" aria-hidden="true"></i>(+91)7025119890</li>
					<li><i class="fa fa-envelope-o" aria-hidden="true"></i><a href="mailto:atyourdoor.com">atyourdoor.com</a></li>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
					<!-- <li>
                   
                        <div class="dropdown">
                        <a class="nav-link" href="#" style="color: #84C639;font-size: 15px;font-weigth:bold;">My Account<i style="padding:15px">/</i></a>
                        <div class="dropdown-content">
						<ul class="dropdown-menu">
                  
					<li><a class="dropdown-item" href="#">my order</a></li>
					<li><a class="dropdown-item" href="#">alarm</a></li>
					<li><hr class="dropdown-divider"></li>
					<!-- <li><a class="dropdown-item" href="#">Another link</a></li>
                        <a href="signup.php">As User</a>
                        <a href="supplier.php">As Supplier</a> 
                       
                    <!-- </div>
                   </div>

                    
                    </li>  -->
					<!-- <li>
                   
                        <div class="dropdown">
                        <a class="nav-link" href="#" style="color: #84C639;font-size: 15px;font-weigth:bold;">My Profile<i style="padding:15px">/</i></a>
                        <div class="dropdown-content">
						<ul class="dropdown-menu">
						<//?php
						$sql1 = mysqli_query($conn,"SELECT * from register where login_id='$uid'");
						// $sqltt= mysqli_query($conn,"SELECT login_tbl.email from login_tbl where login_id = '$uid'");
						 
						 while ($row = mysqli_fetch_assoc($sql1)){ ?>
							
					<li><a class="dropdown-item" href="#"><b>Name: </b><//?php echo $row['uname']?> <br></a></li>
					<li><a class="dropdown-item" href="#"> <b>Email: </b><//?php echo $sqltt ?> <br></a></li> -->
					<!-- <li><a class="dropdown-item" href="#"> <b>Phone: </b><//?php echo $row['phonenumber']?> <br></a></li>
					<li><a class="dropdown-item" href="#"><b>Address: </b><//?php echo $row['address']?> <br></a></li>
					<div>
					<li><a class="dropdown-item" style="color:red;margin-left: 20px;" href="change_password.php?id =<//?php echo $id ?>" >change password</a></li>
                 
                  
                   </div>
					<li><a class="dropdown-item" href="#"></a></li>
                           
					
                       
                <//?php } ?>
                   --> 
					<!-- <li><a class="dropdown-item" href="#"></a></li> -->
					
					<!-- <li><a class="dropdown-item" href="#">Another link</a></li>
                        <a href="signup.php">As User</a>
                        <a href="supplier.php">As Supplier</a> -->
                       
                    <!-- </div>
                   </div> -->

<!--                     
                    </li> -->

					
					
					
					
					<!-- <li><a href="products.php">my account</a>
					<i>/</i></li>  -->
					<!-- <div class="dropdown">
		  <div style="margin top:5px;">
    
		  <li>
			  my account
					</li>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="#">Link 1</a></li>
      <li><a class="dropdown-item" href="#">Link 2</a></li>
      <li><a class="dropdown-item" href="#">Link 3</a></li>
      <li><hr class="dropdown-divider"></li>
      <li><a class="dropdown-item" href="#">Another link</a></li>
    </ul>
  </div>
      </div>
	  <ul> -->
	  <!-- <li>
                   
                        <div class="dropdown">
                        <a class="nav-link" href="#">REGISTER</a>
                        <div class="dropdown-content">
						<ul class="dropdown-menu">
      <li><a class="dropdown-item" href="#">Link 1</a></li>
      <li><a class="dropdown-item" href="#">Link 2</a></li>
      <li><a class="dropdown-item" href="#">Link 3</a></li>
      <li><hr class="dropdown-divider"></li>
      <li><a class="dropdown-item" href="#">Another link</a></li>
                        <a href="signup.php">As User</a>
                        <a href="supplier.php">As Supplier</a>
                       
                    </div>
                   </div>

                    
                    </li> -->
                    
					<!-- <li><a href="services.php">Services</a><i>/</i></li>
					<li><a href="logout.php">Logout</a></li> -->
					
				<!-- </ul>
			</div> -->
			
<!-- //header -->
<!-- banner -->
	<div class="banner">
		<div class="w3l_banner_nav_left">
			<nav class="navbar nav_bottom">
			 <!-- Brand and toggle get grouped for better mobile display -->
			  <div class="navbar-header nav_2">
				  <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
			   </div> 
			   <!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
				
					<ul class="nav navbar-nav nav_1">
					<?php $query=mysqli_query($conn,"select * from tbl_category");
                                          while($row=mysqli_fetch_array($query))
                                          {?>
					

						<li><a href="frozen.php?cid=<?php echo $row['id'];?>"><?php echo $row['category_name'];?></a></li>
				
						<?php } ?>
					</ul>
					
				 </div><!-- /.navbar-collapse -->
			</nav>
		</div>
		<div class="w3l_banner_nav_right">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="w3l_banner_nav_right_banner">
								<h3>Stay Home <span>And</span> Shop Online</h3>
								<div class="more">
									<!-- <a href="#" class="button--saqui button--round-l button--text-thick" data-text="Shop now">Shop now</a> -->
								</div>
							</div>
						</li>
						<li>
							<div class="w3l_banner_nav_right_banner1">
							<h3>Stay Home <span>And</span> Shop Online</h3>
								<div class="more">
									<!-- <a href="#" class="button--saqui button--round-l button--text-thick" data-text="Shop now">Shop now</a> -->
								</div>
							</div>
						</li>
						<li>
							<div class="w3l_banner_nav_right_banner2">
							<h3>Stay Home <span>And</span> Shop Online</h3>
								<div class="more">
									<!-- <a href="#" class="button--saqui button--round-l button--text-thick" data-text="Shop now">Shop now</a> -->
								</div>
							</div>
						</li>
					</ul>
				</div>
			</section>
			<!-- flexSlider -->
				<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
				<script defer src="js/jquery.flexslider.js"></script>
				<script type="text/javascript">
				$(window).load(function(){
				  $('.flexslider').flexslider({
					animation: "slide",
					start: function(slider){
					  $('body').removeClass('loading');
					}
				  });
				});
			  </script>
			<!-- //flexSlider -->
		</div>
		<div class="clearfix"></div>
	</div>
<!-- banner -->
	<div class="banner_bottom">
			<div class="wthree_banner_bottom_left_grid_sub">
			</div>
			<div class="wthree_banner_bottom_left_grid_sub1">
				<div class="col-md-4 wthree_banner_bottom_left">
					<div class="wthree_banner_bottom_left_grid">
						<img src="images/4.jpg" alt=" " class="img-responsive" />
						<div class="wthree_banner_bottom_left_grid_pos">
							<h4>Monsoon Offer <span>5%</span></h4>
						</div>
					</div>
				</div>
				<div class="col-md-4 wthree_banner_bottom_left">
					<div class="wthree_banner_bottom_left_grid">
						<img src="images/5.jpg" alt=" " class="img-responsive" />
						<div class="wthree_banner_btm_pos">
							<h3>introducing <span>best store</span> for <i>groceries</i></h3>
						</div>
					</div>
				</div>
				<div class="col-md-4 wthree_banner_bottom_left">
					<div class="wthree_banner_bottom_left_grid">
						<img src="images/6.jpg" alt=" " class="img-responsive" />
						<div class="wthree_banner_btm_pos1">
							<h3>Save <span>Upto</span> $10</h3>
						</div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
	</div>
<!-- top-brands -->
	<!-- <div class="top-brands">
		<div class="container">
			<h3>Hot Offers</h3>
			<div class="agile_top_brands_grids">
				<div class="col-md-3 top_brand_left">
					<div class="hover14 column">
						<div class="agile_top_brand_left_grid">
							<div class="tag"><img src="images/tag.png" alt=" " class="img-responsive" /></div>
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block" >
										<div class="snipcart-thumb">
											<a href="single.php"><img title=" " alt=" " src="images/1.png" /></a>		
											<p>fortune sunflower oil</p>
											<h4>100 <span>$10</span></h4>
										</div>
										<div class="snipcart-details top_brand_home_details">
											<form action="#" method="post">
												<fieldset>
													<input type="hidden" name="cmd" value="_cart" />
													<input type="hidden" name="add" value="1" />
													<input type="hidden" name="business" value=" " />
													<input type="hidden" name="item_name" value="Fortune Sunflower Oil" />
													<input type="hidden" name="amount" value="7.99" />
													<input type="hidden" name="discount_amount" value="1.00" />
													<input type="hidden" name="currency_code" value="USD" />
													<input type="hidden" name="return" value=" " />
													<input type="hidden" name="cancel_return" value=" " />
													
												</fieldset>
											</form>
										</div>
									</div>
								</figure>
							</div>
						</div>
					</div>
				</div> -->
				<!-- <div class="col-md-3 top_brand_left">
					<div class="hover14 column">
						<div class="agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block" >
										<div class="snipcart-thumb">
											<a href="single.php"><img title=" " alt=" " src="images/3.png" /></a>		
											<p>basmati rise (5 Kg)</p>
											<h4>$11.99 <span>$15.00</span></h4>
										</div>
										<div class="snipcart-details top_brand_home_details">
											<form action="#" method="post">
												<fieldset>
													<input type="hidden" name="cmd" value="_cart" />
													<input type="hidden" name="add" value="1" />
													<input type="hidden" name="business" value=" " />
													<input type="hidden" name="item_name" value="basmati rise" />
													<input type="hidden" name="amount" value="11.99" />
													<input type="hidden" name="discount_amount" value="1.00" />
													<input type="hidden" name="currency_code" value="USD" />
													<input type="hidden" name="return" value=" " />
													<input type="hidden" name="cancel_return" value=" " />
													
												</fieldset>
											</form>
										</div>
									</div>
								</figure>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3 top_brand_left">
					<div class="hover14 column">
						<div class="agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid_pos">
								<img src="images/offer.png" alt=" " class="img-responsive" />
							</div>
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block">
										<div class="snipcart-thumb">
											<a href="single.php"><img src="images/2.png" alt=" " class="img-responsive" /></a>
											<p>Pepsi soft drink (2 Ltr)</p>
											<h4>$8.00 <span>$10.00</span></h4>
										</div>
										<div class="snipcart-details top_brand_home_details">
											<form action="#" method="post">
												<fieldset>
													<input type="hidden" name="cmd" value="_cart" />
													<input type="hidden" name="add" value="1" />
													<input type="hidden" name="business" value=" " />
													<input type="hidden" name="item_name" value="Pepsi soft drink" />
													<input type="hidden" name="amount" value="8.00" />
													<input type="hidden" name="discount_amount" value="1.00" />
													<input type="hidden" name="currency_code" value="USD" />
													<input type="hidden" name="return" value=" " />
													<input type="hidden" name="cancel_return" value=" " />
													<input type="submit" name="submit" value="Add to cart" class="button" />
												</fieldset>
											</form>
										</div>
									</div>
								</figure>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3 top_brand_left">
					<div class="hover14 column">
						<div class="agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid_pos">
								<img src="images/offer.png" alt=" " class="img-responsive" />
							</div>
							<div class="agile_top_brand_left_grid1">
								<figure>
									<div class="snipcart-item block">
										<div class="snipcart-thumb">
											<a href="single.php"><img src="images/4.png" alt=" " class="img-responsive" /></a>
											<p>dogs food (4 Kg)</p>
											<h4>$9.00 <span>$11.00</span></h4>
										</div>
										<div class="snipcart-details top_brand_home_details">
											<form action="#" method="post">
												<fieldset>
													<input type="hidden" name="cmd" value="_cart" />
													<input type="hidden" name="add" value="1" />
													<input type="hidden" name="business" value=" " />
													<input type="hidden" name="item_name" value="dogs food" />
													<input type="hidden" name="amount" value="9.00" />
													<input type="hidden" name="discount_amount" value="1.00" />
													<input type="hidden" name="currency_code" value="USD" />
													<input type="hidden" name="return" value=" " />
													<input type="hidden" name="cancel_return" value=" " />
													
												</fieldset>
											</form>
										</div>
									</div>
								</figure>
							</div>
						</div>
					</div>
				</div> -->
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //top-brands -->
<!-- fresh-vegetables -->
	<!-- <div class="fresh-vegetables">
		<div class="container">
			<h3>Top Products</h3>
			<div class="w3l_fresh_vegetables_grids">
				<div class="col-md-3 w3l_fresh_vegetables_grid w3l_fresh_vegetables_grid_left">
					<div class="w3l_fresh_vegetables_grid2">
						<ul>
							<li><i class="fa fa-check" aria-hidden="true"></i><a href="#">All Brands</a></li>
							<li><i class="fa fa-check" aria-hidden="true"></i><a href="vegetables.php">Vegetables</a></li>
							<li><i class="fa fa-check" aria-hidden="true"></i><a href="vegetables.php">Fruits</a></li>
							<li><i class="fa fa-check" aria-hidden="true"></i><a href="drinks.php">Juices</a></li>
							<li><i class="fa fa-check" aria-hidden="true"></i><a href="pet.php">Pet Food</a></li>
							<li><i class="fa fa-check" aria-hidden="true"></i><a href="bread.php">Bread & Bakery</a></li>
							<li><i class="fa fa-check" aria-hidden="true"></i><a href="household.php">Cleaning</a></li>
							<li><i class="fa fa-check" aria-hidden="true"></i><a href="products.php">Spices</a></li>
							<li><i class="fa fa-check" aria-hidden="true"></i><a href="products.php">Dry Fruits</a></li>
							<li><i class="fa fa-check" aria-hidden="true"></i><a href="products.php">Dairy Products</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-9 w3l_fresh_vegetables_grid_right">
					<div class="col-md-4 w3l_fresh_vegetables_grid">
						<div class="w3l_fresh_vegetables_grid1">
							<img src="images/8.jpg" alt=" " class="img-responsive" />
						</div>
					</div>
					<div class="col-md-4 w3l_fresh_vegetables_grid">
						<div class="w3l_fresh_vegetables_grid1">
							<div class="w3l_fresh_vegetables_grid1_rel">
								<img src="images/7.jpg" alt=" " class="img-responsive" />
								<div class="w3l_fresh_vegetables_grid1_rel_pos">
									<div class="more m1">
										<a href="products.php" class="button--saqui button--round-l button--text-thick" data-text="Shop now">Shop now</a>
									</div>
								</div>
							</div>
						</div>
						<div class="w3l_fresh_vegetables_grid1_bottom">
							<img src="images/10.jpg" alt=" " class="img-responsive" />
							<div class="w3l_fresh_vegetables_grid1_bottom_pos">
								<h5>Special Offers</h5>
							</div>
						</div>
					</div>
					<div class="col-md-4 w3l_fresh_vegetables_grid">
						<div class="w3l_fresh_vegetables_grid1">
							<img src="images/9.jpg" alt=" " class="img-responsive" />
						</div>
						<div class="w3l_fresh_vegetables_grid1_bottom">
							<img src="images/11.jpg" alt=" " class="img-responsive" />
						</div>
					</div>
					<div class="clearfix"> </div>
					<div class="agileinfo_move_text">
						<div class="agileinfo_marquee">
							<h4>get <span class="blink_me">25% off</span> on first order and also get gift voucher</h4>
						</div>
						<div class="agileinfo_breaking_news">
							<span> </span>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div> -->
<!-- //fresh-vegetables -->
<!-- newsletter -->
	<div class="newsletter" style="background-color:#3b5998;">
		<div class="container">
		<center><h3 style="color:#fff">Feedback</h3><center>
			<div class="">
				
			</div>
			<div class="" style="margin-top:10px;">
				<form  method="post">
					<input type="text" style="height: 69px; width: 704px; margin-left: 58px;"  name="Comments" value=""   autocomplete="off" required>
					<div class="">
					<input type="text" style="height:40px;width: 499px;"  name="content" value="" autocomplete="off" required>
	<select class="form-select" name="subject" id="floatingSelect" aria-label="Floating label select example"style=" color: #fff;background-color: #31708f;; height: 34px; font-size: -0.26rem;  margin: 7px;text-align: center;font-weight: 500;width:127px">
   <option selected>Admin</option>
   <option selected>Delivery boy</option>
   
   
   </select>
		</div>
					<input type="submit" value="Submit" name="btnreply" style="height: 47px;font-size: 15px;">
				</form>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //newsletter -->
<!-- footer -->
	<!-- <div class="footer">
		<div class="container">
			<div class="col-md-3 w3_footer_grid">
				<h3>information</h3>
				<ul class="w3_footer_grid_list">
					<li><a href="events.php"></a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="products.php">Best Deals</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="short-codes.php">Short Codes</a></li>
				</ul>
			</div>
			<div class="col-md-3 w3_footer_grid">
				<h3>policy info</h3>
				<ul class="w3_footer_grid_list">
					<li><a href="faqs.php">FAQ</a></li>
					<li><a href="privacy.php">privacy policy</a></li>
					<li><a href="privacy.php">terms of use</a></li>
				</ul>
			</div>
			<div class="col-md-3 w3_footer_grid">
				<h3>what in stores</h3>
				<ul class="w3_footer_grid_list">
					<li><a href="pet.php">Pet Food</a></li>
					<li><a href="frozen.php">Frozen Snacks</a></li>
					<li><a href="kitchen.php">Kitchen</a></li>
					<li><a href="products.php">Branded Foods</a></li>
					<li><a href="household.php">Households</a></li>
				</ul>
			</div>
			 -->
			<!-- <div class="clearfix"> </div>
			<div class="agile_footer_grids">
				<div class="col-md-3 w3_footer_grid agile_footer_grids_w3_footer">
					<div class="w3_footer_grid_bottom">
						<h4>100% secure payments</h4>
						<img src="images/card.png" alt=" " class="img-responsive" />
					</div>
				</div>
				<div class="col-md-3 w3_footer_grid agile_footer_grids_w3_footer">
					<div class="w3_footer_grid_bottom">
						<h5>connect with us</h5>
						<ul class="agileits_social_icons">
							<li><a href="#" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" class="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" class="google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
							<li><a href="#" class="instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href="#" class="dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
						</ul>
					</div>
				</div> -->
				<div class="clearfix"> </div>
			</div>
			<div class="wthree_footer_copy">
				<p>© 2016 @Your Door. All rights reserved | Design by <a href="http://w3layouts.com/">Ancy Alexander</a></p>
			</div>
		</div>
	</div>
<!-- //footer -->
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideDown("fast");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).slideUp("fast");
            $(this).toggleClass('open');       
        }
    );
});
</script>
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->
<script src="js/minicart.min.js"></script>
<!--script>
	// Mini Cart
	paypal.minicart.render({
		action: '#'
	});

	if (~window.location.search.indexOf('reset=true')) {
		paypal.minicart.reset();
	}
</script-->
</body>
</html>