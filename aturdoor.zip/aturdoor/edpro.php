<!DOCTYPE html>
<html>
<head>
<title>@Your door</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Grocery Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all" /> 
<!-- //font-awesome icons -->
<!-- js -->
<script src="js/jquery-1.11.1.min.js"></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- start-smoth-scrolling -->
</head>
	
<body>
<?php include 'hheader.php' ?>
<style>
.button-24{
    background: #FF4742;
  border: 1px solid #FF4742;
  border-radius: 6px;
  box-shadow: rgba(0, 0, 0, 0.1) 1px 2px 4px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: nunito,roboto,proxima-nova,"proxima nova",sans-serif;
  font-size: 14px;
  line-height: 16px;
  min-height: 30px;
  outline: 0;
  padding: 12px 14px;
  text-align: center;
  text-rendering: geometricprecision;
  text-transform: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: middle;
}

.button-24:hover,
.button-24:active {
  background-color: initial;
  background-position: 0 0;
  color: #FF4742;
}

.button-24:active {
  opacity: .5;
}

</style>

  <html>

  <head>
    
    <style>
      table {
        border-collapse: collapse;
        width: 100%;
      }

      th,
      td {
        text-align: left;
        padding: 8px;
      }

      tr:nth-child(even) {
        background-color: #f2f2f2;
      }
    </style>

  </head>

  <body>
   
  

  <?php
session_start();
error_reporting(0);
include('db.php');
if (isset($_SESSION['login_admin'])) {
 $id = $_SESSION['login_admin'];
  extract($_REQUEST);
  if (isset($submit)) {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    
    $lat=$_POST['lat'];
    $lon=$_POST['lon'];
   // $sid = $_POST['login_id'];
    $que = "update register set uname='$name',phonenumber='$phone',address='$address',longittude='$lon',latitude='$lat' where login_id='$id' ";
    mysqli_query($conn, $que);
    $msg = "<h3 style='color:blue'>Profile Updated successfully</h3>";
  }
?>
<?php

$sql=mysqli_query($conn,"SELECT * FROM register,login_tbl WHERE register.login_id='$id' and login_tbl.login_id='$id'");
$row=mysqli_fetch_assoc($sql);
?>
  <form method="POST" enctype="multipart/form-data" style="width: 496px;margin-left: 419px;">
    <table class="table table-bordered">
      <h4 style="font-weight: bolder;">Update profile</h4>
      <hr>
      <tr>
        <th>Name</th>
        <td><input type="text" name="name" class="form-control" value="<?php echo $row['uname']; ?>" />
        </td>
      </tr>
      <tr>
        <th>Address</th>
        <td><input type="text" name="address" class="form-control" value="<?php echo $row['address']; ?>" />
        </td>
      </tr>
      <tr>
        <th>Phone</th>
        <td><input type="text" name="phone" class="form-control" value="<?php echo $row['phonenumber']; ?>" />
        </td>
      </tr>
      <input type="hidden" name="id" class="form-control" value="<?php echo $id; ?>" />
      <input type="hidden" name="lat" class="form-control" value="" id="lat"/>
      <input type="hidden" name="lon" class="form-control" value="" id="lon" />

      <div>
                  <button  class="btn btn-primary" style=" margin-left: 44%;" type="submit" name="submit">Update</button>
                   </div>
                   
                  <h5 id="demo1"></h5>
                  <button  class="btn btn-primary" style=" margin-right: 44%;" type="button" onclick="getLocation()">choose your location</button>
                   
    </table>
  </form>
  <div class="col-sm-12" align="center" id="mapholder">
                    <iframe id="google_map" width="100%" height="200" frameborder="0" scrolling="no" marginheight="0"
                        marginwidth="0" src="https://maps.google.co.in?output=embed"></iframe><br>
                </div><br>

  <?php } ?>
  </body>
  <script>
    var x = document.getElementById("demo1");
    function getLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(showPosition, showError);
        }
        else { x.innerHTML = "Geolocation is not supported by this browser."; }
    }
function showPosition(position) {
        var lat = position.coords.latitude;
        var lon = position.coords.longitude;
        var coords = lat + ',' + lon;
        document.getElementById("google_map").setAttribute('src', 'https://maps.google.co.in/?q=' + coords + '&output=embed');
        document.getElementById("lat").value = lat;
        document.getElementById("lon").value = lon;
    }
function showError(error) {
        switch (error.code) {
            case error.PERMISSION_DENIED:
                x.innerHTML = "User denied the request for Geolocation."
                break;
            case error.POSITION_UNAVAILABLE:
                x.innerHTML = "Location information is unavailable."
                break;
            case error.TIMEOUT:
                x.innerHTML = "The request to get user location timed out."
                break;
            case error.UNKNOWN_ERROR:
                x.innerHTML = "An unknown error occurred."
                break;
        }
    }


  </script>
    
  </html>
<!-- <//?php
} else {
  if (headers_sent()) {
    die('<script type="text/javascript">window.location.href="../login.html?e=1"</script>');
  } else {
    header("location:../login.html?e=1");
    die();
  }
}
?> -->
