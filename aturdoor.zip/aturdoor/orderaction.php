<?php
include 'db.php';
session_start();
//error_reporting(0);
$uid = $_SESSION['login_admin'];
$cartids = $_GET['cid'];
$prices = $_GET['tid'];
$asu = mysqli_query($conn,"SELECT * FROM `register` where login_id='$uid'");
$ado = mysqli_fetch_assoc($asu);
$adpp = $ado['uname'];

$as = mysqli_query($conn,"SELECT * FROM `register` where login_id='$uid'");
$ad = mysqli_fetch_assoc($as);
$ad = $ad['pincode'];
$as = mysqli_query($conn,"SELECT * FROM `deliveryboy_tbl` where pincode='$ad' and sts='active'");
$con = mysqli_num_rows($as);
if($con>0){
    $af = mysqli_fetch_assoc($as);
    $af = $af['login_id'];
}


$order="INSERT INTO `order_tbl`(`login_id`,`price`,`status`) VALUES ('$uid','$prices','placed')";
$or1=mysqli_query($conn,$order);
$orid = mysqli_insert_id($conn);

if($con>0){
    $oi = mysqli_query($conn,"UPDATE `order_tbl` SET `status`='shipped',`del_boy`='$af' WHERE `id`='$orid'");
    if($oi){
        mysqli_query($conn,"UPDATE `deliveryboy_tbl` SET `sts`='inactive' WHERE `login_id`='$af'");
    }
}


$qw = mysqli_query($conn,"select * from `cart_tbl` WHERE sts = 0 and login_id = '$uid'");
while($rw = mysqli_fetch_assoc($qw)){
    $qua = 0;
    echo $qua;
    $cid = $rw['product_id'];
    $qid = $rw['quantity'];
    echo $cid;
    $qe = mysqli_query($conn,"SELECT quantity FROM `product_tbl` WHERE product_id ='$cid'");
    $qr = mysqli_fetch_assoc($qe);
    $qua = $qr['quantity'] - $qid;
    mysqli_query($conn,"UPDATE `product_tbl` SET quantity='$qua' WHERE product_id ='$cid'");
}
$qq = mysqli_query($conn,"UPDATE `cart_tbl` SET sts=1, orderid ='$orid' WHERE sts = 0 and login_id = '$uid' ");

$asr = mysqli_query($conn,"DELETE FROM `discount_tbl` where login_id='$uid'");

$ordert="INSERT INTO `payment_tbl`(`login_id`,`name`,`cart_id`,`price`,`status`) VALUES ('$uid','$adpp','$cartids','$prices','success')";
mysqli_query($conn,$ordert);



header("Location:final.php?id=$orid");
?>