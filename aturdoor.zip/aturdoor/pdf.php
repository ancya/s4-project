<?php
session_start();
include 'db2.php';

error_reporting(0);
$uid = $_SESSION['login_admin'];
if($_SESSION['login_admin']==""){
    header('location:login.php');
  }

 

$result=mysqli_query($conn,"SELECT name,address,date,price,status FROM `order_tbl` where login_id=$uid") or die(mysqli_error($con));


include('pdf_mc_table.php');
$pdf = new PDF_MC_TABLE();
$pdf->AddPage();
$pdf->SetFont('Arial','B',15);	
$pdf->Cell(176, 5, 'Application Details', 0, 0, 'C');
  $pdf->Ln();
  $pdf->Ln();
  $pdf->Ln();	
$row=mysqli_fetch_array($result);
$pdf->SetFont('Arial','',12);	
$pdf->Multicell(80,12,'Name : '. $row['uname'],1); 



$pdf->Multicell(80,12,'Permanent Adddress : '. $row['address'],1);
$pdf->Multicell(80,12,'Phone Number : '. $row['phone_no'],1);
$pdf->Multicell(80,12,'License Type : '. $row['license_type'],1);
$pdf->Multicell(80,12,'Date of Issue : '. $row['date_of_issue'],1);
$pdf->Multicell(80,12,'Expiriry Date : '. $row['expiriry_date'],1);
$pdf->Multicell(80,12,'Blood : '. $row['blood'],1);

$pdf->Output();
?>