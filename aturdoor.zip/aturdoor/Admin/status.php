<?php
include 'db2.php';
$su_id=$_GET['sid'];
$sts=$_GET['sts'];

if ($sts == 0) {
    mysqli_query($con,"UPDATE `login_tbl` SET `status` = 1 WHERE `login_id` ='$su_id'");
} else {
mysqli_query($con,"UPDATE `login_tbl` SET `status` = 0 WHERE `login_id` ='$su_id'");
}

        header('location: manage.php');
?>