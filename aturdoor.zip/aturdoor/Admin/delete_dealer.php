<?php
include 'db2.php';
$su_id=$_GET['sid'];
mysqli_query($con,"DELETE FROM `login_tbl` WHERE `login_id` ='$su_id'");
mysqli_query($con,"DELETE FROM `dealer_tbl` WHERE `login_id` ='$su_id'");
        header('location: manage.php');
?>