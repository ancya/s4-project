<?php include 'db2.php';
$sa = "";
$sql = mysqli_query($con, "SELECT order_tbl.status,order_tbl.price,order_tbl.date,register.uname,register.address FROM `order_tbl` inner join login_tbl on login_tbl.login_id = order_tbl.login_id inner join register on register.login_id=order_tbl.login_id ");
if(isset($_POST['subis'])){
    $sa = $_POST['as'];
    header("location:orderdetails.php?asd=".$sa);
}
if(!empty($_GET['asd'])){
    $sa = $_GET['asd'];
    $sas = $_GET['asd']."%";
    $sql = mysqli_query($con, "SELECT order_tbl.status,order_tbl.price,order_tbl.date,register.uname,register.address FROM `order_tbl` inner join login_tbl on login_tbl.login_id = order_tbl.login_id inner join register on register.login_id=order_tbl.login_id where order_tbl.date like '$sas'");

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
   
    <style>
        table{
            border-collapse:collapse;
            width:100%;
        }
        th,td{
            text-align:left;
            padding:10px;
        }
        tr:nth-child(even){
            background-color:#f2f2f2;
        }
        th,td{
            background-color:#867198;
            color:black;
        }
    </style>
</head>

<body style =" height:100px;">

    <?php include 'sidebar.php'; ?>
    <div class="main">
       
        <div class="disk">
           
            <div class="container" position="inherit">
                
            <form method="post">
            	<input type="text" name="as" value="<?php if($sa !=""){ echo $sa; } ?>" placeholder="Search by date" title="Type in a name">
                <input type="submit" name="subis" value="Filter">
 
                    <div class="row">
                        <div>
                       
					<div class="table-wrap">
						<table class="table" id="myTable">
						  <thead class="thead-primary" style="background-color: #84C639;" margin:inherit>
                          <div class="card-body table-border-style">
                          <div>
    </div><br>
                        <div class="table-responsive">
                            <table border=2 width=100%>
						    <tr>
                            <th>Name</th>
                            <th>Address</th>
                            <th>Date</th>
                            <th>Price</th>
                            <th>Status</th>
						    </tr>
						  </thead>
						  <tbody>
                          <?php while ($row = mysqli_fetch_array($sql)) { ?>
                            <tr>
                                <td><p><?php echo $row['uname']?></p></td>
                                <td><p><?php echo $row['address']?></p></td>
                                <td><p><?php echo $row['date']?></p></td>
                                <td><p><?php echo $row['price']?></p></td>
                                <td><p><?php echo $row['status']?></p></td>
                                
                            </tr>
                         
                        <?php } ?>
<div>
                          </div>
                          </div>
                
                </div>
               
                   
                    
                </table>
                <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
			
                <button><a href="pddf.php?date=<?php echo $sa; ?>">Download</a></button>

            </div>
            </form>
            <!-- <script>
        $(document).ready(function(){
            $("#myInput").on("keyup",function({
                var value =$(this).val().toLowerCase();
                $("#myTable tr").filter(function(){
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            }));
        });
    </script> -->
</html>