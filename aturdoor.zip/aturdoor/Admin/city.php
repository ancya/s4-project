<?php
include 'db2.php';
session_start();
if($_SESSION['login_admin']==""){
    header('location:login.php');
  }
if (isset($_POST['submit'])) {
    $city = $_POST['city'];
    $pincode = $_POST['pincode'];
    

    
    // $sql = mysqli_query($con, "INSERT INTO `dealer_tbl`( `dealer_name`, `email`, `phonenumber`, `place`, `login_id`) VALUES ('$name','$email','$phone','$address','$roleid')");
    $sel="SELECT * FROM `city` WHERE `city`='$city'";
    $sell="SELECT * FROM `city` WHERE `pincode`='$pincode'";
	$query1=mysqli_query($con,$sel);
	$num=mysqli_num_rows($query1);
    $query2=mysqli_query($con,$sell);
	$numm=mysqli_num_rows($query2);
	if($num > 0)
	{
		echo '<script>alert("city already exit..!");</script>';
		echo "<script>window.location='city.php'</script>";
	}else if($numm>0){
        echo '<script>alert("pincode already exit..!");</script>';
		echo "<script>window.location='city.php'</script>";

    

    }
    else{
        $sql = mysqli_query($con, "INSERT INTO `city`( `city`, `pincode`) VALUES ('$city','$pincode')");
    
    echo "<script>alert('Succesfully added');</script>";
    header("Location: city.php");
}
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <style>
        input[type=text],
        [type=number],
        [type=password],
        [type=email],
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            resize: vertical;
        }

        label {
            padding: 12px 12px 12px 0;
            display: inline-block;
        }

        input[type=submit] {
            background-color: #04AA6D;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            float: right;
        }

        input[type=submit]:hover {
            background-color: #45a049;
        }

        .container {
            border-radius: 5px;
            background-color: #f2f2f2;
        }

        .col-25 {
            float: left;
            width: 15%;
            margin-top: 6px;
        }

        .col-75 {
            float: left;
            width: 75%;
            margin-top: 6px;
        }

        /* Clear floats after the columns */
        .row:after {
            content: "";
            display: table;
            clear: both;
        }
    </style>
</head>

<body>
    <?php include 'sidebar.php'; ?>

    <div class="main">
        <?php include 'topbar.php'; ?>
        <div class="disk">
            <h2><ADDress></ADDress>ADD CITY</h2>
            <div class="container">
                <form method="post">
                    <div class="row">
                        <!-- <div class="col-25">
                            <label for="fname">place</label>
                        </div>
                        <div class="col-75">
                            <input type="text" id="fname" name="fname" placeholder="place..">
                        </div>
                    </div> -->
                   
                    <div class="row">
                        <div class="col-25">
                            <label for="lname">city</label>
                        </div>
                        <div class="col-75">
                            <input type="text" id="lname" name="city" placeholder="enter city    .." required onchange="Validate()">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-25">
                            <label for="subject">pincode</label>
                        </div>
                        <div class="col-75">
                            <input type="number" id="pin" name="pincode" placeholder="enter pincode    .." required onchange="Validat()">
                        </div>
                       
                   
                    <br>
                    <div class="row">
                        <div class="col-75" style="margin-left:-250px">
                            <input type="submit" value="Submit" name="submit">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>		
function Validate() 
{
    var val = document.getElementById('lname').value;

    if (!val.match(/^[A-Z][A-Za-z/ ]{3,}$/)) 
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('lname').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
function Validat() 
{
    var val = document.getElementById('pin').value;

    if (!val.match(/^[6][0-9]{6}$/))
    {
        document.getElementById('msg4').innerHTML="Only Numbers are allowed and must contain 6 number";
	
		
		            document.getElementById('pin').value = "";
        return false;
    }
document.getElementById('msg4').innerHTML=" ";
    return true;
}
</script>
                    
    <script>
        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active')
            main.classList.toggle('active')

        }
    </script>

</body>

</html>