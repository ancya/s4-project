<?php
include 'db2.php';
session_start();
if($_SESSION['login_admin']==""){
    header('location:login.php');
  }

if (isset($_POST['submit'])) {
    $name = $_POST['fname'];
    $email = $_POST['eemail'];
    $phone = $_POST['pphone'];
    $address = $_POST['subject'];
    $password = $_POST['pass'];

    $sql = mysqli_query($con, "INSERT INTO `login_tbl`( `email`, `password`, `role`, `status`) VALUES ('$email','$password','dealer','1')");
    $roleid = mysqli_insert_id($con);
    $sql = mysqli_query($con, "INSERT INTO `dealer_tbl`( `dealer_name`, `email`, `phonenumber`, `place`, `login_id`) VALUES ('$name','$email','$phone','$address','$roleid')");
    echo "<script>alert('Succesfully added');</script>";
    header("Location: add_dealer.php");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <style>
        input[type=text],
        [type=number],
        [type=password],
        [type=email],
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            resize: vertical;
        }

        label {
            padding: 12px 12px 12px 0;
            display: inline-block;
        }

        input[type=submit] {
            background-color: #04AA6D;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            float: right;
        }

        input[type=submit]:hover {
            background-color: #45a049;
        }

        .container {
            border-radius: 5px;
            background-color: #f2f2f2;
        }

        .col-25 {
            float: left;
            width: 15%;
            margin-top: 6px;
        }

        .col-75 {
            float: left;
            width: 75%;
            margin-top: 6px;
        }

        /* Clear floats after the columns */
        .row:after {
            content: "";
            display: table;
            clear: both;
        }
    </style>
</head>

<body>
    <?php include 'sidebar.php'; ?>
    <div class="main">
        <?php include 'topbar.php'; ?>
        <div class="form-floating">
		
		<!-- <div class="w3l_header_right1">
	<select class="form-select" id="floatingSelect" aria-label="Floating label select example"style=" color: #fff;background-color: #84C639; height: 34px; font-size: -0.26rem;  margin: 7px;text-align: center;font-weight: 500;width:127px" onchange="this.value">
   <option selected><?php echo $dealer_name; ?></option>
   	
  
   
  
   
   </select>
		</div> -->
<!-- </div> -->
	

    <div class="main">
        
        <div class="disk">
            <h2>Add Dealer</h2>
            <div class="container">
                <form method="post">
                    <div class="row">
                        <div class="col-25">
                            <label for="fname">Full Name</label>
                        </div>
                        <div class="col-75">
                            <input type="text" id="fname" name="fname" placeholder="Your name..">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-25">
                            <label for="lname">Email</label>
                        </div>
                        <div class="col-75">
                            <input type="email" id="lname" name="eemail" placeholder="Your Email..">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-25">
                            <label for="lname">Phone</label>
                        </div>
                        <div class="col-75">
                            <input type="number" id="lname" name="pphone" placeholder="Your Number    ..">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-25">
                            <label for="subject">Address</label>
                        </div>
                        <div class="col-75">
                            <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-25">
                            <label for="lname">Password</label>
                        </div>
                        <div class="col-75">
                            <input type="password" id="lname" name="pass" placeholder="Your Password..">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-75" style="margin-left:-250px">
                            <input type="submit" value="Submit" name="submit">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active')
            main.classList.toggle('active')

        }
    </script>

</body>

</html>