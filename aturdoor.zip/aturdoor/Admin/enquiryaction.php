<?php
include 'db2.php';
$yy = $_GET['cid'];
$tt = $_GET['did'];
$sql="DELETE FROM enquiry where category_name='$yy'";
mysqli_query($con,$sql);
$result = "INSERT INTO tbl_category(category_name,category_desc)values('$yy','$tt')";
mysqli_query($con,$result);
echo "<script> alert('Approved'); window.location.href='enquiryaction.php';</script>";
?>