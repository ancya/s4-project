<?php 
include 'db2.php';
session_start();
if($_SESSION['login_admin']==""){
    header('location:../login.php');
  }
$sql = mysqli_query($con,"SELECT * FROM `product_tbl`");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <style>
        * {
            box-sizing: border-box;
        }

        /* Create three equal columns that floats next to each other */
        .column {
            float: left;
            width: 30%;
            padding: 10px;
            margin-right: 20px;
            margin-bottom: 20px;
            /* Should be removed. Only for demonstration */
        }

        /* Clear floats after the columns */
        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        .card {
            margin: auto;
            text-align: center;
            font-family: arial;
        }

        button {
            border: none;
            outline: 0;
            display: inline-block;
            padding: 8px;
            color: white;
            background-color: #000;
            text-align: center;
            cursor: pointer;
            width: 100%;
        }

        a {
            text-decoration: none;
            color: black;
        }
    </style>
</head>

<body>
    <?php include 'sidebar.php'; ?>

    <div class="main">
        <?php include 'topbar.php'; ?>
        <div class="disk">
            <h2>View Products</h2>
            <div>
        <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search product" title="Type in a name">
</div>

            <div class="row">
                <?php while ($row = mysqli_fetch_assoc($sql)){ ?>
                <div class="column" style="background-color:#DBDBDB;">
                    <div class="card">
                        <img src="../dealer/productimages/<?php echo $row['image']; ?>" alt=" " class="img-responsive" style="height: 150px; width: 188px;" />
                        <h3><?php echo $row['product_name']?></h3>
                        <p class="title"><?php echo $row['type']; ?></p>
                        <p><i><?php echo $row['description']; ?></i></p>
                        <p><?php echo "₹".$row['price']; ?></p>
                        <p><?php echo "Stock Avaliable: ".$row['quantity']; ?></p>
                        <p style="margin-top:5px"><button><?php 
                        if($row['quantity']>0){
                            echo $row['availability'];
                        }else{
                            echo "Out of Stock";
                        }
                        ?></button></p>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <script>
        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active')
            main.classList.toggle('active')

        }
    </script>
    <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[5];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>


</body>

</html>