<div class="topbar">
    <div class="toggle" onclick="toggleMenu()"></div>
    <div class="search">
    <!-- <form class="example" action="searchad.php" method="POST">
        <input type="text" placeholder="Search.." name="search" >
        <button type="submit"><i class="fa fa-search" ></i></button>
        </form> -->
				

    </div>Admin
    <div>
        <p><a href ="logout.php">logout</a></p>
</div>
    <!-- <div class="user">
        <img src=" -->


</div>