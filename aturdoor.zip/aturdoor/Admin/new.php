<?php include 'db2.php';
$uu="SELECT * from product_tbl where `status`=0";
$sql=mysqli_query($con,$uu);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <style>
        table{
            border-collapse:collapse;
            width:100%;
        }
        th,td{
            text-align:left;
            padding:10px
        }
        tr:nth-child(even){
            background-color:#f2f2f2;
        }
        th{
            background-color:#867198;
            color:black;
        }
    </style>
</head>

<body style="width: 100px;" height:100px;>

    <?php include 'sidebar.php'; ?>
    <div class="main">
       
        <div class="disk">
           
            <div class="container" position="inherit">
                <form method="post">
                    <div class="row">
                        <div class="col-25">
                            

					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-primary" style="background-color: #84C639; "margin:inherit">
                          <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table border=2 width=100%>
						    <tr>
                            <th>Name</th>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Action</th>
						    </tr>
						  </thead>
						  <tbody>
                          <?php while ($row = mysqli_fetch_array($sql)) { ?>
                            <tr>
                                <td><p><?php echo $row['product_name']?></p></td>
                                <td><p><img src="../dealer/productimages/<?php echo $row['image']; ?>" alt=" " class="img-responsive" style="height: 50px; width: 50px;" /></p>
                                <td><p><?php echo $row['price']?></p></td>
                                <td><p><a href="update-pro.php?pro_id=<?php echo $row['product_id']; ?>">approve</a></td></p>
                            </tr>
                         
                        <?php } ?>
<div>
                          </div>
                          </div>
                    <h2> PRODUCTS FOR APPROVEL</h2>
                </div>
                <table>
                    <thead>
                        <!-- <tr>
                            <td>Name</td>
                            <td>Product</td>
                            <td>Price</td>
                            <td>Action</td>
                        </tr> -->
                    </thead>
                    <tbody>
                        <!-- <?php while ($row = mysqli_fetch_array($sql)) { ?>
                            <tr>
                                <td><p><?php echo $row['product_name']?></p></td>
                                <td><p><img src="../dealer/productimages/<?php echo $row['image']; ?>" alt=" " class="img-responsive" style="height: 50px; width: 50px;" /></p>
                                <td><p><?php echo $row['price']?></p></td>
                                <td><p><a href="update-pro.php?pro_id=<?php echo $row['product_id']; ?>">approve</a></td></p>
                            </tr>
                         
                        <?php } ?> -->
                    </tbody>
                </table>

            </div>
</html>