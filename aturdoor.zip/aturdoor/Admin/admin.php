<?php
include 'db2.php';
session_start();
if($_SESSION['login_admin']==""){
    header('location:login.php');
  }

// $sql = mysqli_query($con, "SELECT * FROM `order_db` join product_tbl on product_tbl.product_id = order_db.order_id join register on register.login_id = order_db.login_id");
$sql = mysqli_query($con, "SELECT order_tbl.status,order_tbl.price,order_tbl.date,register.uname FROM `order_tbl` inner join login_tbl on login_tbl.login_id = order_tbl.login_id inner join register on register.login_id=order_tbl.login_id WHERE DATE(date) = DATE(NOW())");
$sql2 = mysqli_query($con, "SELECT * FROM `login_tbl` INNER join register on login_tbl.login_id = register.login_id");
//$sql3 = mysqli_query($con,"SELECT * FROM order_tbl WHERE DATE(date) = DATE(NOW())")           

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">

</head>

<body>
    <?php include 'sidebar.php'; ?>

    <div class="main">
        <?php include 'topbar.php'; ?>

        <!-- <div class="cardBox">
            <div class="card">
                <div>
                    <div class="numbers">
                        
                    </div>
                    <div class="cardName">Total Orders</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-eye" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">208</div>
                    <div class="cardName">Sales</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">5</div>
                    <div class="cardName">Comments</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-comment" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">3999</div>
                    <div class="cardName">Earnings</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-inr" aria-hidden="true"></i>
                </div>
            </div>
        </div> -->
        <div class="cardBox">
            <div class="card">
                <div>
                    <h2>
                                                <?php
                            $query = "SELECT reg_id FROM register ORDER BY reg_id";  
                            $query_run = mysqli_query($con, $query);
                            $row = mysqli_num_rows($query_run);
                            echo '<h4>'.$row.'</h4>';
                        ?>
                                                </h2>
                    <div class="cardName">Total users</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-eye" aria-hidden="true"></i>
                </div>
            </div>
			
			 <div class="card">
                <div>
                    <h2>
                                                <?php
                            $query = "SELECT product_name FROM product_tbl ORDER BY product_id";  
                            $query_run = mysqli_query($con, $query);
                            $row = mysqli_num_rows($query_run);
                            echo '<h4>'.$row.'</h4>';
                        ?>
                                                </h2>
                    <div class="cardName">Total products</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-eye" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div>
                    <h2>
                           <?php
                            $query = "SELECT * FROM order_tbl";  
                            $query_run = mysqli_query($con, $query);
                            $row = mysqli_num_rows($query_run);
                            echo '<h4>'.$row.'</h4>';
                        ?>
                                                </h2>
                    <div class="cardName">Total Orders</div>
                </div>
                <div class="iconBox">
                   <a href="orderdetails.php" style="text-decoration:none;"> <i class="fa fa-eye" aria-hidden="true"></a></i>
                </div>
            </div>
			
			
			
			
			
			
           
		   
		   
		   
		   
		   
            <!-- <div class="card">
                <div>
                    <div class="numbers">5</div>
                    <div class="cardName">Comments</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-comment" aria-hidden="true"></i>
                </div>
            </div> -->
            <!-- <div class="card">
                <div>
                    <div class="numbers">3999</div>
                    <div class="cardName">Earnings</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-inr" aria-hidden="true"></i>
                </div>
            </div> -->
        </div>


        <div class="details">
            <div class="recentOrders">
                <div class="cardHeader">
                    <h2>Recent Orders</h2>
                    <a href="#" class="btn">View All</a>
                </div>
                <table>
                    <thead>
                        <tr>
                            <td>Name</td>
                            
                            <td>Price</td>
                            <td>Date</td>
                            <td>Status</td>
                           
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($sql)) { ?>
                            <tr>
                                <td><?php echo $row['uname']?></td>
                                <!-- <td><?php echo $row['cart_id']?></td> -->
                                <td><?php echo $row['price']?></td>
                                <td><?php echo $row['date']?></td>
                                <td><span class="status inprogress"><?php echo $row['status']?></span></td>
                            </tr>
                            <!-- <tr>
                            <td>Mango</td>
                            <td>100</td>
                            <td>Due</td>
                            <td><span class="status pending">Pending</span></td>
                        </tr>
                        <tr>
                            <td>Maggi</td>
                            <td>50</td>
                            <td>Paid</td>
                            <td><span class="status return">Return</span></td>
                        </tr>
                        <tr>
                            <td>Sugar</td>
                            <td>40</td>
                            <td>due</td>
                            <td><span class="status delivered">In Progress</span></td>
                        </tr> -->
                        <?php } ?>
                    </tbody>
                </table>

            </div>
            <!-- <div class="recentCustomers">
                <div class="cardHeader">
                    <h2>Recent Customers</h2>

                </div>
                <table>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($sql2)) { ?>
                        <tr>
                            <td width="60px">
                                <div class="imgBx"><img src="profile.png"></div>
                            </td>
                            <td>
                                <h4><?php echo $row['uname']?><br><span><?php echo $row['email']?></span></h4>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div> -->
        </div>
    </div>

    <script>
        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active')
            main.classList.toggle('active')

        }
    </script>

</body>

</html>