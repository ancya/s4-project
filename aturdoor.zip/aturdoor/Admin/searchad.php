<?php
include 'db2.php';
session_start();
error_reporting(0);
$uid = $_SESSION['login_admin'];
if($_SESSION['login_admin']==""){
  header('location:login.php');
}






?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">

</head>

<body>
    <?php include 'sidebar.php'; ?>

    <div class="main">
        <?php include 'topbar.php'; ?>

        <!-- <div class="cardBox">
            <div class="card">
                <div>
                    <div class="numbers">
                        
                    </div>
                    <div class="cardName">Total Orders</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-eye" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">208</div>
                    <div class="cardName">Sales</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">5</div>
                    <div class="cardName">Comments</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-comment" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div>
                    <div class="numbers">3999</div>
                    <div class="cardName">Earnings</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-inr" aria-hidden="true"></i>
                </div>
            </div>
        </div> -->
        <div class="cardBox">
            <div class="card">
                <div>
                    <h2>
                                                <?php
                            $query = "SELECT reg_id FROM register ORDER BY reg_id";  
                            $query_run = mysqli_query($con, $query);
                            $row = mysqli_num_rows($query_run);
                            echo '<h4>'.$row.'</h4>';
                        ?>
                                                </h2>
                    <div class="cardName">Total users</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-eye" aria-hidden="true"></i>
                </div>
            </div>
			
			 <div class="card">
                <div>
                    <h2>
                                                <?php
                            $query = "SELECT product_name FROM product_tbl ORDER BY product_id";  
                            $query_run = mysqli_query($con, $query);
                            $row = mysqli_num_rows($query_run);
                            echo '<h4>'.$row.'</h4>';
                        ?>
                                                </h2>
                    <div class="cardName">Total products</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-eye" aria-hidden="true"></i>
                </div>
            </div>
            <div class="card">
                <div>
                    <h2>
                           <?php
                            $query = "SELECT * FROM order_tbl";  
                            $query_run = mysqli_query($con, $query);
                            $row = mysqli_num_rows($query_run);
                            echo '<h4>'.$row.'</h4>';
                        ?>
                                                </h2>
                    <div class="cardName">Total Orders</div>
                </div>
                <div class="iconBox">
                   <a href="orderdetails.php" style="text-decoration:none;"> <i class="fa fa-eye" aria-hidden="true"></a></i>
                </div>
            </div>
			
			
			
			
			
			
           
		   
		   
		   
		   
		   
            <!-- <div class="card">
                <div>
                    <div class="numbers">5</div>
                    <div class="cardName">Comments</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-comment" aria-hidden="true"></i>
                </div>
            </div> -->
            <!-- <div class="card">
                <div>
                    <div class="numbers">3999</div>
                    <div class="cardName">Earnings</div>
                </div>
                <div class="iconBox">
                    <i class="fa fa-inr" aria-hidden="true"></i>
                </div>
            </div> -->
        </div>

        <div class="w3ls_w3l_banner_nav_right_grid w3ls_w3l_banner_nav_right_grid_veg"><br>
				<h3 class="w3l_fruit">Related Products</h3>
				<div class="w3ls_w3l_banner_nav_right_grid1 w3ls_w3l_banner_nav_right_grid1_veg">
				            <?php  
                            $search=$_POST['search'];
                            $sql="select * from product_tbl join register on product_tbl.product_id=register.reg_id where product_tbl.product_name like '%search%' or register.uname like '%search%';";
							// $sql2="select * from tbl_category where category_name like '%$search%'";
                            $result = $conn->query($sql);
							// $results = $conn->query($sql2);
							
							
							if($result->num_rows > 0){
                                while ($raw = $result->fetch_assoc()){ ?>
								
					<div class="col-md-3 w3ls_w3l_banner_left w3ls_w3l_banner_left_asdfdfd">
						<div class="hover14 column">
						
						<div class="agile_top_brand_left_grid w3l_agile_top_brand_left_grid">
							<div class="agile_top_brand_left_grid1">
								<figure>
								<form action="#" method="post">
								
									<div class="snipcart-item block">
										<div class="snipcart-thumb">
											<img src="dealer/productimages/<?php echo $raw['image']; ?>" alt=" " class="img-responsive" style="height: 150px; width: 188px;" />
											<p><?php echo $raw['product_name']; ?></p>
											<h4><?php echo $raw['price']; ?> </h4>
											<input type="hidden" name="productid" value="<?php echo $raw['product_id']; ?>">
											<input type="hidden" name="price" value="<?php echo $raw['price']; ?>">
											<input type="submit" name="submit" value="Add To Cart" class="button" style="margin-left: 4px;margin-top: 15px;width: 194px;height: 35px;background-color: #84C639;color: #fff;border-radius: 6px;font-size: 17px;">
										</div>
										<div class="snipcart-details">
										
											
										</div>
									</div>
								
								</figure>
							</div>
						</div>
						
						</div>
					</div>
					<?php }} else{
						echo "NO PRODUCT FOUND";
						}?>
						</form>
				
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>

      

    <script>
        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active')
            main.classList.toggle('active')

        }
    </script>

</body>

</html>