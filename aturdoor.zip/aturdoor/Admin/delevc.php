<?php
include 'db2.php';
$su_id=$_GET['sid'];
mysqli_query($con,"DELETE FROM `tbl_category` WHERE `id`='$su_id'");
echo "<script>alert('Succesfully added');</script>";
header('location:vc.php');

?>

