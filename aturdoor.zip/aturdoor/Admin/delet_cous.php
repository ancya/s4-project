<?php
include 'db2.php';
$su_id=$_GET['sid'];
mysqli_query($con,"DELETE FROM `login_tbl` WHERE `login_id` ='$su_id'");
mysqli_query($con,"DELETE FROM `register` WHERE `login_id` ='$su_id'");
        header('location: view_customers.php');

?>
<div class="newsletter" style="background-color:#3b5998;">
		<div class="container">
		<center><h3 style="color:#fff">Reply</h3><center>
			<div class="">
				
			</div>
			<div class="" style="margin-top:10px;">
				<form action="#" method="post">
					
					<div class="">
					<input type="text" style="height:40px;width: 499px;"  name="Reply coments" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Write reply';}" required=""> >
	
		</div>
					<input type="submit" value="Submit" name="submit" style="height: 47px;font-size: larger;">
				</form>
			</div>