<?php 
include 'db2.php';
$fid=$_GET['sid'];
if (isset($_POST['submit'])) {
    $reply = $_POST['freply'];
    mysqli_query($con,"UPDATE `feedback_db` SET `replay`='$reply' WHERE feedback_id='$fid'");
}
    $sql = mysqli_query($con,"SELECT * FROM `feedback_db` where user_type='Admin'");
 

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <?php include 'sidebar.php'; ?>

    <div class="main">
        <?php include 'topbar.php'; ?>
        <div class="disk">

        <div class="newsletter" style="background-color:#84c639;">
		<div class="container">
		<center><h3 style="color:#fff"> Feedback Reply</h3><center>
			<div class="">
				
			</div>
			<div class="" style="margin-top:10px;">
				<form  method="post">
					
					<div class="">
	<textarea cols="50" rows="10" name="freply"  value ="feedbackreply" required=""></textarea>
		</div>
					<input type="submit" value="Submit" name="submit" style="height: 47px;font-size: larger;">
				</form>
			</div>
            </table>

        </div>
    </div>
    <script>
        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active')
            main.classList.toggle('active')

        }
    </script>

</body>

</html>