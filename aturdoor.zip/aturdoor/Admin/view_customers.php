<?php 
include 'db2.php';
session_start();
if($_SESSION['login_admin']==""){
    header('location:login.php');
  }
$sql = mysqli_query($con,"SELECT * FROM `login_tbl` INNER join register on login_tbl.login_id = register.login_id");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <style>
        * {
            box-sizing: border-box;
        }

        /* Create three equal columns that floats next to each other */
        .column {
            float: left;
            width: 31.63%;
            height: 180px;
            padding: 10px;
            margin-right: 20px;
            margin-bottom: 20px;
            /* Should be removed. Only for demonstration */
        }

        /* Clear floats after the columns */
        .row:after {
            content: "";
            display: table;
            clear: both;
        }
    </style>
</head>

<body> 
    <?php include 'sidebar.php'; ?>

    <div class="main">
        <?php include 'topbar.php'; ?>
        <div class="disk">
            <h2>View Customers</h2>
            <div class="row">
                <?php while ($row = mysqli_fetch_assoc($sql)){ ?>
                <div class="column" style="background-color:#DBDBDB;height: 216px;">
                    <b>Name: </b><?php echo $row['uname']?> <br>
                    <b>Email: </b><?php echo $row['email']?> <br>
                    <b>Phone: </b><?php echo $row['phonenumber']?> <br>
                    <b>Address: </b><?php echo $row['address']?> <br>
                    <p>
                           
                        
                        <?php if ($row['status'] == 0) { ?>
                            <p><a href="statuscou.php?sid=<?php echo $row['login_id']; ?>&&sts=0"><button style="width: 100%;margin-top:10px;background:#84C639">Enable</button></a></p>
                        <?php } else { ?>
                            <p><a href="statuscou.php?sid=<?php echo $row['login_id']; ?>&&sts=1"><button style="width: 100%;margin-top:10px;background:#84C639">Disable</button></a></p>
                        <?php } ?>
                    
                </div>
                <?php } ?>
            </div>
                        </div>
    </div>
    <script>
        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active')
            main.classList.toggle('active')

        }
    </script>

</body>

</html>