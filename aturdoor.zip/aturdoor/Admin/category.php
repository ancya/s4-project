<?php
include 'db2.php';
session_start();
if($_SESSION['login_admin']==""){
    header('location:login.php');
  }
if (isset($_POST['submit'])) {
    $category = $_POST['category'];
    $description = $_POST['description'];
    

    
    // $sql = mysqli_query($con, "INSERT INTO `dealer_tbl`( `dealer_name`, `email`, `phonenumber`, `place`, `login_id`) VALUES ('$name','$email','$phone','$address','$roleid')");
    $sel="SELECT * FROM `tbl_category` WHERE `category_name`='$category'";
   
	$query1=mysqli_query($con,$sel);
	$num=mysqli_num_rows($query1);
	if($num > 0)
	{
		echo '<script>alert("category already exit..!");</script>';
		echo "<script>window.location='category.php'</script>";
	}
    else{
        $sql = mysqli_query($con, "INSERT INTO `tbl_category`( `category_name`, `category_desc`) VALUES ('$category','$description')");
    
    echo "<script>alert('Succesfully added');</script>";
    header("Location: category.php");
}
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>At Your Door</title>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <style>
        input[type=text],
        [type=number],
        [type=password],
        [type=email],
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            resize: vertical;
        }

        label {
            padding: 12px 12px 12px 0;
            display: inline-block;
        }

        input[type=submit] {
            background-color: #04AA6D;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            float: right;
        }

        input[type=submit]:hover {
            background-color: #45a049;
        }

        .container {
            border-radius: 5px;
            background-color: #f2f2f2;
        }

        .col-25 {
            float: left;
            width: 15%;
            margin-top: 6px;
        }

        .col-75 {
            float: left;
            width: 75%;
            margin-top: 6px;
        }

        /* Clear floats after the columns */
        .row:after {
            content: "";
            display: table;
            clear: both;
        }
    </style>
</head>

<body>
    <?php include 'sidebar.php'; ?>

    <div class="main">
        <?php include 'topbar.php'; ?>
        <div class="disk">
            <h2><ADDress></ADDress>ADD CATEGORY</h2>
            <div class="container">
                <form method="post">
                    <div class="row">
                        <!-- <div class="col-25">
                            <label for="fname">place</label>
                        </div>
                        <div class="col-75">
                            <input type="text" id="fname" name="fname" placeholder="place..">
                        </div>
                    </div> -->
                   
                    <div class="row">
                        <div class="col-25">
                            <label for="lname">category Name</label>
                        </div>
                        <div class="col-75">
                            <input type="text" id="lname" name="category" placeholder="enter category    .." required onchange="Validate()">
                            <span id="msg1" style="color:red;"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-25">
                            <label for="subject">Description</label>
                        </div>
                        <div class="col-75">
                            <input type="text" id="lname" name="description" placeholder="describe   ..">
                        </div>
                       
                   
                    <br>
                    <div class="row">
                        <div class="col-75" style="margin-left:-250px">
                            <input type="submit" value="Submit" name="submit">
                        </div>
                        <div>
                        <div style="float:left;margin-left:10px">
<button style=" text-decoration:none;margin-top: 9px; height: 42px; width: 141px; background-color: #fdae04; border: none;border-radius: 6px;color: #fff;font-family:Poppins,sans-serif;"><a href="vc.php" style="text-decoration:none;">View Category</a></button>

</div>
    </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>		
function Validate() 
{
    var val = document.getElementById('lname').value;

    if (!val.match(/^[A-Z][A-Za-z/ ]{3,}$/)) 
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('lname').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script>
                    
    <script>

        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active')
            main.classList.toggle('active')

        }
    </script>
    

</body>

</html>