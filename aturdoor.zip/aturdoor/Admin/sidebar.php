<?php


?>
<div class="container">
    <div class="navigation" style="overflow: scroll;">
        <ul>
            <li style="margin-top:10px;">
                <a href="admin.php">
                    <span class="icon"><i class="fa fa-shopping-cart" aria-hidden="true"></i></span>
                    <span class="title">
                        <h2>At Your Door</h2>
                    </span>
                </a>
            </li>
            <li class="li_list">
                <a href="admin.php">
                    <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <span class="title">Dashboard</span>
                </a>
            </li>
            <li class="li_list">
                <a href="view_customers.php">
                    <span class="icon"><i class="fa fa-user" aria-hidden="true"></i></span>
                    <span class="title">Customers</span>
                </a>
            </li>
            <li class="li_list">
                <a href="add_dealer.php">
                    <span class="icon"><i class="fa fa-comments" aria-hidden="true"></i></span>
                    <span class="title">Add dealers</span>
                </a>
            </li>
            <li class="li_list">
                <a href="advie.php">
                    <span class="icon"><i class="fa fa-comments" aria-hidden="true"></i></span>
                    <span class="title">payment</span>
                </a>
            </li>
            <!-- <li class="li_list">
                <a href="acc_order.php">
                    <span class="icon"><i class="fa fa-comments" aria-hidden="true"></i></span>
                    <span class="title">Accept Orders</span>
                </a>
            </li> -->
            <!-- <li class="li_list">
                <a href="add_deliveryboy.php">
                    <span class="icon"><i class="fa fa-comments" aria-hidden="true"></i></span>
                    <span class="title">Add delivery boy</span>
                </a>
            </li> -->
            <li class="li_list">
                <a href="view_products.php">
                    <span class="icon"><i class="fa fa-info-circle" aria-hidden="true"></i></span>
                    <span class="title"> View products</span>
                </a>
            </li>
            <li class="li_list">
                <a href="manage.php">
                    <span class="icon"><i class="fa fa-cog" aria-hidden="true"></i></span>
                    <span class="title">manage dealers/customers</span>
                </a>
            </li>
            <li class="li_list">
                <a href="approvesel.php">
                    <span class="icon"><i class="fa fa-cog" aria-hidden="true"></i></span>
                    <span class="title">Approve sellers</span>
                </a>
            </li>
            <li class="li_list">
                <a href="category.php">
                    <span class="icon"><i class="fa fa-unlock" aria-hidden="true"></i></span>
                    <span class="title">Add category</span>
                </a>
            <li class="li_list">
                <a href="city.php">
                    <span class="icon"><i class="fa fa-info-circle" aria-hidden="true"></i></span>
                    <span class="title"> Add City</span>
                </a>
            </li>
            <li class="li_list">
                <a href="enquiryappr.php">
                    <span class="icon"><i class="fa fa-info-circle" aria-hidden="true"></i></span>
                    <span class="title"> Enquiry Approve</span>
                </a>
            </li>
            <li class="li_list">
                <a href="feedback.php">
                    <span class="icon"><i class="fa fa-unlock" aria-hidden="true"></i></span>
                    <span class="title">feedback</span>
                </a>
            </li>   
            <li class="li_list">
                <a href="logout.php">
                    <span class="icon"><i class="fa fa-sign-out" aria-hidden="true"></i></span>
                    <span class="title">Sign Out</span>
                </a>
            </li>
        </ul>
    </div>