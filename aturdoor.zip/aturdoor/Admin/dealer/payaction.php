<?php
include 'dbd.php';
session_start();
error_reporting(0);
$ff=$_SESSION['login_admin'];
$payid=$_GET['pid'];

if($_SESSION['login_admin']==""){
    header('location:login.php');
  }
  $re= mysqli_query($con, "UPDATE  adminpay SET status='1' where `adminpay_id`='$payid'");
  echo "<script>alert('Paid successfully..!');</script>";
  header("location:viewpay.php");
?>
