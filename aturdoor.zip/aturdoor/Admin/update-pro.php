<?php
include 'db2.php';
$su_id=$_GET['pro_id'];
mysqli_query($con,"UPDATE `product_tbl` SET `status` = 1 WHERE `product_id`='$su_id'");
echo "<script>alert('Product Approved');</script>";
header('location: acc_order.php');
?>