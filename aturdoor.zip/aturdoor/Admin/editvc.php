<?php      
    include 'db2.php';
    $id=$_GET['sid'];
    $sql="select * from `tbl_category` where id='$id'";
    $result=mysqli_query($con,$sql);
    $row=mysqli_fetch_array($result);
    $categoryname=$row['category_name'];


    if(isset($_POST['s']))
    {
    $id=$_GET['sid'];
	  $categorynamess = $_POST['categoryname'];
    
     mysqli_query($con,"UPDATE `tbl_category` SET `category_name`='$categorynamess' where id='$id'");
     echo "<script>alert('Succesfully updated');</script>";
     header('location:vc.php');
     }
  
      
    
 ?>
 
 <!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: darkblue;  
}  
.container {  
    padding: 50px;  
  background-color: white;  
}  
  
input[type=text], input[type=password], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=password]:focus {  
  background-color: white;  
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 0.9;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style> 
<style> form{
  padding: 150px 170px;
}</style> 
</head>  
<body>  
<form method='post' action="" enctype="multipart/form-data">  
  
  <div class="container">  
  <center>  <h1>UPDATE CATEGORY</h1> </center>  
  <hr>  
  <div class="modal-header">
 
                          </div>
                      <div class="modal-body">
                     <div class="card-body card-block">
					 <div class="form-group">
					  <span class="lnr lnr-user"></span>
                        <label for="company" class=" form-control-label"> Category Name</label>
                   <input type="text"   class="form-control" name="categoryname"  id="categoryname"  onfocusout="f1()" value="<?php echo $categoryname ?>" required >
                    </div>
					<span id="msgr" style="color:red;"></span>
<script>		

</script>
                </div>
                     
                </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal" style="margin-right: 66%"><a href="insert_category.php">Cancel</a></button>
                    <button type="submit" class="btn btn-primary" name="s">Update</button>
            </div>
                   
            </div>
                </div>
            
</form>  
</body>  
</html>