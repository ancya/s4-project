<?php
include 'db2.php';
session_start();
$uid=$_SESSION['login_admin'];
$rr=$_GET['date'];
$say = $_GET['date']."%";
//$oid = $_GET['id'];
//$main_tb = mysqli_query($conn,"SELECT `id`,`name`,`price`,`status` FROM `payment_tbl` WHERE id='$rrio'");
//$tb = mysqli_query($con,"SELECT * FROM `order_tbl` WHERE id='$rr'");
$sub_detail = mysqli_query($con,"SELECT order_tbl.status,order_tbl.price,order_tbl.date,register.uname,register.address FROM `order_tbl` inner join login_tbl on login_tbl.login_id = order_tbl.login_id inner join register on register.login_id=order_tbl.login_id where order_tbl.date like '$say'");


//if(isset($_POST['finish'])){
    
  //  header("location:Thank.php");
//}

?>
<html>
    <head>
        <title>Recipt</title>
        <style>
        .ord-inv-cont{
            margin-left: 25%;
            
}
.inv-body{
    margin-top: 30px;
 background-color: whitesmoke;
 box-shadow: 1px 1px 1px 1px;
 width: 55%;

}
.inv-dtls{
    text-align: center;
}
.inv-dtls h2{
    padding-top:4%;
    font-style: bold;
    color:black;
}
.inv-dtls p{
    font-size: 12px;
    font-style: italic;
    margin-top:-5px;
}
.inv-conts{
    margin: 50px;
}

.inv-head h5{
    margin-bottom: 20px;
}
.inv-addr{
    margin-left: 8%;
    margin-bottom: 10%;
}
.inv-tbl table{
   width: 100%;
}
.inv-tbl table tr{
    width: 100%;
}.inv-tbl table th{
    width: 10%;

}.inv-tbl table td{
    width: 10%;
    margin-left: 100px;
}
.inv-tot{
    margin-top: 20px;
}
.inv-tot text{
    float: left;
    text-align: inline;
}

.pay-stat{
    margin-top: 40px;
    width: 70%;
    background-color: #5cf78d;
    height: 30px;
    margin-left: 60px;
    color: black;
    text-align: center;
    margin-bottom: 10px;
}
.ord-stat{
    width: 70%;
    background-color: #2cf56c;
    height: 30px;
    margin-left: 60px;
    color: black;
    text-align: center;
    margin-bottom: 30px;
}
.inv-footer{
    margin-top:15px;
    padding-bottom: 10px;
    text-align: center;
}
.inv-btn{
    border: none;
    width: 150px;
    height:30px;
    border-radius:6px;
    background-color:#57d7fa;
    color: black;
    margin-left: 25%;
}
.inv-btn:hover{
    border: none;
    border-radius:6px;
    background-color:#51ad89;
    color: black;
}
.inv-btn1{
    border: none;
    width: 150px;
    height:30px;
    border-radius:6px;
    background-color:orange;
    color: black;
}
.inv-btn1:hover{
    border: none;
    border-radius:6px;
    background-color:lawngreen;
    color: black;
}

    </style>
    </head>
    <body>
<div class="ord-inv-cont" >
            <div class="inv-body" id="invoice">
                <div class="inv-dtls">
                    
                    <h2>AT YOUR DOOR</h2>
                    <p>The Best Super Market</p>
                </div>
                <form method="post">
                <div class="inv-conts">
                    
                  
                    <div class="inv-tbl">
                       
                        <table>
                            <tr>
                                
                                <th>Name</th>
                                <th>Address</th>
                                <th>Date</th>
                                <th>Price</th>
                                <th>Status</th>
                            </tr>
                            
                            <?php
                        while($fetch=mysqli_fetch_array($sub_detail)){
                        ?><tr>
                                <td><?php echo $fetch['uname']?></td>
                                <td><?php echo $fetch['address']?></td>
                                <td><?php echo $fetch['date']?></td>
                                <td><?php echo $fetch['price']?></td>
                                <td><?php echo $fetch['status']?></td>
                                </tr>
                            <?php }?>
                       
                        </table>
                    </div>
                    <div class="inv-tot">
                        <?php
                    while($fetchi=mysqli_fetch_array($sub_detail)){ ?>
                        <text>Total amount: <?php echo $fetch['price']?></text><br>
                        
                    <?php } ?>
                    </div>
                   
                    <!-- <div class="inv-footer">
                        <text>Thank you for purchasing with At Your Door</text>
                    </div> -->
                </div>
                
            </div>
            <p>

            <button class="inv-btn" onclick="printDiv('invoice')">Download Invoice</button>
            <button class="inv-btn1" type="submit" name="finish">Finish</button></p>
            
     </div>
</form>
<!-- print screen -->
<script type="text/javascript">
      function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
    </script>
    </body></html>
 