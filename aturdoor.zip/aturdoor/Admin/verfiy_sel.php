<?php
include 'db2.php';
$su_id=$_GET['pro_id'];


mysqli_query($con,"UPDATE `dealer_tbl` SET `status` = 1 WHERE `login_id`='$su_id'");

echo "<script>alert(' Approved');</script>";

header('location: approvesel.php');
?>