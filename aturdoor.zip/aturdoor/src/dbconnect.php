<?php
    $con=mysqli_connect('localhost','root','','traffic offense');
?>
