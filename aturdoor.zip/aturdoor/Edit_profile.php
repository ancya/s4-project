<?php
include 'db.php';
session_start();
$a=$_SESSION['login_admin'];
if(isset($_POST['submit']))
{
	$add=$_POST['address'];
	$phone=$_POST['phone'];
	$email=$_POST['email'];
    
	$edit=mysqli_query($conn,"UPDATE `register` SET  `phonenumber`='$phone',`address`='$add' WHERE `login_id`='$a'");
    $edit1=mysqli_query($conn,"UPDATE `login_tbl` SET `email`='$email'  WHERE ``login_id`='$a'");
	header("location:view_profile.php");
}
?>
