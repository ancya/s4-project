<?php
include 'db.php';
session_start();
error_reporting(0);

$uid = $_SESSION['login_admin'];
if($_SESSION['login_admin']==""){
    header('location:login.php');
  }
$as = mysqli_query($conn,"SELECT * FROM `register` where login_id='$uid'");
$ad = mysqli_fetch_assoc($as);
$ad = $ad['pincode'];
$as = mysqli_query($conn,"SELECT * FROM `deliveryboy_tbl` where pincode='$ad' and sts='active'");
$con = mysqli_num_rows($as);
if($con>0){
    $af = mysqli_fetch_assoc($as);
    $af = $af['login_id'];
}
$sql = mysqli_query($conn,"SELECT * from cart_tbl where login_id='$uid'");
while($row = mysqli_fetch_array($sql)){
  $name = $row['cart_id'];
}

if(isset($_POST['order'])){
    $total=$_POST['total'];
	$car2 = mysqli_query($conn,"SELECT * FROM `cart_tbl` where login_id=$uid");
    while($row = mysqli_fetch_array($car2))  { 
    $cartid = $_POST['id'];
	$order="INSERT INTO `order_tbl`(`login_id`, `cartid`, `price`,`status`) VALUES ('$uid', '$cartid', '$total','placed')";
	$or1=mysqli_query($conn,$order);
    $rid = mysqli_insert_id($conn);
    if($con>0){
        $oi = mysqli_query($conn,"UPDATE `order_tbl` SET `status`='shipped',`del_boy`='$af' WHERE `id`='$rid'");
        if($oi){
            mysqli_query($conn,"UPDATE `deliveryboy_tbl` SET `sts`='inactive' WHERE `login_id`='$af'");
        }
    }
    
     

    }
    echo"<script>window.location='final.php';</script>";
}
if(isset($_POST['cou'])){
    $total=$_POST['coup'];
    $car2 = mysqli_query($conn,"SELECT * FROM `coupon_tbl` where `coupon_code`='$total' and status='valid'");
    $ee=mysqli_num_rows($car2);
    if($ee>0){
        $car3 = mysqli_query($conn,"SELECT * FROM `coupon_tbl` where `coupon_code`='$total' and status='valid'");
        $uuu=mysqli_fetch_array($car2);
        $vv=$uuu['discount'];
        $rr=$uuu['owner_id'];
        $qqy = mysqli_query($conn,"SELECT product_tbl.owner_id,product_tbl.product_id,cart_tbl.product_id,cart_tbl.login_id,SUM(cart_tbl.total_price),cart_tbl.cart_id,cart_tbl.sts FROM `product_tbl` join `cart_tbl` on product_tbl.product_id=cart_tbl.product_id WHERE login_id='$uid' and owner_id='$rr' and cart_tbl.sts=0");
        $er=mysqli_fetch_array($qqy);
        $ll=$er['cart_id'];
        $oo= $er['SUM(cart_tbl.total_price)'];
       $mm= $oo * $vv / 100 ;
       $vv=$oo - $mm;
       $sql2 = "INSERT INTO discount_tbl(login_id,cart_id,discount) VALUES ($uid,$ll,$vv)";
	   mysqli_query($conn,$sql2);
		echo "<script>window.location='checkk.php'</script>";
    }else{
        echo '<script>alert("Coupon Does not Exists..!");</script>';
		echo "<script>window.location='checkk.php'</script>";
        

    }
  
}


?>
<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>AT UR DOOR</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css_cart/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css_cart/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css_cart/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css_cart/custom.css">
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all" /> 
<!-- //font-awesome icons -->
<!-- js -->
<script src="js/jquery-1.11.1.min.js"></script>

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
<?php include 'hheader.php' ?> 


    
    <center><h2>checkout</h2></center>
    <hr>
    <div class="cart-box-main">
        <div class="container">
           
            <div class="row">
            
                <div class="col-sm-6 col-lg-6 mb-3">
                    <div class="checkout-address">
                        <div class="title-left">
                            <h3>Billing address</h3>
                        </div>
                        
                        <form class="needs-validation" novalidate>
                            <div class="row">
                                
                            </div>
                            <div class="mb-3">
                            <?php
                          $result = mysqli_query($conn,"SELECT * FROM register where login_id='$uid'");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                                <label for="username">Username </label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="username" placeholder="<?php echo $raw['uname']; ?>" readonly>
                                   
                                </div>
                            </div>
                           
                            <div class="mb-3">
                                <label for="email">Contact Number</label>
                                <input type="email" class="form-control" id="phone" placeholder="<?php echo $raw['phonenumber']; ?>" readonly>
                                
                            </div>
                            <div class="mb-3">
                                <label for="address">Address</label>
                                <input type="text" class="form-control" id="address" placeholder="<?php echo $raw['address']; ?>" readonly>
                            
                            </div>
                                <?php } ?>
                            
                            <div class="row">
                                <div class="col-md-5 mb-3">
                                   
                                  
                                </div>
                                <div class="col-md-4 mb-3">
                                   
                                </div>
                                <div class="col-md-3 mb-3">
                                    
                                </div>
                            </div>
                            </form>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6 mb-3">
                <form action="" method="POST">
                    <div class="row">
                       
                        <div class="col-md-12 col-lg-12">
                            <div class="odr-box">
                                <div class="title-left">
                                    <h3>Shopping cart</h3>
                                </div>
                                <div class="rounded p-2 bg-light">
                                    <div class="media mb-2 border-bottom">
                                    <?php
                                $result = mysqli_query($conn,"SELECT cart_tbl.cart_id,cart_tbl.price,cart_tbl.quantity,cart_tbl.sts,cart_tbl.total_price, cart_tbl.product_id,product_tbl.product_name, product_tbl.image FROM cart_tbl LEFT JOIN product_tbl ON cart_tbl.product_id = product_tbl.product_id where login_id='$uid' and cart_tbl.sts=0");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                                        <div class="media-body"> <a href="carts.php"> <?php echo $raw['product_name']; ?></a>
                                        <input type="hidden" name="id" value="<?php echo $raw['cart_id']; ?>">
                                        
                                            <div class="small text-muted">Price: <?php echo $raw['price']; ?> <span class="mx-2">|</span> Qty: <?php echo $raw['quantity']; ?>   Subtotal: <?php echo $raw['total_price']; ?> </div>
                                        </div>
                                    </div>
                                <?php } ?>
                                   
                                   
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-12">
                            <div class="order-box">
                                <div class="title-left">
                                    <h3>Your order</h3>
                                </div>
                                <div> 
                                <?php
                                     $uu = 5;
                                    $qq = mysqli_query($conn,"SELECT SUM(total_price) FROM `cart_tbl` WHERE login_id='$uid' and sts=0 ");
                                    while($er=mysqli_fetch_array($qq)){  
                                    ?>
                                <b>Total : </b> 
                                <p style="float: right;">Rs: <?php echo $er['SUM(total_price)'];?></p> 
                                <?php }?>
                                </div>
                                    
                               
                            
                                <div> 
                                <br>
                              
                              <label>Enter coupon code(if any)</label>
                              <input type="text" name="coup" id="cou" placeholder="Enter code">
                              <input type="submit" name="cou" id="vit" value="Verify">
               
                             
                              <br>
                              <br>
                             </div>
                             <div>
                             <?php
                                    $qqp = mysqli_query($conn,"SELECT * FROM `discount_tbl` WHERE login_id='$uid' ");
                                    $kk=mysqli_num_rows($qqp);
                                    $tt=mysqli_fetch_array($qqp);
                                    $yy=$tt['discount'];  
                                    ?>
                                <b>Price after discount : </b> 
                                <p style="float: right;">Rs: <?php if($kk>0){
                                    echo $yy;
                                }else{
                                    $qqr = mysqli_query($conn,"SELECT SUM(total_price) FROM `cart_tbl` WHERE login_id='$uid' and sts=0 ");
                                    while($eyr=mysqli_fetch_array($qqr)){  
                                    echo $eyr['SUM(total_price)'];
                                    }
                                } ?> </p> 
                                </div>
                               
                             
                             <div>
                                <b>GST : </b> 
                                <?php
                                    $qqr = mysqli_query($conn,"SELECT * FROM `discount_tbl` WHERE login_id='$uid' ");
                                    $kky=mysqli_num_rows($qqr);
                                    $tt=mysqli_fetch_array($qqr);
                                    $yy=$tt['discount'];  
                                    $vvi=$yy*5/100;
                                    //$jj=$er['SUM(total_price)'];
                                    //$vu=$jj*5/100;
                                    ?>
                                <p style="float: right;">RS: <?php if($kky>0){
                                    echo $vvi;
                                }else{
                                    //echo $vu;
                                    $qqm = mysqli_query($conn,"SELECT SUM(total_price) FROM `cart_tbl` WHERE login_id='$uid' and sts=0 ");
                                    while($eyr=mysqli_fetch_array($qqm)){  
                                    $yyk= $eyr['SUM(total_price)'];
                                    $vu=$yyk*5/100;
                                    echo $vu;
                                    }
                                    

                                }?> </p> 
                                </div>
                                <div> 
                                <b>Delivery Charges : </b> 
                                <p style="float: right;">Rs: <?php echo $uu;?></p> 
                                </div>
                               
                          
                               
                                <div class="d-flex gr-total">
                                    <h5>Grand Total</h5>
                                    <?php
                                         $qh = mysqli_query($conn,"SELECT * FROM `discount_tbl` WHERE login_id='$uid' ");
                                         $kkt=mysqli_num_rows($qh);
                                         $tt=mysqli_fetch_array($qh);
                                         $yy=$tt['discount'];  
                                         $vvi=$yy*5/100;
                                        // $jj=$er['SUM(total_price)'];
                                         //$vu=$jj*5/100;
                                        // $ntot=$jj+$uu+$vu;
                                         $dtot=$yy+$uu+$vvi;
                                    ?>
                                    <div class="ml-auto h5"><p>RS:</p> <input type="text" name="total" value="<?php if($kkt>0){
                                    echo $dtot;
                                }else{
                                    $uu=5;
                                    $qqi = mysqli_query($conn,"SELECT SUM(total_price) FROM `cart_tbl` WHERE login_id='$uid' and sts=0 ");
                                    while($eyi=mysqli_fetch_array($qqi)){  
                                    $yyi= $eyi['SUM(total_price)'];
                                    $vo=$yyi*5/100;
                                    $rpp=$yyi+$vo+$uu;
                                    echo $rpp;
                                    
                                    }
                                    

                                }?>" style="border:none"> </div>
                                    
                                </div>
                           
                                <hr> </div>
                        </div>
                        <div style=""> 
                            <?php 
                        $qho = mysqli_query($conn,"SELECT * FROM `discount_tbl` WHERE login_id='$uid' ");
                                        $uu=5;
                                         $ka=mysqli_num_rows($qho);
                                         $tti=mysqli_fetch_array($qho);
                                         $yyf=$tti['discount'];  
                                         $vb=$yyf*5/100;
                                        // $jj=$er['SUM(total_price)'];
                                         //$vu=$jj*5/100;
                                        // $ntot=$jj+$uu+$vu;
                                         $dtot=$yyf+$uu+$vb;
                                         ?>
                            <button style="background-color: #84c639;margin-left: 397px;  border: thin;width: 128px; height: 59px;color: white;font-weight: 700;"><a href="payment.php?an=<?php if($ka>0){
                                    echo $dtot;
                                }else{
                                    $uu=5;
                                    $qqi = mysqli_query($conn,"SELECT SUM(total_price) FROM `cart_tbl` WHERE login_id='$uid' and sts=0 ");
                                    while($eyi=mysqli_fetch_array($qqi)){  
                                    $yyi= $eyi['SUM(total_price)'];
                                    $vo=$yyi*5/100;
                                    $rpp=$yyi+$vo+$uu;
                                    echo $rpp;
                                    
                                    }
                                    

                                }?>">Place Order</a></button>
                    </div>
                    
                    </form>
                </div>
            </div>

        </div>
    </div>
  

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>