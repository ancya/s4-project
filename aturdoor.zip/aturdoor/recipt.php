<?php
include 'db.php';
session_start();
$uid=$_SESSION['login_admin'];
$rr=$_GET['ii'];
//$oid = $_GET['id'];
//$main_tb = mysqli_query($conn,"SELECT `id`,`name`,`price`,`status` FROM `payment_tbl` WHERE id='$rrio'");
$tb = mysqli_query($conn,"SELECT * FROM `order_tbl` WHERE id='$rr'");
$sub_detail = mysqli_query($conn,"SELECT cart_tbl.login_id,cart_tbl.quantity,cart_tbl.sts,cart_tbl.orderid,cart_tbl.product_id,cart_tbl.total_price,product_tbl.product_name,product_tbl.product_id,product_tbl.price FROM cart_tbl JOIN product_tbl ON cart_tbl.product_id = product_tbl.product_id where cart_tbl.login_id='$uid' and cart_tbl.orderid='$rr'");
$totalqty = mysqli_query($conn,"SELECT SUM(total_price) FROM `cart_tbl` WHERE login_id='$uid' and sts=0 ");
$llo=mysqli_query($conn,"SELECT * from register where login_id='$uid'");
$rowu = mysqli_fetch_array($llo);
$yy=$rowu['uname'];
$bb=$rowu['phonenumber'];
$xx=$rowu['place'];
$uy=$rowu['address'];

//$row = mysqli_fetch_array($main_tb);
//$uu= mysqli_fetch_array($sub_detail);
$row1 = mysqli_fetch_array($totalqty);

//if(isset($_POST['finish'])){
    
  //  header("location:Thank.php");
//}

?>
<html>
    <head>
        <title>Recipt</title>
        <style>
        .ord-inv-cont{
            margin-left: 25%;
            
}
.inv-body{
    margin-top: 30px;
 background-color: whitesmoke;
 box-shadow: 1px 1px 1px 1px;
 width: 55%;

}
.inv-dtls{
    text-align: center;
}
.inv-dtls h2{
    padding-top:4%;
    font-style: bold;
    color:black;
}
.inv-dtls p{
    font-size: 12px;
    font-style: italic;
    margin-top:-5px;
}
.inv-conts{
    margin: 50px;
}

.inv-head h5{
    margin-bottom: 20px;
}
.inv-addr{
    margin-left: 8%;
    margin-bottom: 10%;
}
.inv-tbl table{
   width: 100%;
}
.inv-tbl table tr{
    width: 100%;
}.inv-tbl table th{
    width: 10%;

}.inv-tbl table td{
    width: 10%;
    margin-left: 100px;
}
.inv-tot{
    margin-top: 20px;
}
.inv-tot text{
    float: left;
    text-align: inline;
}

.pay-stat{
    margin-top: 40px;
    width: 70%;
    background-color: #5cf78d;
    height: 30px;
    margin-left: 60px;
    color: black;
    text-align: center;
    margin-bottom: 10px;
}
.ord-stat{
    width: 70%;
    background-color: #2cf56c;
    height: 30px;
    margin-left: 60px;
    color: black;
    text-align: center;
    margin-bottom: 30px;
}
.inv-footer{
    margin-top:15px;
    padding-bottom: 10px;
    text-align: center;
}
.inv-btn{
    border: none;
    width: 150px;
    height:30px;
    border-radius:6px;
    background-color:#57d7fa;
    color: black;
    margin-left: 25%;
}
.inv-btn:hover{
    border: none;
    border-radius:6px;
    background-color:#51ad89;
    color: black;
}
.inv-btn1{
    border: none;
    width: 150px;
    height:30px;
    border-radius:6px;
    background-color:orange;
    color: black;
}
.inv-btn1:hover{
    border: none;
    border-radius:6px;
    background-color:lawngreen;
    color: black;
}

    </style>
    </head>
    <body>
<div class="ord-inv-cont" >
            <div class="inv-body" id="invoice">
                <div class="inv-dtls">
                    
                    <h2>AT YOUR DOOR</h2>
                    <p>The Best Super Market</p>
                </div>
                <form method="post">
                <div class="inv-conts">
                    <div class="inv-head">
                    <h5>order No:&nbsp; <?php echo $rr; ?></h5>
                    <h5>Customer Name:&nbsp; <?php echo $yy; ?></h5>
                    <h5>Phone:&nbsp; <?php echo $bb; ?></h5>
                    <h5>Address:&nbsp; <?php echo $uy; ?></h5>
                    <h5>Place:&nbsp; <?php echo $xx; ?></h5>
                    </div>
                  
                    <div class="inv-tbl">
                       
                        <table>
                            <tr>
                                <th>Items</th>
                                <th>Quantity</th>
                                <th>Price</th>
                            </tr>
                            
                            <?php
                        while($fetch=mysqli_fetch_array($sub_detail)){
                        ?><tr>
                                <td><?php echo $fetch['product_name']?></td>
                                <td><?php echo $fetch['quantity']?></td>
                                <td><?php echo $fetch['price']?></td>
                                </tr>
                            <?php }?>
                       
                        </table>
                    </div>
                    <div class="inv-tot">
                        <?php
                    while($fetchi=mysqli_fetch_array($tb)){ ?>
                        <text>Total amount: <?php echo $fetchi['price']?></text><br>
                        
                    <?php } ?>
                    </div>
                   
                    <div class="inv-footer">
                        <text>Thank you for purchasing with At Your Door</text>
                    </div>
                </div>
                
            </div>
            <p>

            <button class="inv-btn" onclick="printDiv('invoice')">Download Invoice</button>
            <button class="inv-btn1" type="submit" name="finish">Finish</button></p>
            
     </div>
</form>
<!-- print screen -->
<script type="text/javascript">
      function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
    </script>
    </body></html>
 