<?php
include 'db.php';
session_start();
error_reporting(0);
 
$uid = $_SESSION['login_admin'];
if($_SESSION['login_admin']==""){
  header('location:login.php');
}
$final = 'out';
?>
<?php

if(isset($_POST['remove'])){
$cartid = $_POST['id'];
$sqlls = "DELETE from cart_tbl where cart_id=$cartid";
mysqli_query($conn,$sqlls);
echo"<script>alert('Item Removed');</script>";
echo"<script>window.location='carts.php';</script>";

}

if(isset($_POST['update'])){
    $price = $_POST['price'];
    $quan = $_POST['quantity'];
    $total=$_POST['price'] * $_POST['quantity'];
    $cartid = $_POST['id'];
   
    $sqll = "UPDATE cart_tbl SET quantity=$quan,total_price=$total where cart_id=$cartid";
    mysqli_query($conn,$sqll);
    }
    if(isset($_POST['cart_up'])){
    $cartid = $_POST['cid'];
    $price = $_POST['price'];
    $qid = $_POST['quantity'];
    $product_id=$_POST['id'];
    // echo $price;
    // echo $qid;
    $total=$price * $qid;
   
    
    $sqll = "UPDATE cart_tbl SET quantity=$qid,total_price=$total where cart_id=$cartid";
    mysqli_query($conn,$sqll);
    $sql3= "UPDATE product_tbl SET quantity=quantity-$qid where product_id=$product_id";
    //mysqli_query($conn,$sql3);
    
}

?>

<script>
function remove()
{
if(confirm("Do you want to remove this item"))
{
	return true;
}
else{
	return false;
}
}                      
 </script>


<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>At your Door</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css_cart/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css_cart/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css_cart/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css_cart/custom.css">
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="all" /> 
<!-- //font-awesome icons -->
<!-- js -->
<script src="js/jquery-1.11.1.min.js"></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Ubuntu:400,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <?php include 'hheader.php' ?>
    
  <h2 style="margin-left: 572px;">My Cart</h2>
  <hr>

    <div class="cart-box-main">
        <div class="container" style="margin-left: 253px;">
            <div class="row">
                <div class="col-md-6">
                    
                    <div class="">
  
                        <table class="table" id="cart_tbl">
                            <thead style="background: #84c639">
                                <tr>
                                    <th style="color:#fff">Image</th>
                                    <th style="color:#fff">Product</th>
                                    <th style="color:#fff">Price</th>
                                    <th style="color:#fff">Quantity</th>
                                    <th style="color:#fff">Total</th>
                                    <th style="color:#fff">Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                            	<?php			
                                    $result = mysqli_query($conn,"SELECT cart_tbl.cart_id,cart_tbl.price,cart_tbl.quantity,cart_tbl.sts,cart_tbl.total_price, cart_tbl.product_id,product_tbl.product_name, product_tbl.image FROM cart_tbl LEFT JOIN product_tbl ON cart_tbl.product_id = product_tbl.product_id where login_id='$uid'and cart_tbl.sts=0");
                                    while ($raw = mysqli_fetch_array($result)){
                                        $ss=$raw['price']*$raw['quantity'];
                                        
                                      ?>
                                   
                                
                            
                                <tr>
                                    <td class="thumbnail-img">

									<img class="img-fluid" src="dealer/productimages/<?php echo $raw['image']; ?>" alt="" />
								
                                    </td>
                                    <td class="name-pr">
                                   
                                        <?php echo $raw['product_name']; ?>
								
                                    </td>
                                    <form method="POST" id="frm<?php echo $raw['cart_id'] ?>">
                                        
                                    <?php   $cartid = $raw['product_id'];
                                             $q = mysqli_query($conn,"SELECT quantity from product_tbl where product_id='$cartid'");
                                             while ($row = mysqli_fetch_array($q)){
                                                 $quan = $row['quantity'];
                                             }
                                    ?>
                                    <td class="">
                                        <input type="text" name="price" value="<?php echo $raw['price']; ?>" style="border: none;font-family: 'Quattrocento Sans', sans-serif;color:#666666;">
                                    </td>
                                    <td class="quantity-box">
                                        <input type="hidden" name="pid" value="<?php echo $raw['price']; ?>">
                                        <input type="hidden" name="cid" value="<?php echo $raw['cart_id']; ?>">
                                        <input type="number" name="quantity" size="4" value="<?php echo $raw['quantity']; ?>" min="1" max="<?php echo $quan; ?>" id="quantity" style="height: 25px;width: 50px;" class="c-input-text qty text" onchange="updcart(<?php echo $raw['cart_id']; ?>)" onkeyup="updcart(<?php echo $raw['cart_id']; ?>)">
                                         
                                    </td>
                                    <td class="">
                                    <input type="text" name="totalprice" value="<?php echo $ss ?>" style="border: none;font-family: 'Quattrocento Sans', sans-serif;color:#666666">
                                    </td>
                                    <input type="hidden" name="cid" value="<?php echo $raw['cart_id']; ?>">
                                    <input type="hidden" name="id" value="<?php echo $raw['product_id']; ?>">
                                   
                                    </form>
                                    <td class="">
                                        <a href="p_delete.php?cid=<?php echo $raw['cart_id']; ?>">
                                      <button style="border: none;background-color: #fff;">Remove</button>
                                    </a>
                                    </td>
                                    
                                 
                                </tr>
                                
                
                                <?php }  ?>
                               
                            </tbody>
                        </table>
                        
                    </div>
                                    
                </div>
            </div>

            <div class="row my-5">
                
                <div class="col-md-5 col-sm-6">
                    <div class="update-box">
                        <?php if($final=='out'){ ?>
                            <h3 style="color:red">*Some of the products are Out of Stock, remove them to place order.</h3>
                        <?php }else{ ?>
                        <button style="background:#84c639;height: 38px; width: 181px;"><a href="checkout.php" style="color=#fff">PLACE ORDER</a></button>
                        <?php }?>
                    </div>
                </div>
            </div>
            

          
        </div>
    </div>
<script>
    
function updcart(id){
    $.ajax({
        url:'get.php',
        type:'POST',
        data:$("#frm"+id).serialize(),
        success:function(res){
            $("cart_tbl").html(res);

        }






    });
}
</script>

    


    
</body>

</html>