<!-- header -->
<div class="agileits_header">
		<div class="w3l_offers">
			<a href="products.html">Today's special Offers !</a>

		</div>
 	
		<div class="product_list_header">  
		<div class="w3l_header_right">
		<form class="example" action="search.php" method="POST">
        <input type="text" placeholder="Search.." name="search" >
        <button type="submit"><i class="fa fa-search" ></i></button>
        </form>
				
		
		</div>
			<div style="float:left">
		<button style=" text-decoration:none;margin-top: 9px;margin-left: 27px; height: 32px; width: 141px; background-color: #fdae04; border: none;font-size: 1.2em;color: #fff;"><a href="view_profile.php" style="text-decoration:none;">View Profile</a></button>
           </div>
		   <div style="float:left;margin-left:10px">
		<button style=" text-decoration:none;margin-top: 9px; height: 32px; width: 141px; background-color: #fdae04; border: none;font-size: 1.2em;color: #fff;"><a href="carts.php" style="text-decoration:none;">View Cart</a></button>
		
         </div>
		
	      </div>
		
		
		<div class="w3l_header_right1">
			<h2><a href="register.php">Register</a></h2>
		</div>
		
		<div class="w3l_header_right1">
			<h2><a href="login.php">Login</a></h2>
		</div>
		<div class="clearfix"> </div>
	</div>
<!-- script-for sticky-nav -->
	<script>
	$(document).ready(function() {
		 var navoffeset=$(".agileits_header").offset().top;
		 $(window).scroll(function(){
			var scrollpos=$(window).scrollTop(); 
			if(scrollpos >=navoffeset){
				$(".agileits_header").addClass("fixed");
			}else{
				$(".agileits_header").removeClass("fixed");
			}
		 });
		 
	});
	</script>
<!-- //script-for sticky-nav -->
	<div class="logo_products">
		<div class="container">
			<div class="w3ls_logo_products_left">
				<h1><a href="index.php"><span>@Your</span>Door</a></h1>
			</div>
			<div class="w3ls_logo_products_left1">
				<!-- <ul class="special_items">
					<li><a href="events.html">Events</a><i>/</i></li>
					<li><a href="about.html">About Us</a><i>/</i></li>
					<li><a href="product.php">Best Deals</a><i>/</i></li>
					<li><a href="services.html">Services</a></li>
				</ul> -->
			</div>
			<div class="w3ls_logo_products_left1">
				<ul class="phone_email">
					<li><i class="fa fa-phone" aria-hidden="true"></i>(+91)700099886</li>
					<li><i class="fa fa-envelope-o" aria-hidden="true"></i><a href="mailto:door@grocery.com">door@grocery.com</a></li>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //header -->