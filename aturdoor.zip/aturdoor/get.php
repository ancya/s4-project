
<?php
include 'db.php';
session_start();
error_reporting(0);
$uid = $_SESSION['login_admin'];
$cartid=$_POST['cid'];
$quan = $_POST['quantity'];
$vt=$_POST['price'];
$yy=$_POST['quantity']*$_POST['price'];
   
$sqll = "UPDATE cart_tbl SET quantity=$quan,total_price=$yy where cart_id=$cartid";
mysqli_query($conn,$sqll);
    
?>


                    
                            	<?php			
                                    $result = mysqli_query($conn,"SELECT cart_tbl.cart_id,cart_tbl.price,cart_tbl.quantity,cart_tbl.sts,cart_tbl.total_price, cart_tbl.product_id,product_tbl.product_name, product_tbl.image FROM cart_tbl LEFT JOIN product_tbl ON cart_tbl.product_id = product_tbl.product_id where login_id='$uid'and cart_tbl.sts=0");
                                    while ($raw = mysqli_fetch_array($result)){
                                        $ss=$raw['price']*$raw['quantity'];
                                        
                                      ?>
                                   
                                
                            
                                <tr>
                                    <td class="thumbnail-img">

									<img class="img-fluid" src="dealer/productimages/<?php echo $raw['image']; ?>" alt="" />
								
                                    </td>
                                    <td class="name-pr">
                                   
                                        <?php echo $raw['product_name']; ?>
								
                                    </td>
                                    <form method="POST" id="frm<?php echo $raw['cart_id'] ?>">
                                        
                                    <?php   $cartid = $raw['product_id'];
                                             $q = mysqli_query($conn,"SELECT quantity from product_tbl where product_id='$cartid'");
                                             while ($row = mysqli_fetch_array($q)){
                                                 $quan = $row['quantity'];
                                             }
                                    ?>
                                    <td class="">
                                        <input type="text" name="price" value="<?php echo $raw['price']; ?>" style="border: none;font-family: 'Quattrocento Sans', sans-serif;color:#666666;">
                                    </td>
                                    <td class="quantity-box">
                                        
                                        <input type="hidden" name="cid" value="<?php echo $raw['cart_id']; ?>">
                                        <input type="number" name="quantity" size="4" value="<?php echo $raw['quantity']; ?>" min="1" max="<?php echo $quan; ?>" id="quantity" style="height: 25px;width: 50px;" class="c-input-text qty text" onchange="updcart(<?php echo $raw['cart_id']; ?>)" onkeyup="updcart(<?php echo $raw['cart_id']; ?>)">
                                         
                                    </td>
                                    <td class="">
                                    <input type="text" name="totalprice" value="<?php echo $ss ?>" style="border: none;font-family: 'Quattrocento Sans', sans-serif;color:#666666">
                                    </td>
                                    <input type="hidden" name="cid" value="<?php echo $raw['cart_id']; ?>">
                                    <input type="hidden" name="id" value="<?php echo $raw['product_id']; ?>">
                                   
                                    </form>
                                    <td class="">
                                        <a href="p_delete.php?cid=<?php echo $raw['cart_id']; ?>">
                                      <button style="border: none;background-color: #fff;">Remove</button>
                                    </a>
                                    </td>
                                    
                                 
                                </tr>
                                
                
                                <?php }  ?>
                               
                            </tbody>
                        </table>