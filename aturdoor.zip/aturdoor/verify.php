<?php
include('db.php');
$eml = $_GET['eml'];

mysqli_query($conn,"UPDATE `login_tbl` SET `status`=1 WHERE `email`='$eml'");
echo "<script>window.location='login.php'</script>";
?>