<html>
    <head>
    
    <link rel="stylesheet" href="admin/css1/bootstrap.min.css">
    
    <link rel="stylesheet" href="admin/css1/style.css">
    
    <link rel="stylesheet" href="admin/css1/responsive.css">
    
    <link rel="stylesheet" href="admin/css1/custom.css">
    <style>
 

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: #3e8e41;
}
    </style>
</head>
<body>


    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav" style="height: 159px;">
            <div class="container">
        
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.php"><img src="https://thumbs.dreamstime.com/b/aloha-brush-lettering-vocation-cards-banners-posters-design-handwritten-modern-pen-calligraphy-vector-illustration-stock-94195337.jpg" class="logo" alt="" style="height: 124px;width: 147px;margin-bottom:5px"></a>
                    <div class="brand_name" style="float: right;margin-top: 34px;">
                    <h2 style="font-size: 27px;font-family: 'Montserrat';font-weight: 600;font-size: 30px;">Aloha<br>Events.<h2>
                    
                    </div>
                </div>
                
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="nav-item active"><a class="nav-link" href="index.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';padding-left: 17px;">HOME</a></li>
                        <li class="nav-item"><a class="nav-link" href="services.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';padding-left: 17px;">SERVICES</a></li>
                        <li class="nav-item"><a class="nav-link" href="about.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';padding-left: 17px;">ABOUT</a></li>
                        <li class="nav-item"><a class="nav-link" href="mail.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';padding-left: 17px;">MAIL US</a></li>
                        <li>
                        <?php if (strlen($_SESSION['obbsuid']!=0)) {?>
                            <div class="dropdown">
                        <a class="nav-link" href="#" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';color: black;  margin-top: 16px; padding-left: 16px; padding-right: 16px;padding-left: 17px;">MY ACCOUNT</a>
                        <div class="dropdown-content">
                        <a href="profile.php">Profile</a>
                        <a href="booking-history.php">Booking History</a>
                        <a href="change-password.php">Change Password</a>
                        <a href="logout.php">Logout</a>
                        
                       
                    </div>
                   </div>
                        <?php } ?>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="login.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';padding-left: 17px;">LOG IN </a></li>
                        <li>
                    <?php if (strlen($_SESSION['obbsuid']==0)) {?>
                        <div class="dropdown">
                        <a class="nav-link" href="#" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';color: green;    margin-top: 16px; padding-left: 16px; padding-right: 16px;">REGISTER</a>
                        <div class="dropdown-content">
                        <a href="signup.php">As User</a>
                        <a href="supplier.php">As Supplier</a>
                       
                    </div>
                   </div>

                    <?php } ?>
                    </li>
                    
                        
                        <a href="" class="dropdown-toggle" data-toggle="dropdown">
                                            <script type="text/javascript">
                                               $(document).ready(function(){
		                                        $.post("get.php",{data:'get'},function(data){
                                                    if(data>0){
                                                        $("span#myspan").show();
                                                        $("span#myspan").text(data);
                                                    }
		                                            });	
                                                    $("span#myspan").click(function(){
                                                        
    
                                                      $("span#myspan").hide("slow"); 

                                                        $.post("get.php",{update:'update'},function(data){
                                                            alert("Your booking have been approved..For more details Check View Bookings section!!");

                                                        });
                                                     
                                                      
                                                    });
                                                    });
                                                  </script>
                                                  <?php if (strlen($_SESSION['obbsuid']!=0)) {?>
                                                  <span class="glyphicon glyphicon-bell" id="bspan" style="font-size:20px;color:#fff;margin-left: 31px;"></span>
                                                  <span id="myspan" class="label label-pill label-danger count" style="border-radius:10px;margin-left: 2px;border-radius: 4px;"> </span></a>
                                                  <?php } ?> 
                    
                        
                    </ul>
                </div>
               
            </div>
           
        </nav>
    
    </header>
    
</body>
</html>