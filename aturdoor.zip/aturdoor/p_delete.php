<?php

include 'db.php';
$cartid = $_GET['cid'];
echo $cartid;

$sqlls = "DELETE from cart_tbl where cart_id='$cartid'";
mysqli_query($conn,$sqlls);
echo"<script>alert('Item Removed');</script>";
echo"<script>window.location='carts.php';</script>";
?>