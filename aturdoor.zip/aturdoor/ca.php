<?php
include 'db.php';
session_start();
error_reporting(0);
 
$uid = $_SESSION['login_admin'];
if($_SESSION['login_admin']==""){
  header('location:login.php');
}
$c = $_GET['cid'];
$b = $_GET['qu'];

$qw = mysqli_query($conn,"SELECT price from cart_tbl where cart_id='$c'");
$qw = mysqli_fetch_assoc($qw);
$qw = $qw['price'];
$a = $qw * $b;
    $sqll = "UPDATE cart_tbl SET quantity= '$b',total_price='$a' where cart_id='$c'" ;
    mysqli_query($conn,$sqll);
    
  header('location:carts.php');

?>